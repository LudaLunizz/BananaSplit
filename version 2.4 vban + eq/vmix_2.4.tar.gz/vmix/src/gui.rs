//! Graphical control surface (`vmix --gui`), with no dependencies: a tiny
//! HTTP server on 127.0.0.1 serves one self-contained page (`gui.html`,
//! embedded in the binary) and streams the mixer state to it.
//!
//! * `GET  /`            the page
//! * `GET  /api/events`  Server-Sent Events: one JSON state object per UI frame
//! * `GET  /api/state`   the latest JSON state, once
//! * `GET  /api/ping`    `vmix-gui` (lets a second `vmix --gui` find this one)
//! * `POST /api/cmd`     one control change, form-encoded (`op=gain&ch=0&v=-3.5`)
//!
//! All mixer parameters (EQ included) are atomics in [`Shared`], so the page
//! changes them exactly like the terminal UI does, with the same click-free
//! ramps. VBAN settings go to [`Vban`], which applies them within a few
//! milliseconds. Things that need the main loop (save, reconnect, rename,
//! quit) are queued as [`Request`]s.
//!
//! Security: listens on 127.0.0.1 only. Every request must carry a `Host`
//! naming this server (defeats DNS rebinding). A `POST` must also carry
//! `X-Vmix: 1` and, if the browser sends one, a same-origin `Origin`; a
//! custom header forces a CORS preflight, which this server never grants,
//! so other web pages open in the browser cannot drive the mixer.

use crate::tui::{Info, ROWS};
use std::fmt::Write as _;
use std::io::{Read, Write};
use std::net::{Ipv4Addr, Shutdown, SocketAddr, TcpListener, TcpStream};
use std::os::unix::process::CommandExt;
use std::process::{Command, Stdio};
use std::sync::atomic::{AtomicBool, AtomicUsize, Ordering::SeqCst};
use std::sync::{Arc, Condvar, Mutex, MutexGuard};
use std::time::Duration;
use vmix::config::Config;
use vmix::engine::{MAX_GAIN_DB, MIN_GAIN_DB, NUM_BUSES, NUM_STRIPS, Shared, clamp_db};
use vmix::eq::{self, BANDS, DEFAULT_BANDS, Kind};
use vmix::recorder::{self, ALL_LINKS, Format, Mode, NUM_SOURCES, Recorder, Settings, Status};
use vmix::vban::{self, FromAddr, InState, NUM_IN, NUM_OUT, OutState, SampleFormat, Vban, VbanConfig, VbanStatus};

pub const DEFAULT_PORT: u16 = 8790;
const PAGE: &str = include_str!("gui.html");
const MAX_HEAD: usize = 16 * 1024;
const MAX_BODY: usize = 64 * 1024;
const MAX_CONNS: usize = 32;
const MAX_STREAMS: usize = 8;
const MAX_NAME: usize = 32;

/// Work for the main loop.
#[derive(Debug, PartialEq)]
pub enum Request {
    Save,
    Reconnect,
    Quit,
    /// Rename channel (0..5 strips, 6..10 buses).
    Rename(usize, String),
}

/// State shared between the main loop and the HTTP threads.
pub struct Hub {
    pub shared: Arc<Shared>,
    pub recorder: Arc<Recorder>,
    pub vban: Arc<Vban>,
    state: Mutex<(u64, Arc<String>)>,
    cond: Condvar,
    names: Mutex<Vec<String>>,
    requests: Mutex<Vec<Request>>,
    closing: AtomicBool,
    conns: AtomicUsize,
    streams: AtomicUsize,
}

fn lock<T>(m: &Mutex<T>) -> MutexGuard<'_, T> {
    m.lock().unwrap_or_else(|e| e.into_inner())
}

impl Hub {
    pub fn new(shared: Arc<Shared>, recorder: Arc<Recorder>, vban: Arc<Vban>) -> Arc<Hub> {
        Arc::new(Hub {
            shared,
            recorder,
            vban,
            state: Mutex::new((0, Arc::new("{}".into()))),
            cond: Condvar::new(),
            names: Mutex::new(Vec::new()),
            requests: Mutex::new(Vec::new()),
            closing: AtomicBool::new(false),
            conns: AtomicUsize::new(0),
            streams: AtomicUsize::new(0),
        })
    }

    /// The 11 channel names (used for multi-track file names).
    pub fn set_names(&self, names: Vec<String>) {
        *lock(&self.names) = names;
    }

    /// New state for every connected page.
    pub fn publish(&self, json: String) {
        let mut st = lock(&self.state);
        st.0 = st.0.wrapping_add(1);
        st.1 = Arc::new(json);
        drop(st);
        self.cond.notify_all();
    }

    pub fn take_requests(&self) -> Vec<Request> {
        std::mem::take(&mut *lock(&self.requests))
    }

    fn request(&self, r: Request) {
        lock(&self.requests).push(r);
    }

    /// End all event streams (on quit).
    pub fn close(&self) {
        self.closing.store(true, SeqCst);
        self.cond.notify_all();
    }
}

// ---------------------------------------------------------------------------
// State as JSON
// ---------------------------------------------------------------------------

fn jstr(o: &mut String, s: &str) {
    o.push('"');
    for c in s.chars() {
        match c {
            '"' => o.push_str("\\\""),
            '\\' => o.push_str("\\\\"),
            '\n' => o.push_str("\\n"),
            '\r' => o.push_str("\\r"),
            '\t' => o.push_str("\\t"),
            '<' | '>' | '&' | '\u{2028}' | '\u{2029}' => {
                let _ = write!(o, "\\u{:04x}", c as u32);
            }
            c if (c as u32) < 0x20 => {
                let _ = write!(o, "\\u{:04x}", c as u32);
            }
            c => o.push(c),
        }
    }
    o.push('"');
}

fn jnum(o: &mut String, v: f64, decimals: usize) {
    let v = if v.is_finite() { v } else { 0.0 };
    let _ = write!(o, "{v:.decimals$}");
}

/// Remove ANSI escape sequences (status texts are shared with the TUI).
pub fn plain(s: &str) -> String {
    let mut o = String::with_capacity(s.len());
    let mut it = s.chars();
    while let Some(c) = it.next() {
        if c == '\x1b' {
            for d in it.by_ref() {
                if d.is_ascii_alphabetic() {
                    break;
                }
            }
        } else {
            o.push(c);
        }
    }
    o
}

pub struct Frame<'a> {
    pub info: &'a Info<'a>,
    pub cfg: &'a Config,
    pub meters: &'a [[f32; 2]; ROWS],
    pub conn: &'a [String],
    pub status: &'a str,
    pub rec: &'a Status,
    pub rec_settings: &'a Settings,
    pub vban: &'a VbanStatus,
    pub vban_cfg: &'a VbanConfig,
}

fn jopt(o: &mut String, s: Option<&str>) {
    match s {
        Some(s) => jstr(o, s),
        None => o.push_str("null"),
    }
}

fn in_state(s: InState) -> &'static str {
    match s {
        InState::Off => "off",
        InState::Blocked => "blocked",
        InState::Waiting => "waiting",
        InState::Receiving => "receiving",
    }
}

fn out_state(s: OutState) -> &'static str {
    match s {
        OutState::Off => "off",
        OutState::Blocked => "blocked",
        OutState::Sending => "sending",
    }
}

fn vban_json(o: &mut String, st: &VbanStatus, c: &VbanConfig, sample_rate: u32) {
    let _ = write!(o, "{{\"on\":{},\"port\":{},\"listening\":", c.enabled, c.port);
    match st.listening {
        Some(p) => {
            let _ = write!(o, "{p}");
        }
        None => o.push_str("null"),
    }
    o.push_str(",\"error\":");
    jopt(o, if c.enabled { st.error.as_deref() } else { None });
    o.push_str(",\"in\":[");
    for (k, s) in c.ins.iter().enumerate() {
        if k > 0 {
            o.push(',');
        }
        let t = &st.ins[k];
        let _ = write!(o, "{{\"on\":{},\"name\":", s.on);
        jstr(o, &s.name);
        o.push_str(",\"from\":");
        jstr(o, &s.from.as_string());
        let _ = write!(o, ",\"strip\":{},\"buffer\":{},\"state\":\"{}\",\"text\":", s.strip, s.buffer_ms, in_state(t.state));
        jstr(o, &t.describe(s));
        let _ = write!(o, ",\"lost\":{},\"dropouts\":{},\"ppm\":", t.lost, t.underruns);
        jnum(o, t.clock_ppm as f64, 1);
        o.push('}');
    }
    o.push_str("],\"out\":[");
    for (k, s) in c.outs.iter().enumerate() {
        if k > 0 {
            o.push(',');
        }
        let t = &st.outs[k];
        let _ = write!(o, "{{\"on\":{},\"name\":", s.on);
        jstr(o, &s.name);
        o.push_str(",\"to\":");
        jstr(o, &s.to.map_or(String::new(), |ip| ip.to_string()));
        let _ = write!(
            o,
            ",\"port\":{},\"src\":{},\"format\":\"{}\",\"channels\":{},\"state\":\"{}\",\"text\":",
            s.port,
            s.source,
            s.format.as_str(),
            s.channels,
            out_state(t.state)
        );
        jstr(o, &t.describe(s, sample_rate));
        let _ = write!(o, ",\"packets\":{},\"errors\":{}}}", t.packets, t.errors);
    }
    o.push_str("],\"seen\":[");
    for (k, s) in st.seen.iter().enumerate() {
        if k > 0 {
            o.push(',');
        }
        o.push_str("{\"name\":");
        jstr(o, &s.name);
        o.push_str(",\"from\":");
        jstr(o, &s.from.ip().to_string());
        let _ = write!(o, ",\"sr\":{},\"ch\":{},\"format\":", s.sample_rate, s.channels);
        jstr(o, s.format.label());
        o.push('}');
    }
    o.push_str("]}");
}

pub fn state_json(sh: &Shared, f: &Frame) -> String {
    use std::sync::atomic::Ordering::Relaxed;
    let i = f.info;
    let mut o = String::with_capacity(4096);
    let period = if i.sample_rate > 0 { i.buffer_size as f64 * 1000.0 / i.sample_rate as f64 } else { 0.0 };
    let measured = i.sample_rate > 0 && (i.lat_in > 0 || i.lat_out > 0);
    let rtt = if measured { (i.lat_in + i.lat_out) as f64 * 1000.0 / i.sample_rate as f64 } else { 2.0 * period };
    o.push_str("{\"client\":");
    jstr(&mut o, i.client);
    let _ = write!(o, ",\"sr\":{},\"bs\":{},\"period\":", i.sample_rate, i.buffer_size);
    jnum(&mut o, period, 2);
    o.push_str(",\"rtt\":");
    jnum(&mut o, rtt, 2);
    let _ = write!(o, ",\"measured\":{measured},\"cpu\":");
    jnum(&mut o, i.cpu as f64, 1);
    let _ = write!(o, ",\"xruns\":{},\"oversize\":{},\"cables\":{},\"status\":", i.xruns, i.oversize, i.cables);
    jstr(&mut o, &plain(f.status));
    let any_solo = sh.strips.iter().any(|s| s.solo.load(Relaxed));
    let links = sh.rec_links.load(Relaxed);
    let _ = write!(o, ",\"anySolo\":{any_solo},\"ch\":[");
    for r in 0..ROWS {
        if r > 0 {
            o.push(',');
        }
        let strip = r < NUM_STRIPS;
        let (name, gain, mute, mono) = if strip {
            let p = &sh.strips[r];
            (&f.cfg.strips[r].name, p.gain_db.load(), p.mute.load(Relaxed), p.mono.load(Relaxed))
        } else {
            let p = &sh.buses[r - NUM_STRIPS];
            (&f.cfg.buses[r - NUM_STRIPS].name, p.gain_db.load(), p.mute.load(Relaxed), p.mono.load(Relaxed))
        };
        o.push_str("{\"id\":");
        jstr(&mut o, recorder::source_id(r));
        o.push_str(",\"name\":");
        jstr(&mut o, name);
        let _ = write!(o, ",\"strip\":{strip},\"gain\":");
        jnum(&mut o, gain as f64, 1);
        let _ = write!(o, ",\"mute\":{mute},\"mono\":{mono},\"link\":{}", links & (1 << r) != 0);
        if strip {
            let p = &sh.strips[r];
            let _ = write!(o, ",\"solo\":{},\"routes\":{}", p.solo.load(Relaxed), p.routes.load(Relaxed));
        }
        o.push_str(",\"m\":[");
        jnum(&mut o, f.meters[r][0] as f64, 1);
        o.push(',');
        jnum(&mut o, f.meters[r][1] as f64, 1);
        o.push_str("],\"conn\":");
        jstr(&mut o, f.conn.get(r).map_or("", String::as_str));
        // (last, so a naive reader of the fields above still finds them
        // before the first closing brace)
        let e = sh.eq(r);
        let _ = write!(o, ",\"eq\":{{\"on\":{},\"b\":[", e.on.load(Relaxed));
        for (k, b) in e.bands().iter().enumerate() {
            if k > 0 {
                o.push(',');
            }
            let _ = write!(o, "[{},\"{}\",", u8::from(b.on), b.kind.as_str());
            jnum(&mut o, b.freq as f64, 0);
            o.push(',');
            jnum(&mut o, b.gain_db as f64, 1);
            o.push(',');
            jnum(&mut o, b.q as f64, 2);
            o.push(']');
        }
        o.push_str("]}}");
    }
    let st = f.rec;
    let s = f.rec_settings;
    let _ = write!(o, "],\"rec\":{{\"on\":{},\"takeMode\":\"{}\",\"mode\":\"{}\",\"format\":\"{}\",\"folder\":", st.on, st.mode.as_str(), s.mode.as_str(), s.format.as_str());
    jstr(&mut o, &s.folder);
    o.push_str(",\"path\":");
    jstr(&mut o, &recorder::expand_home(&s.folder).display().to_string());
    o.push_str(",\"secs\":");
    jnum(&mut o, st.seconds(), 2);
    let _ = write!(o, ",\"dropped\":{},\"clipped\":{},\"files\":[", st.dropped, st.clipped);
    for (k, p) in st.files.iter().enumerate() {
        if k > 0 {
            o.push(',');
        }
        jstr(&mut o, &p.display().to_string());
    }
    o.push_str("],\"error\":");
    match &st.error {
        Some(e) => jstr(&mut o, e),
        None => o.push_str("null"),
    }
    o.push_str("},\"vban\":");
    vban_json(&mut o, f.vban, f.vban_cfg, i.sample_rate);
    o.push('}');
    o
}

// ---------------------------------------------------------------------------
// Commands
// ---------------------------------------------------------------------------

fn hex(b: u8) -> Option<u8> {
    match b {
        b'0'..=b'9' => Some(b - b'0'),
        b'a'..=b'f' => Some(b - b'a' + 10),
        b'A'..=b'F' => Some(b - b'A' + 10),
        _ => None,
    }
}

fn url_decode(s: &str) -> Option<String> {
    let b = s.as_bytes();
    let mut out = Vec::with_capacity(b.len());
    let mut i = 0;
    while i < b.len() {
        match b[i] {
            b'+' => out.push(b' '),
            b'%' => {
                let (h, l) = (hex(*b.get(i + 1)?)?, hex(*b.get(i + 2)?)?);
                out.push(h << 4 | l);
                i += 2;
            }
            c => out.push(c),
        }
        i += 1;
    }
    String::from_utf8(out).ok()
}

/// `application/x-www-form-urlencoded` body -> key/value pairs.
pub fn parse_form(body: &str) -> Result<Vec<(String, String)>, String> {
    body.split('&')
        .filter(|kv| !kv.is_empty())
        .map(|kv| {
            let (k, v) = kv.split_once('=').unwrap_or((kv, ""));
            match (url_decode(k), url_decode(v)) {
                (Some(k), Some(v)) => Ok((k, v)),
                _ => Err("malformed form data".to_string()),
            }
        })
        .collect()
}

struct Form(Vec<(String, String)>);

impl Form {
    fn get(&self, k: &str) -> Option<&str> {
        self.0.iter().find(|(key, _)| key == k).map(|(_, v)| v.as_str())
    }
    fn req(&self, k: &str) -> Result<&str, String> {
        self.get(k).ok_or_else(|| format!("missing {k:?}"))
    }
    fn flag(&self) -> Result<bool, String> {
        match self.req("v")? {
            "1" | "true" | "on" => Ok(true),
            "0" | "false" | "off" => Ok(false),
            v => Err(format!("expected 0 or 1, got {v:?}")),
        }
    }
    fn ch(&self) -> Result<usize, String> {
        self.req("ch")?.parse::<usize>().ok().filter(|&c| c < NUM_SOURCES).ok_or_else(|| "bad channel".into())
    }
    fn index(&self, k: &str, n: usize) -> Result<usize, String> {
        self.req(k)?.parse::<usize>().ok().filter(|&i| i < n).ok_or_else(|| format!("bad {k}"))
    }
    fn bool_of(&self, k: &str) -> Result<Option<bool>, String> {
        match self.get(k) {
            None => Ok(None),
            Some("1" | "true" | "on") => Ok(Some(true)),
            Some("0" | "false" | "off") => Ok(Some(false)),
            Some(v) => Err(format!("{k}: expected 0 or 1, got {v:?}")),
        }
    }
    fn num_of(&self, k: &str, what: &str, lo: f32, hi: f32) -> Result<Option<f32>, String> {
        let Some(v) = self.get(k) else { return Ok(None) };
        let x: f32 = v.trim().parse().map_err(|_| format!("{what} must be a number"))?;
        if !x.is_finite() || x < lo || x > hi {
            return Err(format!("{what} must be {lo} to {hi}"));
        }
        Ok(Some(x))
    }
}

/// `on`, `name` and the other fields of a VBAN stream form, checked.
fn vban_name(f: &Form) -> Result<Option<String>, String> {
    f.get("name")
        .map(|v| {
            let v = v.trim();
            vban::proto::validate_name(v).map(|_| v.to_string())
        })
        .transpose()
}

fn set_bit_u8(a: &std::sync::atomic::AtomicU8, bit: usize, on: bool) {
    if on { a.fetch_or(1 << bit, SeqCst) } else { a.fetch_and(!(1u8 << bit), SeqCst) };
}

/// Apply one control change. Returns a short message for the page.
pub fn command(hub: &Hub, body: &str) -> Result<String, String> {
    let f = Form(parse_form(body)?);
    let sh = &*hub.shared;
    let op = f.req("op")?;
    match op {
        "gain" => {
            let c = f.ch()?;
            let v: f32 = f.req("v")?.parse().map_err(|_| "gain must be a number")?;
            if !v.is_finite() {
                return Err("gain must be finite".into());
            }
            let v = clamp_db((v * 10.0).round() / 10.0);
            if c < NUM_STRIPS { sh.strips[c].gain_db.store(v) } else { sh.buses[c - NUM_STRIPS].gain_db.store(v) }
            Ok(format!("{v:+.1} dB"))
        }
        "mute" | "mono" => {
            let (c, on) = (f.ch()?, f.flag()?);
            let a = match (op, c < NUM_STRIPS) {
                ("mute", true) => &sh.strips[c].mute,
                ("mute", false) => &sh.buses[c - NUM_STRIPS].mute,
                (_, true) => &sh.strips[c].mono,
                (_, false) => &sh.buses[c - NUM_STRIPS].mono,
            };
            a.store(on, SeqCst);
            Ok("ok".into())
        }
        "solo" => {
            let c = f.ch()?;
            if c >= NUM_STRIPS {
                return Err("buses have no solo".into());
            }
            sh.strips[c].solo.store(f.flag()?, SeqCst);
            Ok("ok".into())
        }
        "route" => {
            let c = f.ch()?;
            if c >= NUM_STRIPS {
                return Err("only strips are routed".into());
            }
            let b: usize = f.req("bus")?.parse().ok().filter(|&b| b < NUM_BUSES).ok_or("bad bus")?;
            set_bit_u8(&sh.strips[c].routes, b, f.flag()?);
            Ok("ok".into())
        }
        "link" => {
            let (c, on) = (f.ch()?, f.flag()?);
            if on { sh.rec_links.fetch_or(1 << c, SeqCst) } else { sh.rec_links.fetch_and(!(1u16 << c), SeqCst) };
            Ok("ok".into())
        }
        "rec" => {
            let rec = &hub.recorder;
            if f.flag()? {
                let names = lock(&hub.names).clone();
                let files = rec.start(sh.rec_links.load(SeqCst) & ALL_LINKS, &names, &crate::sys::local_timestamp())?;
                Ok(match files.len() {
                    1 => format!("recording to {}", files[0].display()),
                    n => format!("recording {n} tracks to {}", files[0].parent().map_or(String::new(), |p| p.display().to_string())),
                })
            } else {
                rec.stop();
                Ok("recording stopped".into())
            }
        }
        "recset" => {
            let rec = &hub.recorder;
            let mut s = rec.settings();
            if let Some(m) = f.get("mode") {
                s.mode = Mode::parse(m)?;
            }
            if let Some(fm) = f.get("format") {
                s.format = Format::parse(fm)?;
            }
            if let Some(d) = f.get("folder") {
                s.folder = d.trim().to_string();
            }
            rec.set_settings(s)?;
            Ok(if rec.is_recording() { "applies to the next recording".into() } else { "ok".into() })
        }
        "name" => {
            let c = f.ch()?;
            let v = f.req("v")?.trim();
            if v.is_empty() || v.chars().count() > MAX_NAME || v.chars().any(char::is_control) {
                return Err(format!("names are 1-{MAX_NAME} characters"));
            }
            hub.request(Request::Rename(c, v.to_string()));
            Ok("ok".into())
        }
        "eq" => {
            let (c, on) = (f.ch()?, f.flag()?);
            sh.eq(c).on.store(on, SeqCst);
            Ok(if on { "EQ on" } else { "EQ off" }.into())
        }
        "band" => {
            let c = f.ch()?;
            let k = f.index("band", BANDS)?;
            let p = &sh.eq(c).bands[k];
            let mut b = p.load();
            if let Some(on) = f.bool_of("on")? {
                b.on = on;
            }
            if let Some(t) = f.get("type") {
                b.kind = Kind::parse(t)?;
            }
            if let Some(v) = f.num_of("f", "frequency", eq::MIN_FREQ, eq::MAX_FREQ)? {
                b.freq = eq::round_freq(v);
            }
            if let Some(v) = f.num_of("g", "gain", eq::MIN_GAIN_DB, eq::MAX_GAIN_DB)? {
                b.gain_db = eq::round_gain(v);
            }
            if let Some(v) = f.num_of("q", "Q", eq::MIN_Q, eq::MAX_Q)? {
                b.q = eq::round_q(v);
            }
            p.store(&b);
            Ok("ok".into())
        }
        "eqreset" => {
            let c = f.ch()?;
            sh.eq(c).store_bands(&DEFAULT_BANDS);
            Ok("EQ bands reset (flat)".into())
        }
        "vban" => {
            let on = f.flag()?;
            hub.vban.update(|c| {
                c.enabled = on;
                Ok(())
            })?;
            Ok(if on { "VBAN on" } else { "VBAN off" }.into())
        }
        "vbanport" => {
            let port = vban::parse_port(f.req("v")?)?;
            hub.vban.update(|c| {
                c.port = port;
                Ok(())
            })?;
            Ok(format!("VBAN listens on UDP port {port}"))
        }
        "vbanin" => {
            let k = f.index("slot", NUM_IN)?;
            let name = vban_name(&f)?;
            let from = f.get("from").map(FromAddr::parse).transpose()?;
            let strip = f.get("strip").map(vban::parse_strip).transpose()?;
            let buffer = f.get("buffer").map(vban::parse_buffer_ms).transpose()?;
            let on = f.bool_of("on")?;
            hub.vban.update(|c| {
                let s = &mut c.ins[k];
                if let Some(v) = name {
                    s.name = v;
                }
                if let Some(v) = from {
                    s.from = v;
                }
                if let Some(v) = strip {
                    s.strip = v;
                }
                if let Some(v) = buffer {
                    s.buffer_ms = v;
                }
                if let Some(v) = on {
                    s.on = v;
                }
                Ok(())
            })?;
            Ok("ok".into())
        }
        "vbanout" => {
            let k = f.index("slot", NUM_OUT)?;
            let name = vban_name(&f)?;
            let to = f.get("to").map(vban::parse_to).transpose()?;
            let port = f.get("port").map(vban::parse_port).transpose()?;
            let src = f.get("src").map(vban::parse_source).transpose()?;
            let format = f.get("format").map(SampleFormat::parse_send).transpose()?;
            let channels = f.get("channels").map(vban::parse_channels).transpose()?;
            let on = f.bool_of("on")?;
            hub.vban.update(|c| {
                let s = &mut c.outs[k];
                if let Some(v) = name {
                    s.name = v;
                }
                if let Some(v) = to {
                    s.to = v;
                }
                if let Some(v) = port {
                    s.port = v;
                }
                if let Some(v) = src {
                    s.source = v;
                }
                if let Some(v) = format {
                    s.format = v;
                }
                if let Some(v) = channels {
                    s.channels = v;
                }
                if let Some(v) = on {
                    s.on = v;
                }
                Ok(())
            })?;
            Ok("ok".into())
        }
        "save" => {
            hub.request(Request::Save);
            Ok("saving".into())
        }
        "reconnect" => {
            hub.request(Request::Reconnect);
            Ok("reconnecting".into())
        }
        "quit" => {
            hub.request(Request::Quit);
            Ok("quitting".into())
        }
        _ => Err(format!("unknown op {op:?}")),
    }
}

// ---------------------------------------------------------------------------
// HTTP
// ---------------------------------------------------------------------------

#[derive(Debug)]
pub struct Req {
    pub method: String,
    pub path: String,
    headers: Vec<(String, String)>,
    pub body: Vec<u8>,
}

impl Req {
    fn header(&self, name: &str) -> Option<&str> {
        self.headers.iter().find(|(k, _)| k == name).map(|(_, v)| v.as_str())
    }
}

/// Read one request. Errors are (status, message).
pub fn read_request(s: &mut impl Read) -> Result<Req, (u16, &'static str)> {
    let mut buf = Vec::with_capacity(2048);
    let mut tmp = [0u8; 4096];
    let head_end = loop {
        if let Some(p) = buf.windows(4).position(|w| w == b"\r\n\r\n") {
            break p;
        }
        if buf.len() > MAX_HEAD {
            return Err((431, "request header too large"));
        }
        let n = s.read(&mut tmp).map_err(|_| (408, "request timeout"))?;
        if n == 0 {
            return Err((400, "incomplete request"));
        }
        buf.extend_from_slice(&tmp[..n]);
    };
    if head_end > MAX_HEAD {
        return Err((431, "request header too large"));
    }
    let head = std::str::from_utf8(&buf[..head_end]).map_err(|_| (400, "bad request"))?;
    let mut lines = head.split("\r\n");
    let mut first = lines.next().unwrap_or("").split(' ');
    let (method, target, version) = (first.next().unwrap_or(""), first.next().unwrap_or(""), first.next().unwrap_or(""));
    if method.is_empty() || !target.starts_with('/') || !version.starts_with("HTTP/1.") || first.next().is_some() {
        return Err((400, "bad request line"));
    }
    let mut headers = Vec::new();
    for line in lines {
        let (k, v) = line.split_once(':').ok_or((400, "bad header"))?;
        headers.push((k.trim().to_ascii_lowercase(), v.trim().to_string()));
    }
    let mut req = Req {
        method: method.to_string(),
        path: target.split('?').next().unwrap_or("/").to_string(),
        headers,
        body: Vec::new(),
    };
    if req.header("transfer-encoding").is_some() {
        return Err((411, "send a Content-Length"));
    }
    let len = match req.header("content-length") {
        None => 0,
        Some(v) => v.parse::<usize>().map_err(|_| (400, "bad Content-Length"))?,
    };
    if len > MAX_BODY {
        return Err((413, "request body too large"));
    }
    let mut body = buf[head_end + 4..].to_vec();
    while body.len() < len {
        let n = s.read(&mut tmp).map_err(|_| (408, "request timeout"))?;
        if n == 0 {
            return Err((400, "incomplete body"));
        }
        body.extend_from_slice(&tmp[..n]);
    }
    body.truncate(len);
    req.body = body;
    Ok(req)
}

fn origins(port: u16) -> [String; 3] {
    [format!("127.0.0.1:{port}"), format!("localhost:{port}"), format!("[::1]:{port}")]
}

/// The request was addressed to this server (not a rebound DNS name).
pub fn host_ok(req: &Req, port: u16) -> bool {
    req.header("host").is_some_and(|h| origins(port).iter().any(|o| o.eq_ignore_ascii_case(h)))
}

/// A state-changing request comes from our own page.
pub fn csrf_ok(req: &Req, port: u16) -> bool {
    if req.header("x-vmix") != Some("1") {
        return false;
    }
    if req.header("sec-fetch-site").is_some_and(|v| v.eq_ignore_ascii_case("cross-site")) {
        return false;
    }
    match req.header("origin") {
        None => true,
        Some(o) => origins(port).iter().any(|h| o.eq_ignore_ascii_case(&format!("http://{h}"))),
    }
}

fn reason(code: u16) -> &'static str {
    match code {
        200 => "OK",
        400 => "Bad Request",
        403 => "Forbidden",
        404 => "Not Found",
        405 => "Method Not Allowed",
        408 => "Request Timeout",
        411 => "Length Required",
        413 => "Payload Too Large",
        431 => "Request Header Fields Too Large",
        503 => "Service Unavailable",
        _ => "Error",
    }
}

fn respond(s: &mut TcpStream, code: u16, ctype: &str, body: &[u8], extra: &str) {
    let head = format!(
        "HTTP/1.1 {code} {}\r\nContent-Type: {ctype}\r\nContent-Length: {}\r\nCache-Control: no-store\r\n\
         X-Content-Type-Options: nosniff\r\nConnection: close\r\n{extra}\r\n",
        reason(code),
        body.len()
    );
    let _ = s.write_all(head.as_bytes());
    let _ = s.write_all(body);
    let _ = s.flush();
    let _ = s.shutdown(Shutdown::Write);
}

const PAGE_HEADERS: &str = "Content-Security-Policy: default-src 'none'; script-src 'unsafe-inline'; \
style-src 'unsafe-inline'; connect-src 'self'; img-src data:; base-uri 'none'; form-action 'none'; \
frame-ancestors 'none'\r\nX-Frame-Options: DENY\r\nReferrer-Policy: no-referrer\r\n";

fn handle(mut s: TcpStream, hub: &Hub, port: u16) {
    let _ = s.set_read_timeout(Some(Duration::from_secs(5)));
    let _ = s.set_write_timeout(Some(Duration::from_secs(5)));
    let req = match read_request(&mut s) {
        Ok(r) => r,
        Err((code, msg)) => return respond(&mut s, code, "text/plain; charset=utf-8", msg.as_bytes(), ""),
    };
    if !host_ok(&req, port) {
        return respond(&mut s, 403, "text/plain; charset=utf-8", b"wrong Host", "");
    }
    let text = "text/plain; charset=utf-8";
    match (req.method.as_str(), req.path.as_str()) {
        ("GET", "/") | ("GET", "/index.html") => {
            respond(&mut s, 200, "text/html; charset=utf-8", PAGE.as_bytes(), PAGE_HEADERS)
        }
        ("GET", "/api/ping") => respond(&mut s, 200, text, b"vmix-gui", ""),
        ("GET", "/api/state") => {
            let json = lock(&hub.state).1.clone();
            respond(&mut s, 200, "application/json", json.as_bytes(), "")
        }
        ("GET", "/api/events") => stream(s, hub),
        ("POST", "/api/cmd") => {
            if !csrf_ok(&req, port) {
                return respond(&mut s, 403, text, b"forbidden", "");
            }
            let Ok(body) = std::str::from_utf8(&req.body) else {
                return respond(&mut s, 400, text, b"body is not UTF-8", "");
            };
            match command(hub, body) {
                Ok(m) => respond(&mut s, 200, text, m.as_bytes(), ""),
                Err(e) => respond(&mut s, 400, text, e.as_bytes(), ""),
            }
        }
        ("GET", _) | ("POST", _) => respond(&mut s, 404, text, b"not found", ""),
        _ => respond(&mut s, 405, text, b"method not allowed", "Allow: GET, POST\r\n"),
    }
}

struct Count<'a>(&'a AtomicUsize);
impl Drop for Count<'_> {
    fn drop(&mut self) {
        self.0.fetch_sub(1, SeqCst);
    }
}

fn stream(mut s: TcpStream, hub: &Hub) {
    if hub.streams.fetch_add(1, SeqCst) >= MAX_STREAMS {
        hub.streams.fetch_sub(1, SeqCst);
        return respond(&mut s, 503, "text/plain", b"too many windows open", "");
    }
    let _count = Count(&hub.streams);
    let head = "HTTP/1.1 200 OK\r\nContent-Type: text/event-stream\r\nCache-Control: no-store\r\n\
                X-Content-Type-Options: nosniff\r\nConnection: keep-alive\r\n\r\nretry: 1000\n\n";
    if s.write_all(head.as_bytes()).is_err() {
        return;
    }
    let mut last = u64::MAX;
    loop {
        let (seq, json) = {
            let g = lock(&hub.state);
            let (g, _) = hub
                .cond
                .wait_timeout_while(g, Duration::from_secs(1), |st| st.0 == last && !hub.closing.load(SeqCst))
                .unwrap_or_else(|e| e.into_inner());
            (g.0, g.1.clone())
        };
        if hub.closing.load(SeqCst) {
            break;
        }
        let msg = if seq != last {
            last = seq;
            format!("data: {json}\n\n")
        } else {
            ": ping\n\n".to_string()
        };
        if s.write_all(msg.as_bytes()).is_err() {
            break;
        }
    }
}

/// Listen on 127.0.0.1:`port` (if it is busy and was not asked for
/// explicitly, on a free port instead). Returns the port in use.
pub fn start(hub: Arc<Hub>, port: u16, explicit: bool) -> Result<u16, String> {
    let listener = match TcpListener::bind((Ipv4Addr::LOCALHOST, port)) {
        Ok(l) => l,
        Err(e) if !explicit && e.kind() == std::io::ErrorKind::AddrInUse => TcpListener::bind((Ipv4Addr::LOCALHOST, 0))
            .map_err(|e| format!("cannot open a port for the GUI: {e}"))?,
        Err(e) => return Err(format!("cannot listen on 127.0.0.1:{port} for the GUI: {e}")),
    };
    let port = listener.local_addr().map_err(|e| e.to_string())?.port();
    std::thread::Builder::new()
        .name("vmix-gui".into())
        .spawn(move || accept_loop(&listener, &hub, port))
        .map_err(|e| format!("cannot start the GUI thread: {e}"))?;
    Ok(port)
}

fn accept_loop(l: &TcpListener, hub: &Arc<Hub>, port: u16) {
    for conn in l.incoming() {
        if hub.closing.load(SeqCst) {
            break;
        }
        let Ok(mut s) = conn else {
            std::thread::sleep(Duration::from_millis(20)); // e.g. out of file descriptors
            continue;
        };
        if hub.conns.fetch_add(1, SeqCst) >= MAX_CONNS {
            hub.conns.fetch_sub(1, SeqCst);
            respond(&mut s, 503, "text/plain", b"busy", "");
            continue;
        }
        let h = hub.clone();
        let spawned = std::thread::Builder::new().name("vmix-gui-conn".into()).spawn(move || {
            let _count = Count(&h.conns);
            handle(s, &h, port);
        });
        if spawned.is_err() {
            hub.conns.fetch_sub(1, SeqCst);
        }
    }
}

pub fn url(port: u16) -> String {
    format!("http://127.0.0.1:{port}/")
}

/// Is a vmix GUI already answering on this port?
pub fn probe(port: u16) -> bool {
    let addr = SocketAddr::from((Ipv4Addr::LOCALHOST, port));
    let Ok(mut s) = TcpStream::connect_timeout(&addr, Duration::from_millis(300)) else { return false };
    let _ = s.set_read_timeout(Some(Duration::from_millis(800)));
    let _ = s.set_write_timeout(Some(Duration::from_millis(800)));
    let req = format!("GET /api/ping HTTP/1.1\r\nHost: 127.0.0.1:{port}\r\nConnection: close\r\n\r\n");
    if s.write_all(req.as_bytes()).is_err() {
        return false;
    }
    let mut buf = Vec::new();
    let _ = s.take(4096).read_to_end(&mut buf);
    buf.starts_with(b"HTTP/1.1 200") && buf.ends_with(b"\r\n\r\nvmix-gui")
}

/// Open the page in its own app window (Chromium-family `--app` mode), or
/// in the default browser. Returns false if nothing could be started.
pub fn open_window(url: &str) -> bool {
    if std::env::var_os("DISPLAY").is_none() && std::env::var_os("WAYLAND_DISPLAY").is_none() {
        return false;
    }
    let app = format!("--app={url}");
    let browsers = [
        "chromium",
        "chromium-browser",
        "google-chrome",
        "google-chrome-stable",
        "brave-browser",
        "brave",
        "microsoft-edge",
        "vivaldi",
    ];
    let mut tries: Vec<(&str, &str)> = browsers.iter().map(|b| (*b, app.as_str())).collect();
    tries.push(("xdg-open", url));
    for (bin, arg) in tries {
        let child = Command::new(bin)
            .arg(arg)
            .stdin(Stdio::null())
            .stdout(Stdio::null())
            .stderr(Stdio::null())
            .process_group(0) // not killed by the terminal's Ctrl-C
            .spawn();
        if let Ok(mut child) = child {
            std::thread::spawn(move || {
                let _ = child.wait(); // reap it
            });
            return true;
        }
    }
    false
}

// The page hard-codes the fader range and the channel layout.
const _: () = assert!(MIN_GAIN_DB == -60.0 && MAX_GAIN_DB == 12.0, "gui.html assumes -60..+12 dB");
const _: () = assert!(NUM_STRIPS == 6 && NUM_BUSES == 5, "gui.html assumes 6 strips and 5 buses");

#[cfg(test)]
mod tests {
    use super::*;
    use std::sync::atomic::Ordering::Relaxed;
    use vmix::recorder::RecTap;

    fn hub() -> Arc<Hub> {
        let dir = std::env::temp_dir().join(format!("vmix-gui-test-{}", std::process::id()));
        let rec = Recorder::new(
            RecTap::new(),
            48000,
            Settings { folder: dir.display().to_string(), ..Settings::default() },
        );
        let vban = Vban::start(vmix::vban::VbanTap::new(), 48000, VbanConfig::default());
        Hub::new(Shared::new(), Arc::new(rec), Arc::new(vban))
    }

    fn req(raw: &str) -> Result<Req, (u16, &'static str)> {
        read_request(&mut raw.as_bytes())
    }

    #[test]
    fn form_and_url_decoding() {
        let f = parse_form("op=name&ch=2&v=Voice+%26+Chat%21&x=").unwrap();
        assert_eq!(f[2], ("v".into(), "Voice & Chat!".into()));
        assert_eq!(f[3], ("x".into(), String::new()));
        assert!(parse_form("v=%zz").is_err());
        assert!(parse_form("v=%e2%82").is_err(), "invalid UTF-8");
        assert_eq!(parse_form("").unwrap(), vec![]);
    }

    #[test]
    fn request_parsing_and_limits() {
        let r = req("POST /api/cmd?x=1 HTTP/1.1\r\nHost: 127.0.0.1:8790\r\nContent-Length: 5\r\n\r\nop=sx").unwrap();
        assert_eq!((r.method.as_str(), r.path.as_str(), r.body.as_slice()), ("POST", "/api/cmd", &b"op=sx"[..]));
        assert_eq!(r.header("host"), Some("127.0.0.1:8790"));
        assert_eq!(req("GET / HTTP/1.1\r\nHost: x").unwrap_err().0, 400, "incomplete");
        assert_eq!(req("GARBAGE\r\n\r\n").unwrap_err().0, 400);
        assert_eq!(req("GET / HTTP/1.1\r\nContent-Length: 99999999\r\n\r\n").unwrap_err().0, 413);
        assert_eq!(req("POST / HTTP/1.1\r\nTransfer-Encoding: chunked\r\n\r\n").unwrap_err().0, 411);
        let big = format!("GET / HTTP/1.1\r\nX: {}\r\n\r\n", "a".repeat(MAX_HEAD + 10));
        assert_eq!(req(&big).unwrap_err().0, 431);
    }

    #[test]
    fn host_and_csrf_checks() {
        let ok = req("POST /api/cmd HTTP/1.1\r\nHost: localhost:8790\r\nX-Vmix: 1\r\nOrigin: http://localhost:8790\r\n\r\n")
            .unwrap();
        assert!(host_ok(&ok, 8790) && csrf_ok(&ok, 8790));
        assert!(!host_ok(&ok, 8791));
        let rebound = req("GET / HTTP/1.1\r\nHost: evil.example:8790\r\n\r\n").unwrap();
        assert!(!host_ok(&rebound, 8790));
        let no_header = req("POST /api/cmd HTTP/1.1\r\nHost: 127.0.0.1:8790\r\n\r\n").unwrap();
        assert!(!csrf_ok(&no_header, 8790));
        let foreign =
            req("POST /api/cmd HTTP/1.1\r\nHost: 127.0.0.1:8790\r\nX-Vmix: 1\r\nOrigin: https://evil.example\r\n\r\n")
                .unwrap();
        assert!(!csrf_ok(&foreign, 8790));
        let cross = req("POST /api/cmd HTTP/1.1\r\nHost: 127.0.0.1:8790\r\nX-Vmix: 1\r\nSec-Fetch-Site: cross-site\r\n\r\n")
            .unwrap();
        assert!(!csrf_ok(&cross, 8790));
    }

    #[test]
    fn commands_change_shared_state() {
        let h = hub();
        let sh = &h.shared;
        assert_eq!(command(&h, "op=gain&ch=0&v=-3.04").unwrap(), "-3.0 dB");
        assert_eq!(sh.strips[0].gain_db.load(), -3.0);
        command(&h, "op=gain&ch=10&v=99").unwrap();
        assert_eq!(sh.buses[4].gain_db.load(), MAX_GAIN_DB);
        assert!(command(&h, "op=gain&ch=0&v=NaN").is_err());
        assert!(command(&h, "op=gain&ch=11&v=0").is_err());
        command(&h, "op=mute&ch=7&v=1").unwrap();
        assert!(sh.buses[1].mute.load(Relaxed));
        command(&h, "op=mono&ch=2&v=1").unwrap();
        assert!(sh.strips[2].mono.load(Relaxed));
        command(&h, "op=solo&ch=5&v=1").unwrap();
        assert!(sh.strips[5].solo.load(Relaxed));
        assert!(command(&h, "op=solo&ch=6&v=1").is_err(), "no solo on buses");
        command(&h, "op=route&ch=1&bus=3&v=1").unwrap();
        command(&h, "op=route&ch=1&bus=0&v=1").unwrap();
        command(&h, "op=route&ch=1&bus=0&v=1").unwrap(); // idempotent, not a toggle
        assert_eq!(sh.strips[1].routes.load(Relaxed), 0b01001);
        command(&h, "op=route&ch=1&bus=3&v=0").unwrap();
        assert_eq!(sh.strips[1].routes.load(Relaxed), 0b00001);
        assert!(command(&h, "op=route&ch=1&bus=5&v=1").is_err());
        command(&h, "op=link&ch=0&v=1").unwrap();
        command(&h, "op=link&ch=9&v=1").unwrap();
        assert_eq!(sh.rec_links.load(Relaxed), (1 << 9) | 1);
        command(&h, "op=link&ch=0&v=0").unwrap();
        assert_eq!(sh.rec_links.load(Relaxed), 1 << 9);
        command(&h, "op=recset&mode=multi&format=wav32f&folder=+%2Ftmp%2Fx+").unwrap();
        let s = h.recorder.settings();
        assert_eq!((s.mode, s.format, s.folder.as_str()), (Mode::Multi, Format::Wav32f, "/tmp/x"));
        assert!(command(&h, "op=recset&format=ogg").is_err());
        assert!(command(&h, "op=name&ch=3&v=").is_err());
        assert!(command(&h, "op=name&ch=3&v=a%0Ab").is_err());
        command(&h, "op=name&ch=3&v=+Voice+").unwrap();
        // EQ
        command(&h, "op=eq&ch=7&v=1").unwrap();
        assert!(sh.buses[1].eq.on.load(Relaxed));
        command(&h, "op=band&ch=0&band=5&type=lowcut&f=80.4&q=0.707&on=0").unwrap();
        let b = sh.strips[0].eq.bands[5].load();
        assert_eq!((b.kind, b.freq, b.q, b.on, b.gain_db), (Kind::LowCut, 80.0, 0.71, false, 0.0));
        command(&h, "op=band&ch=0&band=5&g=-3.04").unwrap();
        assert_eq!(sh.strips[0].eq.bands[5].load().gain_db, -3.0);
        for bad in ["op=band&ch=0&band=6&g=1", "op=band&ch=0&band=0&g=30", "op=band&ch=0&band=0&f=10", "op=band&ch=0&band=0&q=0", "op=band&ch=0&band=0&type=comb", "op=band&ch=0&band=0&g=NaN", "op=band&ch=11&band=0&g=1", "op=band&ch=0&band=0&on=2"] {
            assert!(command(&h, bad).is_err(), "{bad}");
        }
        command(&h, "op=eqreset&ch=0").unwrap();
        assert_eq!(sh.strips[0].eq.bands(), DEFAULT_BANDS);
        // VBAN
        command(&h, "op=vban&v=1").unwrap();
        command(&h, "op=vbanport&v=6990").unwrap();
        command(&h, "op=vbanin&slot=2&on=1&name=+Voicemeeter+&from=192.168.1.20&strip=4&buffer=20").unwrap();
        command(&h, "op=vbanout&slot=7&on=1&name=Mix&to=192.168.1.255&port=7000&src=B2&format=float32&channels=1").unwrap();
        let c = h.vban.config();
        assert!(c.enabled && c.port == 6990);
        assert_eq!(c.ins[2], vban::InStream { on: true, name: "Voicemeeter".into(), from: FromAddr::Ip([192, 168, 1, 20].into()), strip: 3, buffer_ms: 20 });
        assert_eq!(c.outs[7], vban::OutStream { on: true, name: "Mix".into(), to: Some([192, 168, 1, 255].into()), port: 7000, source: 10, format: SampleFormat::F32, channels: 1 });
        for bad in ["op=vbanin&slot=8&on=1", "op=vbanin&slot=0&name=0123456789abcdefg", "op=vbanin&slot=0&from=1.2.3", "op=vbanin&slot=0&strip=0", "op=vbanin&slot=0&buffer=999", "op=vbanout&slot=0&to=any", "op=vbanout&slot=0&src=C1", "op=vbanout&slot=0&format=mp3", "op=vbanout&slot=0&channels=3", "op=vbanout&slot=0&port=0", "op=vbanport&v=x"] {
            assert!(command(&h, bad).is_err(), "{bad}");
        }
        assert_eq!(h.vban.config(), c, "a rejected change changes nothing");
        command(&h, "op=vbanin&slot=2&from=").unwrap();
        assert_eq!(h.vban.config().ins[2].from, FromAddr::Unset);
        command(&h, "op=vban&v=0").unwrap();
        command(&h, "op=save").unwrap();
        command(&h, "op=quit").unwrap();
        assert_eq!(h.take_requests(), vec![Request::Rename(3, "Voice".into()), Request::Save, Request::Quit]);
        assert!(h.take_requests().is_empty());
        assert!(command(&h, "op=explode").is_err());
        assert!(command(&h, "ch=1").is_err());
    }

    #[test]
    fn record_command_starts_and_stops() {
        let h = hub();
        h.set_names((0..NUM_SOURCES).map(|i| format!("n{i}")).collect());
        let dir = recorder::expand_home(&h.recorder.settings().folder);
        assert!(command(&h, "op=rec&v=1").unwrap_err().contains("link"));
        command(&h, "op=link&ch=6&v=1").unwrap();
        let msg = command(&h, "op=rec&v=1").unwrap();
        assert!(msg.starts_with("recording to ") && msg.ends_with("_mix.wav"), "{msg}");
        assert!(h.recorder.is_recording());
        command(&h, "op=rec&v=0").unwrap();
        assert!(!h.recorder.is_recording());
        h.recorder.shutdown();
        let _ = std::fs::remove_dir_all(dir);
    }

    #[test]
    fn json_is_well_formed_and_escaped() {
        let h = hub();
        let mut cfg = Config::default();
        cfg.strips[0].name = "Mic \"1\" <b>\\".into();
        h.shared.rec_links.store(1, Relaxed);
        h.shared.strips[0].routes.store(0b01000, Relaxed);
        let info = Info {
            client: "vmix",
            sample_rate: 48000,
            buffer_size: 128,
            cpu: f32::NAN,
            xruns: 3,
            oversize: 0,
            lat_in: 128,
            lat_out: 256,
            cables: 8,
            vban: "",
        };
        let meters = [[-60.0f32, -12.5]; ROWS];
        let st = h.recorder.status();
        h.shared.strips[2].eq.on.store(true, Relaxed);
        h.shared.buses[0].eq.bands[3].gain_db.store(-4.5);
        let mut vcfg = VbanConfig { enabled: true, ..VbanConfig::default() };
        vcfg.ins[1].on = true;
        vcfg.ins[1].name = "Voice <1>".into();
        vcfg.outs[0].to = Some([192, 168, 1, 20].into());
        let mut vst = VbanStatus { listening: Some(6980), ..VbanStatus::default() };
        vst.ins[1].state = InState::Waiting;
        vst.seen.push(vban::Seen {
            name: "Stream1".into(),
            from: "10.0.0.2:6980".parse().unwrap(),
            sample_rate: 44100,
            channels: 2,
            format: SampleFormat::I24,
            last: std::time::Instant::now(),
        });
        let json = state_json(
            &h.shared,
            &Frame {
                info: &info,
                cfg: &cfg,
                meters: &meters,
                conn: &["Firefox".into()],
                status: "\x1b[33msaved\x1b[0m\nok",
                rec: &st,
                rec_settings: &h.recorder.settings(),
                vban: &vst,
                vban_cfg: &vcfg,
            },
        );
        assert!(!json.contains('\n'), "one SSE data line");
        let (lt, gt) = (format!("\\u{:04x}", '<' as u32), format!("\\u{:04x}", '>' as u32));
        assert!(json.contains(&format!(r#""name":"Mic \"1\" {lt}b{gt}\\""#)), "{json}");
        assert!(!json.contains('<') && !json.contains('>'));
        assert!(json.contains(r#""status":"saved\nok""#));
        assert!(json.contains(r#""rtt":8.00"#) && json.contains(r#""cpu":0.0"#));
        assert!(json.contains(r#""id":"1","name""#) && json.contains(r#""id":"B2""#));
        assert!(json.contains(r#""link":true,"solo":false,"routes":8,"m":[-60.0,-12.5],"conn":"Firefox","eq":{"on":false,"b":[[1,"lowshelf",100,0.0,0.71],[1,"bell",250,0.0,1.00],"#));
        assert!(json.contains(r#"[1,"highshelf",10000,0.0,0.71]]}},{"id":"2""#));
        assert!(json.contains(r#""id":"3","name":"Desktop","strip":true,"gain":0.0,"mute":false,"mono":false,"link":false,"solo":false,"routes":0,"m":[-60.0,-12.5],"conn":"","eq":{"on":true"#), "{json}");
        assert!(json.contains(r#"[1,"bell",1500,-4.5,1.00]"#));
        assert!(json.contains(r#""rec":{"on":false"#) && json.contains(r#""error":null},"vban":{"on":true,"port":6980,"listening":6980,"error":null,"in":[{"on":false,"name":"Stream1","from":"","strip":5,"buffer":10,"state":"off""#), "{json}");
        let (lt, gt) = (format!("\\u{:04x}", '<' as u32), format!("\\u{:04x}", '>' as u32));
        assert!(json.contains(&format!(r#"{{"on":true,"name":"Voice {lt}1{gt}","from":"","strip":5,"buffer":10,"state":"waiting","text":"waiting for \"Voice {lt}1{gt}\" from any sender""#)), "{json}");
        assert!(json.contains(r#""out":[{"on":false,"name":"Stream1","to":"192.168.1.20","port":6980,"src":9,"format":"int16","channels":2,"state":"off","text":"off""#), "{json}");
        assert!(json.ends_with(r#""seen":[{"name":"Stream1","from":"10.0.0.2","sr":44100,"ch":2,"format":"24-bit"}]}}"#), "{json}");
        // balanced brackets outside strings
        let (mut depth, mut in_str, mut esc) = (0i32, false, false);
        for c in json.chars() {
            match (in_str, esc, c) {
                (true, true, _) => esc = false,
                (true, false, '\\') => esc = true,
                (true, false, '"') => in_str = false,
                (false, _, '"') => in_str = true,
                (false, _, '{' | '[') => depth += 1,
                (false, _, '}' | ']') => depth -= 1,
                _ => {}
            }
            assert!(depth >= 0);
        }
        assert_eq!(depth, 0);
        assert!(!in_str);
    }

    #[test]
    fn page_is_self_contained() {
        assert!(PAGE.starts_with("<!doctype html>"));
        // no external resources: everything works offline and under the CSP
        for bad in ["http://", "https://", "<link", "src=\""] {
            assert!(!PAGE.contains(bad), "page references {bad}");
        }
        assert!(PAGE.contains("X-Vmix"));
        assert!(PAGE.contains("/api/events"));
    }

    #[test]
    fn plain_strips_ansi() {
        assert_eq!(plain("\x1b[31;1msave failed\x1b[0m: x"), "save failed: x");
    }

    #[test]
    fn server_round_trip() {
        let h = hub();
        let port = start(h.clone(), 0, true).unwrap();
        assert!(port > 0);
        assert!(probe(port));
        h.publish("{\"x\":1}".into());
        let get = |path: &str, extra: &str| -> String {
            let mut s = TcpStream::connect((Ipv4Addr::LOCALHOST, port)).unwrap();
            write!(s, "GET {path} HTTP/1.1\r\nHost: 127.0.0.1:{port}\r\n{extra}\r\n").unwrap();
            let mut out = String::new();
            let _ = s.read_to_string(&mut out);
            out
        };
        let page = get("/", "");
        assert!(page.starts_with("HTTP/1.1 200") && page.contains("Content-Security-Policy"));
        assert!(get("/api/state", "").ends_with("{\"x\":1}"));
        assert!(get("/nope", "").starts_with("HTTP/1.1 404"));
        let post = |body: &str, hdr: &str| -> String {
            let mut s = TcpStream::connect((Ipv4Addr::LOCALHOST, port)).unwrap();
            write!(s, "POST /api/cmd HTTP/1.1\r\nHost: 127.0.0.1:{port}\r\n{hdr}Content-Length: {}\r\n\r\n{body}", body.len())
                .unwrap();
            let mut out = String::new();
            let _ = s.read_to_string(&mut out);
            out
        };
        assert!(post("op=mute&ch=0&v=1", "").starts_with("HTTP/1.1 403"));
        assert!(!h.shared.strips[0].mute.load(Relaxed));
        assert!(post("op=mute&ch=0&v=1", "X-Vmix: 1\r\n").starts_with("HTTP/1.1 200"));
        assert!(h.shared.strips[0].mute.load(Relaxed));
        assert!(post("op=bogus", "X-Vmix: 1\r\n").starts_with("HTTP/1.1 400"));
        // event stream delivers published state
        let mut s = TcpStream::connect((Ipv4Addr::LOCALHOST, port)).unwrap();
        write!(s, "GET /api/events HTTP/1.1\r\nHost: 127.0.0.1:{port}\r\n\r\n").unwrap();
        s.set_read_timeout(Some(Duration::from_secs(3))).unwrap();
        let mut got = String::new();
        let mut buf = [0u8; 1024];
        while !got.contains("data: {\"x\":1}\n\n") {
            let n = s.read(&mut buf).unwrap();
            assert!(n > 0);
            got.push_str(&String::from_utf8_lossy(&buf[..n]));
        }
        assert!(got.contains("text/event-stream"));
        h.publish("{\"x\":2}".into());
        while !got.contains("data: {\"x\":2}\n\n") {
            let n = s.read(&mut buf).unwrap();
            assert!(n > 0);
            got.push_str(&String::from_utf8_lossy(&buf[..n]));
        }
        h.close();
        h.recorder.shutdown();
    }
}
