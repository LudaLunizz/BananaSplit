#!/bin/sh
# End-to-end test: runs the real vmix binary against mockjack (no audio server needed).
set -e
HERE=$(cd "$(dirname "$0")" && pwd)
BIN=${1:-$HERE/../../target/release/vmix}
gcc -shared -fPIC -O2 -o "$HERE/libjack.so.0" "$HERE/mockjack.c" -lpthread
TMP=$(mktemp -d); cp "$HERE/e2e.ini" "$TMP/vmix.ini"
export MOCKJACK_REPORT="$TMP/report.txt"
LD_LIBRARY_PATH="$HERE" "$BIN" --headless --config "$TMP/vmix.ini" 2>"$TMP/stderr.txt" &
PID=$!
sleep 7
kill -INT $PID; wait $PID; RC=$?
cat "$TMP/stderr.txt"; cat "$MOCKJACK_REPORT"
fail() { echo "E2E FAIL: $1"; exit 1; }
[ $RC -eq 0 ] || fail "exit code $RC"
grep -q GARBAGE "$MOCKJACK_REPORT" && fail "output buffers not fully written"
grep -q "Speakers:monitor" "$MOCKJACK_REPORT" && fail "@physical picked a monitor port (feedback loop)"
grep -q "^SIGNAL cycle=500 frame=77 vmix:A1_L -> system:playback_1 value=0.625000$" "$MOCKJACK_REPORT" || fail "A1_L"
grep -q "^SIGNAL cycle=500 frame=77 vmix:A1_R -> system:playback_2 value=0.312500$" "$MOCKJACK_REPORT" || fail "A1_R"
grep -q "^SIGNAL cycle=500 frame=77 vmix:B1_L -> OBS:input_1 value=0.500000$" "$MOCKJACK_REPORT" || fail "B1_L"
grep -q "^SIGNAL cycle=500 frame=77 vmix:B1_R -> OBS:input_1 value=0.250000$" "$MOCKJACK_REPORT" || fail "B1_R"
[ "$(grep -c '^SIGNAL' "$MOCKJACK_REPORT")" -eq 4 ] || fail "signal leaked to other frames/cycles/buses"
grep -q "^CYCLES 2000 " "$MOCKJACK_REPORT" || fail "process callback did not run every cycle"
echo "E2E PASS: all outputs sample-aligned at cycle 500 frame 77, zero added latency"
rm -rf "$TMP"

# ---- phase 2: PipeWire virtual cables (fake pactl + cable ports in the mock) ----
TMP=$(mktemp -d)
export PACTL_LOG="$TMP/pactl.log" MOCKJACK_REPORT="$TMP/report.txt" MOCKJACK_CABLES=1 XDG_CONFIG_HOME="$TMP"
PATH="$HERE/fakebin:$PATH" LD_LIBRARY_PATH="$HERE" "$BIN" --headless 2>"$TMP/stderr.txt" &
PID=$!
sleep 2
kill -TERM $PID; wait $PID; RC=$?
[ $RC -eq 0 ] || fail "cables: exit code $RC"
grep -q "^pactl unload-module 7$" "$PACTL_LOG" || fail "stale cable not removed"
grep -q "unload-module 9" "$PACTL_LOG" && fail "removed a module that is not ours"
[ "$(grep -c 'load-module module-null-sink' "$PACTL_LOG")" -eq 8 ] || fail "expected 8 cables"
[ "$(grep -c '^pactl unload-module 1[0-9][0-9]$' "$PACTL_LOG")" -eq 8 ] || fail "cables not removed on exit"
grep -q "node.description=vmix-Out-B1 media.class=Audio/Source/Virtual" "$PACTL_LOG" || fail "B1 virtual mic args"
for s in 1 2 3 4 5 6; do
  grep -q "^CONN vmix-In$s-[A-Za-z]*:monitor_FL -> vmix:in${s}_L$" "$MOCKJACK_REPORT" || fail "cable $s L"
  grep -q "^CONN vmix-In$s-[A-Za-z]*:monitor_FR -> vmix:in${s}_R$" "$MOCKJACK_REPORT" || fail "cable $s R"
done
grep -q "^CONN vmix:B1_L -> vmix-Out-B1:input_FL$" "$MOCKJACK_REPORT" || fail "B1 -> virtual mic"
grep -q "^CONN vmix:B2_R -> vmix-Out-B2:input_FR$" "$MOCKJACK_REPORT" || fail "B2 -> virtual mic"
echo "E2E PASS: 8 virtual cables created, wired, and removed; stale cable cleaned up"
rm -rf "$TMP"

# ---- phase 3: GUI + recorder (real binary, driven over HTTP exactly like the page) ----
command -v curl >/dev/null || fail "phase 3 needs curl"
TMP=$(mktemp -d); cp "$HERE/e2e.ini" "$TMP/vmix.ini"
unset MOCKJACK_CABLES PACTL_LOG XDG_CONFIG_HOME
export MOCKJACK_REPORT="$TMP/report.txt" MOCKJACK_IMPULSE_CYCLE=1200 MOCKJACK_CYCLES=20000
PORT=18791; URL="http://127.0.0.1:$PORT"
LD_LIBRARY_PATH="$HERE" "$BIN" --gui --no-open --gui-port $PORT --config "$TMP/vmix.ini" 2>"$TMP/stderr.txt" &
PID=$!
trap 'rc=$?; kill $PID 2>/dev/null; exit $rc' EXIT   # never leave vmix running if a check fails
cmd() { curl -s -o "$TMP/resp" -w '%{http_code}' -H 'X-Vmix: 1' --data "$1" "$URL/api/cmd"; }
i=0; until curl -sf "$URL/api/ping" >/dev/null 2>&1; do i=$((i+1)); [ $i -lt 200 ] || fail "GUI did not come up"; sleep 0.05; done
curl -s "$URL/" | grep -q '<title>vmix</title>' || fail "page not served"
[ "$(curl -s -o /dev/null -w '%{http_code}' --data 'op=mute&ch=0&v=1' "$URL/api/cmd")" = 403 ] || fail "POST without X-Vmix accepted"
[ "$(curl -s -o /dev/null -w '%{http_code}' -H 'Host: evil.example' "$URL/api/state")" = 403 ] || fail "foreign Host accepted"
LD_LIBRARY_PATH="$HERE" "$BIN" --gui --no-open --gui-port $PORT --config "$TMP/vmix.ini" 2>"$TMP/second.txt" || fail "second --gui failed"
grep -q "already running" "$TMP/second.txt" || fail "second --gui did not find the running one"
[ "$(cmd 'op=link&ch=0&v=1')" = 200 ] || fail "link strip 1"
[ "$(cmd 'op=link&ch=6&v=1')" = 200 ] || fail "link A1"
[ "$(cmd "op=recset&mode=multi&format=wav32f&folder=$TMP/rec")" = 200 ] || fail "recorder settings"
[ "$(cmd 'op=rec&v=1')" = 200 ] || fail "start recording: $(cat "$TMP/resp")"
# state is republished every UI frame (33 ms): allow a few frames for it to show up
i=0; until curl -s "$URL/api/state" | grep -q '"rec":{"on":true,"takeMode":"multi"'; do
  i=$((i+1)); [ $i -lt 40 ] || fail "state does not show the recording"; sleep 0.05
done
# wait until the impulse has gone through strip 1 (its meter jumps to -6 dB)
i=0
until [ "$(curl -s "$URL/api/state" | grep -o '"id":"1"[^}]*' | grep -o '"m":\[[-0-9.]*' | cut -d[ -f2 | awk '{print ($1 > -20)}')" = 1 ]; do
  i=$((i+1)); [ $i -lt 600 ] || fail "impulse never reached strip 1"; sleep 0.05
done
sleep 0.3
[ "$(cmd 'op=rec&v=0')" = 200 ] || fail "stop recording"
sleep 0.5
[ "$(cmd 'op=quit')" = 200 ] || fail "quit"
RC=0; wait $PID || RC=$?
trap - EXIT
cat "$TMP/stderr.txt"
[ $RC -eq 0 ] || fail "gui: exit code $RC"
grep -q "GUI at $URL/" "$TMP/stderr.txt" || fail "GUI URL not printed"
grep -q "^mode = multi$" "$TMP/vmix.ini" && grep -q "^links = 1,A1$" "$TMP/vmix.ini" || fail "recorder settings not saved on quit"
F1=$(ls "$TMP"/rec/*_1-Mic.wav); FA=$(ls "$TMP"/rec/*_A1-Speakers.wav)
[ "$(ls "$TMP"/rec | wc -l)" -eq 2 ] || fail "expected exactly 2 tracks: $(ls "$TMP"/rec)"
SZ=$(stat -c %s "$F1")
[ "$SZ" = "$(stat -c %s "$FA")" ] || fail "tracks differ in length"
[ "$(od -A n -t u4 -j 54 -N 4 "$F1" | tr -d ' ')" -eq $((SZ - 58)) ] || fail "WAV data size"
[ "$(od -A n -t u4 -j 4 -N 4 "$F1" | tr -d ' ')" -eq $((SZ - 8)) ] || fail "RIFF size"
[ "$(od -A n -t u4 -j 46 -N 4 "$F1" | tr -d ' ')" -eq $(((SZ - 58) / 8)) ] || fail "fact frame count"
nz() { od -A n -v -t f4 -j 58 "$1" | tr -s ' \t' '\n\n' | grep -v '^$' | awk '{ if ($1 + 0 != 0) printf "%d %.6f\n", NR - 1, $1 }'; }
S1=$(nz "$F1"); SA=$(nz "$FA")
K=$(echo "$S1" | head -1 | cut -d' ' -f1)
[ -n "$K" ] && [ $((K % 2)) -eq 0 ] || fail "strip 1 track has no impulse: $S1"
[ "$S1" = "$(printf '%d 0.500000\n%d 0.250000' "$K" $((K + 1)))" ] || fail "strip 1 track: $S1"
[ "$SA" = "$(printf '%d 0.625000\n%d 0.312500' "$K" $((K + 1)))" ] || fail "A1 track: $SA"
echo "E2E PASS: GUI drove the recorder; strip 1 and A1 tracks hold the impulse on the same frame ($((K / 2)))"
rm -rf "$TMP"
