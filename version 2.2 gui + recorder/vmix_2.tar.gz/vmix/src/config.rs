//! Persistent configuration (simple INI format, no dependencies).
//!
//! ```ini
//! [global]
//! client_name = vmix
//! buffer_size = 128
//! force_buffer_size = false
//! create_cables = true
//!
//! [strip1]
//! name = Mic
//! gain_db = 0.0
//! mute = false
//! solo = false
//! mono = true
//! routes = B1
//! connect = @physical
//!
//! [bus.A1]
//! name = Speakers
//! gain_db = 0.0
//! mute = false
//! mono = false
//! connect = @physical
//!
//! [recorder]
//! folder = ~/Music/vmix
//! format = wav24      # wav16 | wav24 | wav32f
//! mode = mix          # mix (one stereo file) | multi (one file per channel)
//! links = 1,A1        # channels feeding the recorder: 1-6, A1-A3, B1-B2 or none
//! ```
//!
//! `connect` may be repeated. Each value is either `@physical` (the
//! server's physical capture ports for a strip / physical playback ports for
//! a bus) or a JACK port-name regular expression. The first two matching
//! ports are connected to L/R; a single (mono) port is connected to both.
//! An empty `connect =` line clears the list.
//!
//! Parsing is strict: unknown sections/keys and bad values are errors with a
//! line number, so a typo can never be silently ignored. A file without a
//! `[recorder]` section (written by an older vmix) loads with its defaults.

use crate::engine::{BUS_IDS, NUM_BUSES, NUM_STRIPS, Shared, clamp_db};
use crate::recorder::{self, ALL_LINKS, Format, Mode, Settings};
use std::fmt::Write as _;
use std::path::{Path, PathBuf};
use std::sync::atomic::Ordering::Relaxed;

pub const PHYSICAL: &str = "@physical";

#[derive(Debug, Clone, PartialEq)]
pub struct RecorderConfig {
    pub folder: String,
    pub format: Format,
    pub mode: Mode,
    /// Linked channels, same bit layout as [`Shared::rec_links`].
    pub links: u16,
}

impl Default for RecorderConfig {
    fn default() -> Self {
        let s = Settings::default();
        RecorderConfig { folder: s.folder, format: s.format, mode: s.mode, links: 1 << NUM_STRIPS } // A1
    }
}

impl RecorderConfig {
    pub fn settings(&self) -> Settings {
        Settings { folder: self.folder.clone(), format: self.format, mode: self.mode }
    }

    pub fn set_settings(&mut self, s: &Settings) {
        self.folder = s.folder.clone();
        self.format = s.format;
        self.mode = s.mode;
    }
}

#[derive(Debug, Clone, PartialEq)]
pub struct StripConfig {
    pub name: String,
    pub gain_db: f32,
    pub mute: bool,
    pub solo: bool,
    pub mono: bool,
    pub routes: u8,
    pub connect: Vec<String>,
}

#[derive(Debug, Clone, PartialEq)]
pub struct BusConfig {
    pub name: String,
    pub gain_db: f32,
    pub mute: bool,
    pub mono: bool,
    pub connect: Vec<String>,
}

#[derive(Debug, Clone, PartialEq)]
pub struct Config {
    pub client_name: String,
    /// Requested period in frames (0 = don't request anything).
    pub buffer_size: u32,
    /// Call jack_set_buffer_size() if the server runs a larger period.
    /// Under JACK2 this changes the period for every client.
    pub force_buffer_size: bool,
    /// Create PipeWire virtual cables (one sink per strip, one virtual
    /// microphone per B bus) via `pactl`.
    pub create_cables: bool,
    pub strips: [StripConfig; NUM_STRIPS],
    pub buses: [BusConfig; NUM_BUSES],
    pub recorder: RecorderConfig,
}

impl Default for Config {
    fn default() -> Self {
        let strip = |name: &str, routes: u8, mono: bool, connect: &[&str]| StripConfig {
            name: name.into(),
            gain_db: 0.0,
            mute: false,
            solo: false,
            mono,
            routes,
            connect: connect.iter().map(|s| s.to_string()).collect(),
        };
        let bus = |name: &str, connect: &[&str]| BusConfig {
            name: name.into(),
            gain_db: 0.0,
            mute: false,
            mono: false,
            connect: connect.iter().map(|s| s.to_string()).collect(),
        };
        const A1: u8 = 1;
        const A2: u8 = 2;
        const B1: u8 = 8;
        Config {
            client_name: "vmix".into(),
            buffer_size: 128,
            force_buffer_size: false,
            create_cables: true,
            strips: [
                strip("Mic", B1, true, &[PHYSICAL]),
                strip("Discord", A1 | A2, false, &[]),
                strip("Desktop", A1, false, &[]),
                strip("Game", A1, false, &[]),
                strip("Music", A1, false, &[]),
                strip("Aux", A1, false, &[]),
            ],
            buses: [
                bus("Speakers", &[PHYSICAL]),
                bus("Headphones", &[]),
                bus("A3", &[]),
                bus("Virtual B1", &[]),
                bus("Virtual B2", &[]),
            ],
            recorder: RecorderConfig::default(),
        }
    }
}

#[derive(Debug)]
pub struct ParseError {
    pub line: usize,
    pub msg: String,
}

impl std::fmt::Display for ParseError {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        write!(f, "line {}: {}", self.line, self.msg)
    }
}
impl std::error::Error for ParseError {}

enum Section {
    None,
    Global,
    Strip(usize),
    Bus(usize),
    Recorder,
}

fn parse_bool(v: &str) -> Result<bool, String> {
    match v.to_ascii_lowercase().as_str() {
        "true" | "yes" | "on" | "1" => Ok(true),
        "false" | "no" | "off" | "0" => Ok(false),
        _ => Err(format!("expected true/false, got {v:?}")),
    }
}

fn parse_gain(v: &str) -> Result<f32, String> {
    let g: f32 = v.parse().map_err(|_| format!("expected a number, got {v:?}"))?;
    if !g.is_finite() {
        return Err(format!("gain must be finite, got {v:?}"));
    }
    Ok(clamp_db(g))
}

pub fn parse_routes(v: &str) -> Result<u8, String> {
    let mut mask = 0u8;
    for tok in v.split(',').map(str::trim).filter(|t| !t.is_empty()) {
        if tok.eq_ignore_ascii_case("none") {
            continue;
        }
        match BUS_IDS.iter().position(|b| b.eq_ignore_ascii_case(tok)) {
            Some(i) => mask |= 1 << i,
            None => return Err(format!("unknown bus {tok:?} (expected A1, A2, A3, B1, B2)")),
        }
    }
    Ok(mask)
}

pub fn format_routes(mask: u8) -> String {
    let v: Vec<&str> = (0..NUM_BUSES).filter(|b| mask & (1 << b) != 0).map(|b| BUS_IDS[b]).collect();
    if v.is_empty() { "none".into() } else { v.join(",") }
}

fn valid_client_name(v: &str) -> bool {
    !v.is_empty() && v.len() <= 32 && v.chars().all(|c| c.is_ascii_alphanumeric() || c == '-' || c == '_')
}

impl Config {
    pub fn parse(text: &str) -> Result<Config, ParseError> {
        let mut cfg = Config::default();
        let mut sec = Section::None;
        // A `connect` list from the file replaces the default list the first
        // time it is seen in a section, then appends.
        let mut strip_seen = [false; NUM_STRIPS];
        let mut bus_seen = [false; NUM_BUSES];

        for (idx, raw) in text.lines().enumerate() {
            let line_no = idx + 1;
            let err = |msg: String| ParseError { line: line_no, msg };
            let line = raw.trim();
            if line.is_empty() || line.starts_with('#') || line.starts_with(';') {
                continue;
            }
            if let Some(h) = line.strip_prefix('[') {
                let h = h.strip_suffix(']').ok_or_else(|| err("missing ']'".into()))?.trim();
                sec = if h.eq_ignore_ascii_case("global") {
                    Section::Global
                } else if h.eq_ignore_ascii_case("recorder") {
                    Section::Recorder
                } else if let Some(n) = h.strip_prefix("strip") {
                    match n.parse::<usize>() {
                        Ok(i) if (1..=NUM_STRIPS).contains(&i) => Section::Strip(i - 1),
                        _ => return Err(err(format!("unknown section [{h}] (strips are strip1..strip{NUM_STRIPS})"))),
                    }
                } else if let Some(id) = h.strip_prefix("bus.") {
                    match BUS_IDS.iter().position(|b| b.eq_ignore_ascii_case(id)) {
                        Some(i) => Section::Bus(i),
                        None => return Err(err(format!("unknown section [{h}] (buses are bus.A1..bus.B2)"))),
                    }
                } else {
                    return Err(err(format!("unknown section [{h}]")));
                };
                continue;
            }
            let (k, v) = line.split_once('=').ok_or_else(|| err("expected key = value".into()))?;
            let (k, v) = (k.trim(), v.trim());
            match sec {
                Section::None => return Err(err("key outside of a section".into())),
                Section::Global => match k {
                    "client_name" => {
                        if !valid_client_name(v) {
                            return Err(err("client_name must be 1-32 chars of [A-Za-z0-9_-]".into()));
                        }
                        cfg.client_name = v.into();
                    }
                    "buffer_size" => {
                        let n: u32 = v.parse().map_err(|_| err(format!("bad buffer_size {v:?}")))?;
                        if n != 0 && (!n.is_power_of_two() || !(16..=8192).contains(&n)) {
                            return Err(err("buffer_size must be 0 or a power of two in 16..=8192".into()));
                        }
                        cfg.buffer_size = n;
                    }
                    "force_buffer_size" => cfg.force_buffer_size = parse_bool(v).map_err(err)?,
                    "create_cables" => cfg.create_cables = parse_bool(v).map_err(err)?,
                    _ => return Err(err(format!("unknown key {k:?} in [global]"))),
                },
                Section::Strip(i) => {
                    let s = &mut cfg.strips[i];
                    match k {
                        "name" => s.name = v.into(),
                        "gain_db" => s.gain_db = parse_gain(v).map_err(err)?,
                        "mute" => s.mute = parse_bool(v).map_err(err)?,
                        "solo" => s.solo = parse_bool(v).map_err(err)?,
                        "mono" => s.mono = parse_bool(v).map_err(err)?,
                        "routes" => s.routes = parse_routes(v).map_err(err)?,
                        "connect" => {
                            if !strip_seen[i] {
                                s.connect.clear();
                                strip_seen[i] = true;
                            }
                            if v.is_empty() { s.connect.clear() } else { s.connect.push(v.into()) }
                        }
                        _ => return Err(err(format!("unknown key {k:?} in [strip{}]", i + 1))),
                    }
                }
                Section::Bus(i) => {
                    let b = &mut cfg.buses[i];
                    match k {
                        "name" => b.name = v.into(),
                        "gain_db" => b.gain_db = parse_gain(v).map_err(err)?,
                        "mute" => b.mute = parse_bool(v).map_err(err)?,
                        "mono" => b.mono = parse_bool(v).map_err(err)?,
                        "connect" => {
                            if !bus_seen[i] {
                                b.connect.clear();
                                bus_seen[i] = true;
                            }
                            if v.is_empty() { b.connect.clear() } else { b.connect.push(v.into()) }
                        }
                        _ => return Err(err(format!("unknown key {k:?} in [bus.{}]", BUS_IDS[i]))),
                    }
                }
                Section::Recorder => {
                    let r = &mut cfg.recorder;
                    match k {
                        "folder" => {
                            recorder::validate_folder(v).map_err(err)?;
                            r.folder = v.into();
                        }
                        "format" => r.format = Format::parse(v).map_err(err)?,
                        "mode" => r.mode = Mode::parse(v).map_err(err)?,
                        "links" => r.links = recorder::parse_links(v).map_err(err)?,
                        _ => return Err(err(format!("unknown key {k:?} in [recorder]"))),
                    }
                }
            }
        }
        Ok(cfg)
    }

    pub fn to_ini(&self) -> String {
        let mut o = String::new();
        let _ = writeln!(o, "# vmix configuration — written by vmix; comments are not preserved.");
        let _ = writeln!(o, "# connect = @physical | <JACK port regex>   (may be repeated)");
        let _ = writeln!(o, "\n[global]");
        let _ = writeln!(o, "client_name = {}", self.client_name);
        let _ = writeln!(o, "buffer_size = {}", self.buffer_size);
        let _ = writeln!(o, "force_buffer_size = {}", self.force_buffer_size);
        let _ = writeln!(o, "create_cables = {}", self.create_cables);
        for (i, s) in self.strips.iter().enumerate() {
            let _ = writeln!(o, "\n[strip{}]", i + 1);
            let _ = writeln!(o, "name = {}", s.name);
            let _ = writeln!(o, "gain_db = {}", s.gain_db);
            let _ = writeln!(o, "mute = {}", s.mute);
            let _ = writeln!(o, "solo = {}", s.solo);
            let _ = writeln!(o, "mono = {}", s.mono);
            let _ = writeln!(o, "routes = {}", format_routes(s.routes));
            if s.connect.is_empty() {
                let _ = writeln!(o, "connect =");
            }
            for c in &s.connect {
                let _ = writeln!(o, "connect = {c}");
            }
        }
        for (i, b) in self.buses.iter().enumerate() {
            let _ = writeln!(o, "\n[bus.{}]", BUS_IDS[i]);
            let _ = writeln!(o, "name = {}", b.name);
            let _ = writeln!(o, "gain_db = {}", b.gain_db);
            let _ = writeln!(o, "mute = {}", b.mute);
            let _ = writeln!(o, "mono = {}", b.mono);
            if b.connect.is_empty() {
                let _ = writeln!(o, "connect =");
            }
            for c in &b.connect {
                let _ = writeln!(o, "connect = {c}");
            }
        }
        let r = &self.recorder;
        let _ = writeln!(o, "\n[recorder]");
        let _ = writeln!(o, "# links: 1-6 = strips, A1-A3 / B1-B2 = buses; mode = mix | multi");
        let _ = writeln!(o, "folder = {}", r.folder);
        let _ = writeln!(o, "format = {}", r.format.as_str());
        let _ = writeln!(o, "mode = {}", r.mode.as_str());
        let _ = writeln!(o, "links = {}", recorder::format_links(r.links));
        o
    }

    /// Push mixer parameters into the shared real-time state.
    pub fn apply(&self, sh: &Shared) {
        for (s, p) in self.strips.iter().zip(&sh.strips) {
            p.gain_db.store(clamp_db(s.gain_db));
            p.mute.store(s.mute, Relaxed);
            p.solo.store(s.solo, Relaxed);
            p.mono.store(s.mono, Relaxed);
            p.routes.store(s.routes & 0b11111, Relaxed);
        }
        for (b, p) in self.buses.iter().zip(&sh.buses) {
            p.gain_db.store(clamp_db(b.gain_db));
            p.mute.store(b.mute, Relaxed);
            p.mono.store(b.mono, Relaxed);
        }
        sh.rec_links.store(self.recorder.links & ALL_LINKS, Relaxed);
    }

    /// Pull current mixer parameters back from the shared state.
    pub fn capture(&mut self, sh: &Shared) {
        for (s, p) in self.strips.iter_mut().zip(&sh.strips) {
            s.gain_db = p.gain_db.load();
            s.mute = p.mute.load(Relaxed);
            s.solo = p.solo.load(Relaxed);
            s.mono = p.mono.load(Relaxed);
            s.routes = p.routes.load(Relaxed);
        }
        for (b, p) in self.buses.iter_mut().zip(&sh.buses) {
            b.gain_db = p.gain_db.load();
            b.mute = p.mute.load(Relaxed);
            b.mono = p.mono.load(Relaxed);
        }
        self.recorder.links = sh.rec_links.load(Relaxed) & ALL_LINKS;
    }

    pub fn default_path() -> PathBuf {
        let base = std::env::var_os("XDG_CONFIG_HOME")
            .filter(|v| !v.is_empty())
            .map(PathBuf::from)
            .or_else(|| std::env::var_os("HOME").map(|h| PathBuf::from(h).join(".config")))
            .unwrap_or_else(|| PathBuf::from("."));
        base.join("vmix").join("vmix.ini")
    }

    /// Load from `path`; if it does not exist, write the defaults there.
    pub fn load_or_create(path: &Path) -> Result<Config, String> {
        match std::fs::read_to_string(path) {
            Ok(text) => Config::parse(&text).map_err(|e| format!("{}: {e}", path.display())),
            Err(e) if e.kind() == std::io::ErrorKind::NotFound => {
                let cfg = Config::default();
                cfg.save(path)?;
                Ok(cfg)
            }
            Err(e) => Err(format!("{}: {e}", path.display())),
        }
    }

    /// Atomic save (write temp file, then rename).
    pub fn save(&self, path: &Path) -> Result<(), String> {
        if let Some(dir) = path.parent() {
            if !dir.as_os_str().is_empty() {
                std::fs::create_dir_all(dir).map_err(|e| format!("{}: {e}", dir.display()))?;
            }
        }
        let tmp = path.with_extension("ini.tmp");
        std::fs::write(&tmp, self.to_ini()).map_err(|e| format!("{}: {e}", tmp.display()))?;
        std::fs::rename(&tmp, path).map_err(|e| format!("{}: {e}", path.display()))
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn default_round_trips() {
        let c = Config::default();
        assert_eq!(Config::parse(&c.to_ini()).unwrap(), c);
    }

    #[test]
    #[allow(clippy::field_reassign_with_default)]
    fn modified_round_trips() {
        let mut c = Config::default();
        c.client_name = "mix_2".into();
        c.buffer_size = 64;
        c.strips[4].gain_db = -12.5;
        c.strips[4].routes = 0b10101;
        c.strips[4].connect = vec!["^Firefox:output_F[LR]$".into(), "a{1,2}".into()];
        c.strips[0].connect.clear();
        c.buses[2].mono = true;
        c.buses[2].connect = vec!["^USB Audio:playback_F[LR]$".into()];
        c.recorder.folder = "/srv/rec dir/vmix".into();
        c.recorder.format = Format::Wav32f;
        c.recorder.mode = Mode::Multi;
        c.recorder.links = 0b110_0010_0001;
        assert_eq!(Config::parse(&c.to_ini()).unwrap(), c);
        c.recorder.links = 0;
        assert_eq!(Config::parse(&c.to_ini()).unwrap(), c);
    }

    #[test]
    fn recorder_section() {
        // a config written before the recorder existed still loads
        let old = "[global]\nclient_name = vmix\n[strip1]\nname = Mic\n";
        assert_eq!(Config::parse(old).unwrap().recorder, RecorderConfig::default());
        let c = Config::parse("[Recorder]\nfolder = ~/rec\nformat = wav16\nmode = multi\nlinks = 2, b1\n").unwrap();
        assert_eq!(c.recorder.folder, "~/rec");
        assert_eq!(c.recorder.format, Format::Wav16);
        assert_eq!(c.recorder.mode, Mode::Multi);
        assert_eq!(c.recorder.links, 0b010_0000_0010);
        let e = Config::parse("[recorder]\nformat = mp3\n").unwrap_err();
        assert_eq!(e.line, 2);
        assert!(Config::parse("[recorder]\nmode = stereo\n").is_err());
        assert!(Config::parse("[recorder]\nlinks = 1,C9\n").unwrap_err().msg.contains("C9"));
        assert!(Config::parse("[recorder]\nfolder =\n").is_err());
        assert!(Config::parse("[recorder]\ngain = 1\n").unwrap_err().msg.contains("gain"));
    }

    #[test]
    fn strict_errors_have_line_numbers() {
        let e = Config::parse("[global]\nbuffer_size = 100\n").unwrap_err();
        assert_eq!(e.line, 2);
        let e = Config::parse("[strip7]\n").unwrap_err();
        assert_eq!(e.line, 1);
        let e = Config::parse("[strip1]\nroutes = A1,C3\n").unwrap_err();
        assert!(e.msg.contains("C3"));
        let e = Config::parse("[bus.A1]\nvolume = 3\n").unwrap_err();
        assert!(e.msg.contains("volume"));
        assert!(Config::parse("gain_db = 1\n").is_err());
        assert!(Config::parse("[global]\nclient_name = bad name\n").is_err());
        assert!(Config::parse("[strip1]\ngain_db = inf\n").is_err());
    }

    #[test]
    fn gains_are_clamped_and_routes_parse() {
        let c = Config::parse("[strip2]\ngain_db = 99\nroutes = b2, a1 ,none\n").unwrap();
        assert_eq!(c.strips[1].gain_db, crate::engine::MAX_GAIN_DB);
        assert_eq!(c.strips[1].routes, 0b10001);
        assert_eq!(parse_routes("").unwrap(), 0);
        assert_eq!(format_routes(0), "none");
    }

    #[test]
    #[allow(clippy::field_reassign_with_default)]
    fn apply_and_capture() {
        let sh = Shared::new();
        let mut c = Config::default();
        c.strips[3].gain_db = -3.0;
        c.strips[3].solo = true;
        c.buses[4].mute = true;
        c.recorder.links = 0b100_0000_1000;
        c.apply(&sh);
        assert_eq!(sh.rec_links.load(Relaxed), 0b100_0000_1000);
        let mut d = Config::default();
        d.capture(&sh);
        assert_eq!(c, d);
    }

    #[test]
    fn save_and_load() {
        let dir = std::env::temp_dir().join(format!("vmix-test-{}", std::process::id()));
        let path = dir.join("sub").join("vmix.ini");
        let c = Config::load_or_create(&path).unwrap();
        assert_eq!(c, Config::default());
        let mut c2 = c.clone();
        c2.strips[0].name = "Voice".into();
        c2.save(&path).unwrap();
        assert_eq!(Config::load_or_create(&path).unwrap(), c2);
        std::fs::remove_dir_all(&dir).unwrap();
    }
}
