//! Tiny libc shims: signals and terminal raw mode (no external crates).

use std::ffi::c_int;
use std::sync::OnceLock;
use std::sync::atomic::{AtomicBool, Ordering::SeqCst};

// glibc/musl `struct termios` layout below is the same on these targets.
#[cfg(not(any(
    target_arch = "x86_64",
    target_arch = "x86",
    target_arch = "aarch64",
    target_arch = "arm",
    target_arch = "riscv64"
)))]
compile_error!("termios layout only verified for x86, x86_64, arm, aarch64 and riscv64 Linux");

#[repr(C)]
#[derive(Clone, Copy)]
struct Termios {
    c_iflag: u32,
    c_oflag: u32,
    c_cflag: u32,
    c_lflag: u32,
    c_line: u8,
    c_cc: [u8; 32],
    c_ispeed: u32,
    c_ospeed: u32,
    /// Safety margin in case a libc writes a slightly larger struct.
    _pad: [u8; 64],
}

const ISIG: u32 = 0o000001;
const ICANON: u32 = 0o000002;
const ECHO: u32 = 0o000010;
const IEXTEN: u32 = 0o100000;
const ICRNL: u32 = 0o000400;
const IXON: u32 = 0o002000;
const VTIME: usize = 5;
const VMIN: usize = 6;
const TCSANOW: c_int = 0;

const SIGHUP: c_int = 1;
const SIGINT: c_int = 2;
const SIGTERM: c_int = 15;

unsafe extern "C" {
    fn tcgetattr(fd: c_int, t: *mut Termios) -> c_int;
    fn tcsetattr(fd: c_int, act: c_int, t: *const Termios) -> c_int;
    fn isatty(fd: c_int) -> c_int;
    fn signal(sig: c_int, handler: usize) -> usize;
}

/// Set by SIGINT/SIGTERM/SIGHUP (and by `q` in the UI).
pub static QUIT: AtomicBool = AtomicBool::new(false);

extern "C" fn on_signal(_sig: c_int) {
    // Atomic store is async-signal-safe.
    QUIT.store(true, SeqCst);
}

pub fn install_signal_handlers() {
    let h = on_signal as extern "C" fn(c_int) as usize;
    for s in [SIGINT, SIGTERM, SIGHUP] {
        // SAFETY: handler only performs an atomic store.
        unsafe { signal(s, h) };
    }
}

pub fn stdin_is_tty() -> bool {
    unsafe { isatty(0) == 1 && isatty(1) == 1 }
}

static ORIGINAL: OnceLock<Termios> = OnceLock::new();

fn restore_tty() {
    if let Some(t) = ORIGINAL.get() {
        unsafe { tcsetattr(0, TCSANOW, t) };
    }
    // show cursor, leave alternate screen, reset colours
    print!("\x1b[0m\x1b[?25h\x1b[?1049l");
    use std::io::Write;
    let _ = std::io::stdout().flush();
}

/// Raw keyboard input + alternate screen; restored on drop and on panic.
pub struct RawTerminal;

impl RawTerminal {
    pub fn enter() -> Result<RawTerminal, String> {
        let mut t: Termios = unsafe { std::mem::zeroed() };
        if unsafe { tcgetattr(0, &mut t) } != 0 {
            return Err("stdin is not a terminal (use --headless)".into());
        }
        let _ = ORIGINAL.set(t);
        let mut raw = t;
        raw.c_lflag &= !(ICANON | ECHO | ISIG | IEXTEN);
        raw.c_iflag &= !(ICRNL | IXON);
        raw.c_cc[VMIN] = 1;
        raw.c_cc[VTIME] = 0;
        if unsafe { tcsetattr(0, TCSANOW, &raw) } != 0 {
            return Err("cannot set terminal raw mode".into());
        }
        let prev = std::panic::take_hook();
        std::panic::set_hook(Box::new(move |info| {
            restore_tty();
            prev(info);
        }));
        print!("\x1b[?1049h\x1b[?25l\x1b[2J");
        Ok(RawTerminal)
    }
}

impl Drop for RawTerminal {
    fn drop(&mut self) {
        restore_tty();
    }
}

/// Current local time as `YYYY-MM-DD_HH-MM-SS` (for recording file names).
///
/// Uses `localtime_r` on 64-bit targets, where `time_t` is 64-bit on both
/// glibc and musl. On 32-bit targets its width differs between libcs, so
/// UTC is used there instead (marked with a trailing `Z`).
pub fn local_timestamp() -> String {
    let secs = std::time::SystemTime::now()
        .duration_since(std::time::UNIX_EPOCH)
        .map(|d| d.as_secs() as i64)
        .unwrap_or(0);
    #[cfg(target_pointer_width = "64")]
    {
        // Leading fields of glibc/musl `struct tm`; `_rest` covers the
        // remaining ints, tm_gmtoff and tm_zone with room to spare.
        #[repr(C)]
        struct Tm {
            sec: c_int,
            min: c_int,
            hour: c_int,
            mday: c_int,
            mon: c_int,
            year: c_int,
            _rest: [u8; 128],
        }
        unsafe extern "C" {
            fn localtime_r(t: *const i64, out: *mut Tm) -> *mut Tm;
        }
        // SAFETY: plain-old-data out-parameter large enough for struct tm.
        let mut tm: Tm = unsafe { std::mem::zeroed() };
        if !unsafe { localtime_r(&secs, &mut tm) }.is_null() {
            return format!(
                "{:04}-{:02}-{:02}_{:02}-{:02}-{:02}",
                tm.year + 1900,
                tm.mon + 1,
                tm.mday,
                tm.hour,
                tm.min,
                tm.sec
            );
        }
    }
    utc_timestamp(secs)
}

/// `YYYY-MM-DD_HH-MM-SSZ` in UTC (civil-from-days, proleptic Gregorian).
pub fn utc_timestamp(secs: i64) -> String {
    let (days, rem) = (secs.div_euclid(86_400), secs.rem_euclid(86_400));
    let z = days + 719_468;
    let era = z.div_euclid(146_097);
    let doe = z.rem_euclid(146_097);
    let yoe = (doe - doe / 1460 + doe / 36_524 - doe / 146_096) / 365;
    let doy = doe - (365 * yoe + yoe / 4 - yoe / 100);
    let mp = (5 * doy + 2) / 153;
    let d = doy - (153 * mp + 2) / 5 + 1;
    let m = if mp < 10 { mp + 3 } else { mp - 9 };
    let y = yoe + era * 400 + i64::from(m <= 2);
    format!("{y:04}-{m:02}-{d:02}_{:02}-{:02}-{:02}Z", rem / 3600, rem % 3600 / 60, rem % 60)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn timestamps() {
        assert_eq!(utc_timestamp(0), "1970-01-01_00-00-00Z");
        assert_eq!(utc_timestamp(951_782_400), "2000-02-29_00-00-00Z");
        assert_eq!(utc_timestamp(1_792_339_880), "2026-10-18_16-11-20Z");
        assert_eq!(utc_timestamp(-1), "1969-12-31_23-59-59Z");
        let t = local_timestamp();
        assert!(t.len() >= 19 && t.as_bytes()[4] == b'-' && t.as_bytes()[10] == b'_', "{t}");
        assert!(t.chars().all(|c| c.is_ascii_digit() || c == '-' || c == '_' || c == 'Z'));
    }
}
