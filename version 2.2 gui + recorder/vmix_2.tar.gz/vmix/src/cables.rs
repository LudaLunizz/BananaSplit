//! Virtual cables (PipeWire).
//!
//! * One **virtual output device per strip** (`Audio/Sink`), e.g.
//!   "vmix-In3-Desktop". Point any application (or the system default output)
//!   at it and its audio lands on that strip. This is the equivalent of
//!   "VB-Audio CABLE Input" / "Voicemeeter Input".
//! * One **virtual microphone per B bus** (`Audio/Source/Virtual`), e.g.
//!   "vmix-Out-B1". Pick it as the microphone in Discord/OBS/etc. This is the
//!   equivalent of "Voicemeeter Output" / "CABLE Output".
//!
//! Cables are created with `pactl load-module module-null-sink`, which
//! pipewire-pulse implements natively. They live in the same PipeWire graph
//! and are driven by the same clock as the mixer, so they add no buffering
//! and stay sample-aligned. They are removed again when vmix exits; stale
//! cables left behind by a crash are cleaned up on the next start.

use crate::jack::regex_escape;
use std::process::Command;
use vmix::config::Config;
use vmix::engine::{BUS_IDS, NUM_BUSES, NUM_PHYSICAL_BUSES, NUM_STRIPS};

#[cfg(test)]
const NUM_VIRTUAL_BUSES: usize = NUM_BUSES - NUM_PHYSICAL_BUSES;

#[derive(Debug, Clone)]
pub struct CableSpec {
    /// PipeWire node.name (stable, used for cleanup).
    pub node_name: String,
    /// Human-readable name shown in sound settings.
    pub description: String,
    /// true = virtual microphone (B bus), false = virtual output (strip).
    pub is_source: bool,
}

impl CableSpec {
    /// Regex matching this cable's JACK client name. PipeWire's JACK layer
    /// names ports after node.description by default (node.name if
    /// `jack.short-name` is set), so accept either.
    pub fn jack_regex(&self) -> String {
        format!("^({}|{})[^:]*:", regex_escape(&self.node_name), regex_escape(&self.description))
    }
}

fn sanitize(s: &str) -> String {
    let t: String = s
        .chars()
        .map(|c| if c.is_ascii_alphanumeric() || c == '-' || c == '_' { c } else { '-' })
        .collect();
    let t = t.trim_matches('-').to_string();
    t.chars().take(24).collect()
}

pub struct CableSet {
    pub strips: Vec<CableSpec>, // NUM_STRIPS
    pub buses: Vec<CableSpec>,  // NUM_VIRTUAL_BUSES (B1, B2)
}

impl CableSet {
    pub fn for_config(cfg: &Config) -> CableSet {
        let prefix = cfg.client_name.to_ascii_lowercase().replace('-', "_");
        let strips = (0..NUM_STRIPS)
            .map(|i| {
                let nm = sanitize(&cfg.strips[i].name);
                CableSpec {
                    node_name: format!("{prefix}_in{}", i + 1),
                    description: if nm.is_empty() {
                        format!("{}-In{}", cfg.client_name, i + 1)
                    } else {
                        format!("{}-In{}-{nm}", cfg.client_name, i + 1)
                    },
                    is_source: false,
                }
            })
            .collect();
        let buses = (NUM_PHYSICAL_BUSES..NUM_BUSES)
            .map(|b| CableSpec {
                node_name: format!("{prefix}_out_{}", BUS_IDS[b].to_ascii_lowercase()),
                description: format!("{}-Out-{}", cfg.client_name, BUS_IDS[b]),
                is_source: true,
            })
            .collect();
        CableSet { strips, buses }
    }

    pub fn all(&self) -> impl Iterator<Item = &CableSpec> {
        self.strips.iter().chain(self.buses.iter())
    }
}

fn pactl(args: &[&str]) -> Result<String, String> {
    let out = Command::new("pactl")
        .args(args)
        .output()
        .map_err(|e| format!("cannot run pactl ({e}); install pulseaudio-utils / libpulse to get virtual cables"))?;
    if out.status.success() {
        Ok(String::from_utf8_lossy(&out.stdout).into_owned())
    } else {
        Err(format!("pactl {}: {}", args.join(" "), String::from_utf8_lossy(&out.stderr).trim()))
    }
}

/// Loaded cable modules; unloaded on drop.
pub struct Cables {
    modules: Vec<u32>,
}

impl Cables {
    /// Create all cables. Returns the guard plus non-fatal warnings.
    pub fn create(set: &CableSet) -> (Cables, Vec<String>) {
        let mut warnings = Vec::new();
        let mut me = Cables { modules: Vec::new() };

        match pactl(&["info"]) {
            Ok(info) if info.contains("PipeWire") => {}
            Ok(_) => {
                warnings.push(
                    "virtual cables need PipeWire (pipewire-pulse); the sound server is not PipeWire, skipping cables".into(),
                );
                return (me, warnings);
            }
            Err(e) => {
                warnings.push(e);
                return (me, warnings);
            }
        }

        // Remove leftovers from a previous crash (exact node-name match only).
        let ours: Vec<String> = set.all().map(|c| format!("sink_name={}", c.node_name)).collect();
        if let Ok(list) = pactl(&["list", "short", "modules"]) {
            for line in list.lines() {
                let mut f = line.split('\t');
                let (Some(id), Some(name), args) = (f.next(), f.next(), f.next().unwrap_or("")) else { continue };
                if name == "module-null-sink" && args.split_whitespace().any(|a| ours.iter().any(|o| o == a)) {
                    let _ = pactl(&["unload-module", id]);
                }
            }
        }

        for c in set.all() {
            let sink_name = format!("sink_name={}", c.node_name);
            let props = format!("sink_properties=device.description={}", c.description);
            let node_desc = format!("node.description={}", c.description);
            let mut args =
                vec!["load-module", "module-null-sink", sink_name.as_str(), props.as_str(), node_desc.as_str()];
            if c.is_source {
                args.push("media.class=Audio/Source/Virtual");
            } else {
                args.push("media.class=Audio/Sink");
            }
            args.push("channels=2");
            args.push("channel_map=front-left,front-right");
            match pactl(&args) {
                Ok(out) => match out.trim().parse::<u32>() {
                    Ok(id) => me.modules.push(id),
                    Err(_) => warnings.push(format!("unexpected pactl output for {}: {out:?}", c.description)),
                },
                Err(e) => warnings.push(e),
            }
        }
        (me, warnings)
    }

    pub fn none() -> Cables {
        Cables { modules: Vec::new() }
    }

    pub fn count(&self) -> usize {
        self.modules.len()
    }
}

impl Drop for Cables {
    fn drop(&mut self) {
        for id in self.modules.drain(..).rev() {
            let _ = pactl(&["unload-module", &id.to_string()]);
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn names_are_stable_and_safe() {
        let mut cfg = Config::default();
        cfg.strips[2].name = "Desk top (main)!".into();
        let set = CableSet::for_config(&cfg);
        assert_eq!(set.strips.len(), NUM_STRIPS);
        assert_eq!(set.buses.len(), NUM_VIRTUAL_BUSES);
        assert_eq!(set.strips[2].node_name, "vmix_in3");
        assert_eq!(set.strips[2].description, "vmix-In3-Desk-top--main");
        assert_eq!(set.buses[0].node_name, "vmix_out_b1");
        assert_eq!(set.buses[1].description, "vmix-Out-B2");
        assert!(set.buses.iter().all(|b| b.is_source));
        assert_eq!(set.strips[0].jack_regex(), "^(vmix_in1|vmix-In1-Mic)[^:]*:");
        for c in set.all() {
            assert!(!c.description.contains(' '), "pactl args must not contain spaces");
        }
    }
}
