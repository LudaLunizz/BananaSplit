# vmix: a 6-strip virtual audio mixer for Linux

A Voicemeeter Banana-style mixer written in Rust, with **6 input strips**, **3 hardware buses (A1–A3)**, **2 virtual buses (B1–B2)**, **one virtual cable per strip**, and a **recorder** that can take any of those 11 channels. It runs as a single real-time JACK client, natively on JACK2 or on PipeWire's JACK layer, and you control it from the terminal or from a graphical window (`vmix --gui`).

```
 VMIX  6 strips · 5 buses · JACK client "vmix" · 8 cables
 48000 Hz  128 frames  period 2.67 ms  round-trip 6.10 ms [<10 ms OK]  DSP 1.2%  xruns 0

  #  NAME         GAIN   L            R             PEAK  M S O  A1 A2 A3 B1 B2
> 1  Mic           +0.0  ███████····· ███████·····    -24  · · O  A1 A2 A3 B1 B2
  2  Discord       -7.4  █████······· █████·······    -31  · · ·  A1 A2 A3 B1 B2
  ...
```

## ASIO / WASAPI on Linux

ASIO and WASAPI are **Windows-only** driver APIs and do not exist on Linux. What they give you on Windows (exclusive device access, no OS mixer or resampler in the path, small fixed buffers, and one callback that sees every channel at once) is what **JACK** provides on Linux. PipeWire implements the same API.

| Windows                       | vmix on Linux                                                       |
|-------------------------------|---------------------------------------------------------------------|
| ASIO driver                   | JACK2 server, or PipeWire + `pipewire-jack`                         |
| WASAPI exclusive mode         | Device opened only by JACK/PipeWire at a fixed rate and quantum     |
| VB-Cable / "Voicemeeter Input"| `vmix-In1…6` virtual output devices (PipeWire sinks)                |
| "Voicemeeter Output" (B1/B2)  | `vmix-Out-B1`, `vmix-Out-B2` virtual microphones                    |
| Voicemeeter Banana            | `vmix`                                                              |

## Sync and latency

* **Sample-synchronous by design.** The whole mixer (all 12 input channels and 10 output channels) is computed inside **one** JACK process callback for the same block of frames. A sample entering any strip at frame *k* leaves every bus at frame *k* of the same cycle. The mixer itself adds **0 samples** of latency.
* **Virtual cables add no buffering.** They are nodes in the same PipeWire graph, driven by the same clock, and processed in the same cycle.
* **Sub-10 ms** depends on the server's period. Use 48 kHz with 128 frames: 2.67 ms per period, which gives about 6–8 ms hardware round-trip including driver headroom. Install `contrib/pipewire/pipewire.conf.d/10-vmix-lowlatency.conf` to pin this (with `max-quantum = 128`, no other app can raise it). The UI shows the measured round-trip from JACK's latency API and turns red if it reaches 10 ms or more.
* **Real-time safe.** The audio callback does no allocation, no locks, no syscalls, and cannot panic. Every gain, mute, solo, or routing change is ramped over one period, so changes don't click.

## Install

Requirements (PipeWire, the default on current Fedora, Ubuntu, Debian, Arch, and others):

| Distro         | Packages                                                     |
|----------------|--------------------------------------------------------------|
| Fedora         | `pipewire-jack-audio-connection-kit pulseaudio-utils`        |
| Arch           | `pipewire-jack libpulse`                                     |
| Debian/Ubuntu  | `pipewire-jack pulseaudio-utils`                             |

Or JACK2 (`jackd2`). The virtual cables need PipeWire; without it, use `--no-cables` and route with JACK.

```sh
cargo build --release            # zero dependencies
install -Dm755 target/release/vmix ~/.local/bin/vmix

# optional but recommended for guaranteed < 10 ms:
mkdir -p ~/.config/pipewire/pipewire.conf.d ~/.config/pipewire/pipewire-pulse.conf.d
cp contrib/pipewire/pipewire.conf.d/*.conf       ~/.config/pipewire/pipewire.conf.d/
cp contrib/pipewire/pipewire-pulse.conf.d/*.conf ~/.config/pipewire/pipewire-pulse.conf.d/
systemctl --user restart pipewire pipewire-pulse wireplumber
```

Run it with `vmix` (terminal UI) or `vmix --gui` (graphical window). On **Debian/Ubuntu**, run `pw-jack vmix` so it uses PipeWire's libjack instead of JACK2's. To run it in the background, use `contrib/systemd/vmix.service`, which runs `vmix --headless`.

## Using it

1. Start `vmix`. Eight devices appear in your sound settings: `vmix-In1-Mic` … `vmix-In6-Aux` (outputs) and `vmix-Out-B1`, `vmix-Out-B2` (microphones).
2. Point applications at a strip by setting their output device (pavucontrol, GNOME/KDE settings, or the app itself), for example Discord to `vmix-In2-Discord`. To send the whole desktop through vmix, make `vmix-In3-Desktop` the default output.
3. Choose where each strip goes with keys `1`–`5` (A1 A2 A3 B1 B2).
4. In Discord or OBS, select **`vmix-Out-B1`** as the microphone to receive the B1 mix.
5. Press `w` to save. The mixer state is also saved automatically on quit.

Keys: `↑↓` select · `←→` gain ±1 dB · `,` `.` ±0.1 dB · `0` 0 dB · `m` mute · `s` solo · `o` mono · `1-5` route · `c` link to recorder · `R` record/stop · `r` reconnect · `w` save · `q` quit

A `●` after a row's number means that channel is linked to the recorder. The line under the mixer shows the recorder: elapsed time and file while recording, otherwise the mode, format, links and folder.

## GUI

```sh
vmix --gui
```

opens the mixer in its own window: six numbered input strips, the five buses, and the recorder. Every strip has a stereo meter with a clip light, a fader (drag it, scroll over it, or use the arrow keys; double-click for 0 dB; type an exact value in the box below), mute, mono, solo, the A1–B2 routing keys, and a round button that links it to the recorder. Click a strip's name to rename it. Save, Reconnect and Quit are in the top bar, next to the sample rate, period, measured round trip, DSP load and xruns.

* The GUI has no dependencies. vmix serves the page itself on **http://127.0.0.1:8790** (this computer only) and opens it as an app window with Chromium, Chrome, Brave, Edge or Vivaldi, or in your default browser. Without `--gui`, nothing listens on the network.
* It controls the same mixer state as the terminal UI, with the same click-free ramps, and saves on quit the same way.
* Running `vmix --gui` again while it is already running just reopens the window, so it works from an app launcher. Install `contrib/vmix.desktop` to `~/.local/share/applications/` for a menu entry.
* Options: `--gui-port PORT` (default 8790; if 8790 is busy, vmix picks a free port and prints it), `--no-open` (don't open a window; open the printed URL yourself). For a background service you can open at any time, change the service to run `vmix --gui --no-open`.
* Only pages served by vmix itself can change the mixer. Requests must name `127.0.0.1`/`localhost` as their host, and changes need a header that other websites cannot send, so a web page open in your browser cannot drive it.

## Recorder

The recorder can take any combination of the 11 channels, numbered the same way everywhere: strips `1`–`6` and buses `A1`–`B2`. Link a channel with its round button in the GUI, with a numbered chip in the GUI's recorder panel, or with `c` in the terminal UI. Then press record (the big button, or `R`).

* **What is recorded:** strips after their fader (gain, mute, solo and mono applied, exactly what the strip sends to the buses), and buses as they leave the mixer.
* **One mix file** (`mode = mix`): all linked channels are added into one stereo file. Links can change while recording; each change is ramped like a routing change, so it doesn't click. A strip linked together with a bus it feeds counts twice.
* **A file per source** (`mode = multi`): one stereo file per linked channel, for example `…_1-Mic.wav`, `…_A1-Speakers.wav`. They are taken from the same audio cycle, so they start on the same sample and always have the same length; drop them into a DAW and they line up. The set of tracks is fixed when recording starts.
* **Formats:** 16-bit, 24-bit (default) or 32-bit float WAV. 16- and 24-bit files clip anything above full scale, and the GUI and terminal UI warn you when that happens; 32-bit float keeps it.
* **Files** go to `~/Music/vmix/` by default, named `YYYY-MM-DD_HH-MM-SS_<label>.wav` in local time. An existing file is never overwritten. The WAV header is rewritten every 2 seconds, so a recording is still playable if vmix is killed. Takes over 4 GB continue in `_part2.wav`, `_part3.wav` …, split at the same sample for every track.
* **Real-time safe:** the audio callback copies each cycle into a preallocated lock-free ring buffer (no allocation, locks or syscalls; see `tests/recorder_no_alloc.rs`), and a separate thread writes the files. If the disk stalls for longer than the buffer holds (about 4 s with all 11 channels, much longer for fewer), the missing part is filled with silence so the tracks stay in sync, and the UI reports how many frames were lost.
* The recorder is available in the terminal UI and the GUI. `--headless` runs without it, exactly as before.

## Configuration: `~/.config/vmix/vmix.ini`

Created with defaults on the first run (see `vmix --print-default-config`). Parsing is strict: a typo produces an error with a line number instead of being ignored.

```ini
[global]
client_name = vmix
buffer_size = 128          # period requested from PipeWire (PIPEWIRE_LATENCY); 0 = don't ask
force_buffer_size = false  # true = jack_set_buffer_size() (JACK2: changes it for every client)
create_cables = true

[strip1]
name = Mic
gain_db = 0.0              # -60 .. +12
mono = true
routes = B1                # any of A1,A2,A3,B1,B2 or none
connect = @physical        # physical capture device; may be repeated

[strip2]
connect = ^Firefox:output_F[LR]$   # or any JACK port regex

[bus.A1]
name = Speakers
connect = @physical        # physical playback device
[bus.A2]
connect = ^Headphones-description:playback_F[LR]$

[recorder]
folder = ~/Music/vmix
format = wav24             # wav16 | wav24 | wav32f
mode = mix                 # mix (one stereo file) | multi (one file per linked channel)
links = 1,A1               # 1-6 = strips, A1-A3 / B1-B2 = buses, or none
```

A config file from an earlier vmix (without `[recorder]`) still loads; the recorder then starts with the defaults above, linked to A1 only.

`@physical` picks the **first** physical device that JACK lists. With several sound cards, put an explicit regex in `connect`. You can see the exact port names in `qpwgraph`, `pw-link -io`, or `jack_lsp`. When ports appear or disappear (hot-plugged headsets, apps starting), vmix re-applies the configured connections automatically. It never removes connections you made yourself.

## Tests

```sh
cargo test                       # 52 unit tests + 2 "audio path never allocates" tests
tests/e2e/run_e2e.sh             # runs the real binary against a mock libjack (needs gcc and curl)
```

The end-to-end test drives vmix's real process callback through a mock JACK server. It checks that impulses fed to two different strips come out on A1 and B1 at the **exact same frame and cycle** they went in, with the correct mix values. It also checks that every output buffer is fully written each cycle, that 8 cables are created, wired and removed, that a stale cable from a crash is cleaned up, and that SIGINT/SIGTERM shut down cleanly. A third phase starts `vmix --gui`, drives it over HTTP exactly like the page does (including the security checks and a second `--gui` launch), records strip 1 and A1 in multi mode, and checks that both WAV files hold the impulse on the **same sample** with the correct values.

The no-allocation tests run thousands of cycles with parameters changing underneath, one of them with the recorder recording (both modes, live link changes, a full buffer). A counting allocator proves the audio path never touches the heap.

## Limitations

* Not included from Voicemeeter: EQ, VBAN network streaming, Intellipan, the compressor/gate, and playback of recordings.
* The GUI page needs a current browser (Chromium/Chrome 111+, Firefox 113+); the app-window mode needs a Chromium-based one.
* **App-side buffering is not under any mixer's control.** PulseAudio-API apps (browsers, Discord) choose their own buffer sizes. The `pipewire-pulse` snippet lowers the default, but an app that asks for 40 ms gets 40 ms. Native PipeWire and JACK apps follow the graph quantum.
* With **two different sound cards** on A1/A2, PipeWire clocks one and adaptively resamples the other, which is the correct way to handle two clock domains. Plain JACK2 can only drive one card.
* The mixer and cables were tested against a mock server. Test them on your own hardware before relying on them live.
