//! vmix — 6-strip / 5-bus virtual audio mixer for Linux (JACK / PipeWire).

mod backend;
mod cables;
mod devices;
mod gui;
mod jack;
mod lowlat;
mod sys;
mod tui;

use backend::{Backend, Wiring};
use cables::{CableSet, Cables};
use devices::Side;
use std::io::{Read, Write};
use std::path::{Path, PathBuf};
use std::process::ExitCode;
use std::sync::Arc;
use std::sync::atomic::Ordering::{Relaxed, SeqCst};
use std::sync::mpsc;
use std::time::{Duration, Instant};
use vmix::config::Config;
use vmix::engine::Shared;
use vmix::recorder::{self, RecTap, Recorder};

const HELP: &str = "\
vmix — 6-strip, 5-bus low-latency virtual audio mixer (JACK / PipeWire)

USAGE:
    vmix [--config FILE] [--no-cables]                 terminal UI
    vmix [--config FILE] [--no-cables] --gui [--no-open] [--gui-port PORT]
    vmix [--config FILE] [--no-cables] --headless
    vmix [--config FILE] --list-ports
    vmix [--config FILE] --cleanup
    vmix --low-latency [off]
    vmix --print-default-config

OPTIONS:
    -c, --config FILE        Config file (default: $XDG_CONFIG_HOME/vmix/vmix.ini)
        --gui                Graphical mixer and recorder in its own window, served
                             on http://127.0.0.1:8790 (this computer only). No
                             terminal needed. If a vmix GUI is already running,
                             this just opens its window again.
        --gui-port PORT      Port for --gui (default 8790)
        --no-open            With --gui: do not open a window (open the URL yourself)
        --headless           No UI; run until SIGINT/SIGTERM (for systemd)
        --no-cables          Do not create PipeWire virtual cables this time
                             (the config file is not changed)
        --list-ports         Show the JACK port names `connect =` can use, with a
                             ready-made line for each device, then exit
        --cleanup            Remove virtual cables left behind by a vmix that was
                             killed (refuses while that vmix is running), then exit
        --low-latency [off]  Install PipeWire settings for 128-frame periods
                             (< 10 ms round trip) and apply them now; `off` undoes it
        --print-default-config
    -h, --help
    -V, --version
";

#[derive(Debug, PartialEq)]
enum Mode {
    Run,
    ListPorts,
    Cleanup,
    LowLatency(bool),
}

struct Args {
    config: PathBuf,
    mode: Mode,
    headless: bool,
    /// Runtime only: never written into the config file.
    no_cables: bool,
    gui: bool,
    gui_port: Option<u16>,
    no_open: bool,
}

fn parse_args() -> Result<Option<Args>, String> {
    let mut a = Args {
        config: Config::default_path(),
        mode: Mode::Run,
        headless: false,
        no_cables: false,
        gui: false,
        gui_port: None,
        no_open: false,
    };
    let mut it = std::env::args().skip(1).peekable();
    let set_mode = |a: &mut Args, m: Mode| {
        if a.mode != Mode::Run {
            return Err("--list-ports, --cleanup and --low-latency are separate commands; give only one".to_string());
        }
        a.mode = m;
        Ok(())
    };
    while let Some(arg) = it.next() {
        match arg.as_str() {
            "-c" | "--config" => a.config = it.next().ok_or("--config needs a file")?.into(),
            "--headless" => a.headless = true,
            "--no-cables" => a.no_cables = true,
            "--gui" => a.gui = true,
            "--no-open" => a.no_open = true,
            "--list-ports" => set_mode(&mut a, Mode::ListPorts)?,
            "--cleanup" => set_mode(&mut a, Mode::Cleanup)?,
            "--low-latency" => {
                let on = match it.peek().map(String::as_str) {
                    Some("off") => false,
                    Some("on") => true,
                    _ => {
                        set_mode(&mut a, Mode::LowLatency(true))?;
                        continue;
                    }
                };
                it.next();
                set_mode(&mut a, Mode::LowLatency(on))?;
            }
            "--gui-port" => {
                let v = it.next().ok_or("--gui-port needs a port number")?;
                a.gui_port = Some(v.parse().ok().filter(|&p| p > 0).ok_or(format!("bad port {v:?}"))?);
            }
            "--print-default-config" => {
                print!("{}", Config::default().to_ini());
                return Ok(None);
            }
            "-h" | "--help" => {
                print!("{HELP}");
                return Ok(None);
            }
            "-V" | "--version" => {
                println!("vmix {}", env!("CARGO_PKG_VERSION"));
                return Ok(None);
            }
            other => return Err(format!("unknown argument {other:?} (see --help)")),
        }
    }
    if a.gui && a.headless {
        return Err("--gui and --headless cannot be combined (for a background service with a GUI use --gui --no-open)".into());
    }
    if !a.gui && (a.no_open || a.gui_port.is_some()) {
        return Err("--no-open and --gui-port only work together with --gui".into());
    }
    if a.mode != Mode::Run && (a.gui || a.headless || a.no_cables) {
        return Err("--list-ports, --cleanup and --low-latency do not run the mixer; drop --gui/--headless/--no-cables".into());
    }
    Ok(Some(a))
}

fn main() -> ExitCode {
    // The cable watchdog (started by vmix itself, see cables.rs).
    let mut argv = std::env::args().skip(1);
    if argv.next().as_deref() == Some(cables::REAPER_FLAG) {
        return cables::reaper_main(&argv.next().unwrap_or_default());
    }
    match run() {
        Ok(()) => ExitCode::SUCCESS,
        Err(e) => {
            eprintln!("vmix: {e}");
            ExitCode::FAILURE
        }
    }
}

fn plural(n: usize, one: &str, many: &str) -> String {
    format!("{n} {}", if n == 1 { one } else { many })
}

/// `vmix --list-ports`.
fn list_ports(path: &Path) -> Result<(), String> {
    let cfg = Config::load_or_default(path)?;
    let client = jack::JackClient::open_aux("vmix-ports")?;
    let rs = devices::Resolver::new(&client, &cfg.client_name, CableSet::for_config(&cfg));
    print!("{}", rs.report());
    Ok(())
}

/// `vmix --cleanup`: remove cables a killed vmix left behind.
fn cleanup(path: &Path) -> Result<(), String> {
    let cfg = Config::load_or_default(path)?;
    let name = &cfg.client_name;
    // A watchdog that is still there after a few seconds belongs to a vmix
    // that is running (or one that is stuck); never pull cables from under it.
    let running = || format!("vmix \"{name}\" is running; its cables are removed when it quits");
    if !cables::wait_for_reapers(name, Duration::from_secs(3)) {
        return Err(running());
    }
    if let Ok(c) = jack::JackClient::open_aux("vmix-cleanup") {
        if !c.ports(Some(&format!("^{}:in1_L$", jack::regex_escape(name))), 0).is_empty() {
            return Err(running());
        }
    }
    let n = cables::sweep(&CableSet::for_config(&cfg).node_names())?;
    println!("vmix: removed {} of \"{name}\"", plural(n, "virtual cable", "virtual cables"));
    Ok(())
}

fn run() -> Result<(), String> {
    let Some(args) = parse_args()? else { return Ok(()) };
    match args.mode {
        Mode::ListPorts => return list_ports(&args.config),
        Mode::Cleanup => return cleanup(&args.config),
        Mode::LowLatency(on) => return lowlat::command(on),
        Mode::Run => {}
    }
    let mut cfg = Config::load_or_create(&args.config)?;
    // `--no-cables` applies to this run only. It is deliberately not stored
    // in `cfg`, which is written back to the file on save and on quit.
    let create_cables = cfg.create_cables && !args.no_cables;
    if !args.headless && !args.gui && !sys::stdin_is_tty() {
        return Err("not running in a terminal; use --gui or --headless".into());
    }
    let gui_port = args.gui_port.unwrap_or(gui::DEFAULT_PORT);
    if args.gui && gui::probe(gui_port) {
        // Already running (e.g. launched again from the app menu): show it.
        let url = gui::url(gui_port);
        if args.no_open || !gui::open_window(&url) {
            eprintln!("vmix: already running; open {url}");
        }
        return Ok(());
    }
    sys::install_signal_handlers();

    // Ask PipeWire for a small period for our node (honoured as long as it is
    // within the server's min/max quantum). Harmless under JACK2.
    if cfg.buffer_size > 0 && std::env::var_os("PIPEWIRE_LATENCY").is_none() {
        // SAFETY: still single-threaded at this point.
        unsafe { std::env::set_var("PIPEWIRE_LATENCY", format!("{}/48000", cfg.buffer_size)) };
    }

    let client = jack::JackClient::open(&cfg.client_name)?;
    let mut notes: Vec<String> = Vec::new();
    if cfg.force_buffer_size && cfg.buffer_size > 0 && client.buffer_size() != cfg.buffer_size {
        if let Err(e) = client.set_buffer_size(cfg.buffer_size) {
            notes.push(e);
        }
    }

    // We own the JACK name now, so cables with our names that are still
    // loaded were left by a vmix that was killed: let its watchdog finish,
    // then remove whatever is left (also with --no-cables).
    let cable_set = CableSet::for_config(&cfg);
    if !cables::wait_for_reapers(&cfg.client_name, Duration::from_secs(3)) {
        notes.push("the cable watchdog of an earlier vmix is still running".into());
    }
    if let Ok(n @ 1..) = cables::sweep(&cable_set.node_names()) {
        notes.push(format!("removed {} left behind by a vmix that was killed", plural(n, "virtual cable", "virtual cables")));
    }
    // Cables before ports so they exist when we auto-connect.
    let (cables, warn) =
        if create_cables { Cables::create(&cfg.client_name, &cable_set) } else { (Cables::none(), Vec::new()) };
    notes.extend(warn);
    let cables_active = cables.count() > 0;

    let shared = Shared::new();
    cfg.apply(&shared);
    // The recorder exists only when there is a UI to drive it; --headless
    // runs exactly the same audio path as before.
    let tap = if args.headless { None } else { Some(RecTap::new()) };
    let backend = Backend::start(client, shared.clone(), tap.clone())?;
    let recorder = tap.map(|t| Arc::new(Recorder::new(t, backend.client().sample_rate(), cfg.recorder.settings())));

    // Give PipeWire a moment to publish the cable ports.
    if cables_active {
        let deadline = Instant::now() + Duration::from_secs(3);
        while Instant::now() < deadline {
            let all = cable_set.all().all(|c| !backend.client().ports(Some(&c.jack_regex()), 0).is_empty());
            if all {
                break;
            }
            std::thread::sleep(Duration::from_millis(50));
        }
    }

    let set_ref = if cables_active { Some(&cable_set) } else { None };
    let result = match &recorder {
        None => run_headless(&backend, &cfg, set_ref, notes),
        Some(rec) if args.gui => {
            let opts = GuiOpts { port: gui_port, explicit: args.gui_port.is_some(), open: !args.no_open };
            run_gui(&backend, &mut cfg, &args.config, set_ref, &shared, rec, cables.count(), notes, &opts)
        }
        Some(rec) => run_tui(&backend, &mut cfg, &args.config, set_ref, &shared, rec, cables.count(), notes),
    };
    if let Some(rec) = &recorder {
        rec.shutdown(); // finish the files while the audio thread still runs
    }
    drop(backend); // close JACK first...
    drop(cables); // ...then remove the cables
    result
}

fn run_headless(backend: &Backend, cfg: &Config, set: Option<&CableSet>, notes: Vec<String>) -> Result<(), String> {
    for n in notes {
        eprintln!("vmix: warning: {n}");
    }
    let c = backend.client();
    eprintln!(
        "vmix: running as JACK client \"{}\" at {} Hz, {} frames ({:.2} ms period). Ctrl-C to stop.",
        backend.client_name,
        c.sample_rate(),
        c.buffer_size(),
        c.buffer_size() as f64 * 1000.0 / c.sample_rate().max(1) as f64
    );
    let mut last_errs: Vec<String> = Vec::new();
    let mut changed_at: Option<Instant> = Some(Instant::now());
    let mut lat = LatencyCheck::new();
    while !sys::QUIT.load(SeqCst) {
        if backend.ctl.shutdown.load(Relaxed) {
            return Err("the JACK/PipeWire server shut down".into());
        }
        if backend.ctl.ports_changed.swap(false, Relaxed) {
            changed_at = Some(Instant::now());
        }
        if changed_at.is_some_and(|t| t.elapsed() > Duration::from_millis(250)) {
            changed_at = None;
            let w = backend.autoconnect(cfg, set);
            print_wiring(backend, cfg, &w, &mut last_errs);
        }
        if let Some(m) = lat.poll(backend, cfg) {
            eprintln!("vmix: warning: {m}");
        }
        std::thread::sleep(Duration::from_millis(50));
    }
    Ok(())
}

/// Problems from an auto-connect pass on stderr (when they change). When a
/// pattern matched nothing, also list the ports that side could use.
fn print_wiring(backend: &Backend, cfg: &Config, w: &Wiring, last: &mut Vec<String>) {
    if w.errs == *last {
        return;
    }
    for e in &w.errs {
        eprintln!("vmix: {e}");
    }
    for (side, what) in [(Side::Strip, "a strip can take (JACK outputs)"), (Side::Bus, "a bus can feed (JACK inputs)")] {
        if w.missed[side as usize] {
            eprintln!("vmix:   ports {what}:");
            for l in backend.port_listing(cfg, side) {
                eprintln!("vmix:     {l}");
            }
        }
    }
    *last = w.errs.clone();
}

/// Looks at the latency once, shortly after start (JACK reports port
/// latencies only once the ports are connected).
struct LatencyCheck {
    at: Option<Instant>,
}

impl LatencyCheck {
    fn new() -> Self {
        LatencyCheck { at: Some(Instant::now() + Duration::from_millis(1500)) }
    }

    fn poll(&mut self, backend: &Backend, cfg: &Config) -> Option<String> {
        if self.at.is_none_or(|t| Instant::now() < t) {
            return None;
        }
        self.at = None;
        let c = backend.client();
        let (lat_in, lat_out) = backend.io_latency();
        lowlat::advice(&lowlat::Facts {
            sample_rate: c.sample_rate(),
            period: c.buffer_size(),
            requested: cfg.buffer_size,
            lat_in,
            lat_out,
            pipewire: cables::pactl(&["info"]).ok().map(|i| i.contains("PipeWire")),
            state: lowlat::state(&lowlat::pw_dir()),
        })
    }
}

fn append(status: &mut String, msg: &str) {
    if !status.is_empty() {
        status.push_str(" | ");
    }
    status.push_str(msg);
}

/// The 11 channel names, numbered like the recorder sources (strips, then buses).
fn channel_names(cfg: &Config) -> Vec<String> {
    cfg.strips.iter().map(|s| s.name.clone()).chain(cfg.buses.iter().map(|b| b.name.clone())).collect()
}

/// Mixer state + recorder settings into the config (before saving).
fn capture_all(cfg: &mut Config, shared: &Shared, rec: &Recorder) {
    cfg.capture(shared);
    cfg.recorder.set_settings(&rec.settings());
}

fn file_name(p: &Path) -> String {
    p.file_name().map_or_else(|| p.display().to_string(), |f| f.to_string_lossy().into_owned())
}

/// Start or stop recording; returns a message for the status line.
fn toggle_record(rec: &Recorder, shared: &Shared, names: &[String]) -> Result<String, String> {
    if rec.is_recording() {
        rec.stop();
        return Ok("recording stopped".into());
    }
    let files = rec.start(shared.rec_links.load(Relaxed), names, &sys::local_timestamp())?;
    // Short: the status line must fit 80 columns (the folder is on the REC line).
    Ok(match files.len() {
        1 => format!("recording {}", files.first().map_or(String::new(), |f| file_name(f))),
        n => format!("recording {n} tracks, one file per channel"),
    })
}

/// Recorder status for the terminal UI.
fn rec_line(rec: &Recorder, shared: &Shared) -> tui::RecLine {
    let st = rec.status();
    let set = rec.settings();
    if st.on {
        let t = st.seconds() as u64;
        let mut text = format!("{:02}:{:02}:{:02}  {}  ", t / 3600, t / 60 % 60, t % 60, st.mode.as_str());
        if let Some(f) = st.files.first() {
            text.push_str(&file_name(f));
        }
        if st.files.len() > 1 {
            text.push_str(&format!(" +{}", st.files.len() - 1));
        }
        if st.dropped > 0 {
            text.push_str(&format!("  ({} frames lost: disk too slow)", st.dropped));
        }
        if st.clipped > 0 {
            text.push_str("  CLIPPING: lower a gain or use wav32f");
        }
        tui::RecLine { on: true, text }
    } else if let Some(e) = &st.error {
        tui::RecLine { on: false, text: e.clone() }
    } else {
        let links = recorder::format_links(shared.rec_links.load(Relaxed));
        tui::RecLine {
            on: false,
            text: format!("{} · {} · links {links} → {}", set.mode.as_str(), set.format.as_str(), set.folder),
        }
    }
}

#[allow(clippy::too_many_arguments)]
fn run_tui(
    backend: &Backend,
    cfg: &mut Config,
    path: &std::path::Path,
    set: Option<&CableSet>,
    shared: &Shared,
    rec: &Recorder,
    cable_count: usize,
    notes: Vec<String>,
) -> Result<(), String> {
    let _term = sys::RawTerminal::enter()?;

    let (tx, rx) = mpsc::channel::<Vec<u8>>();
    std::thread::spawn(move || {
        let mut stdin = std::io::stdin();
        let mut buf = [0u8; 64];
        loop {
            match stdin.read(&mut buf) {
                Ok(0) | Err(_) => break,
                Ok(n) => {
                    if tx.send(buf[..n].to_vec()).is_err() {
                        break;
                    }
                }
            }
        }
    });

    let mut view = tui::View::default();
    if !notes.is_empty() {
        view.status = format!("\x1b[33m{}\x1b[0m", notes.join(" | "));
    }
    let mut pending = Vec::new();
    let mut conn: Vec<String> = Vec::new();
    let mut changed_at: Option<Instant> = Some(Instant::now());
    let mut force_connect = false;
    let mut lat = (0u32, 0u32);
    let mut lat_at = Instant::now() - Duration::from_secs(10);
    let mut lat_check = LatencyCheck::new();
    let mut out = std::io::stdout();
    let frame = Duration::from_millis(33);

    loop {
        let t0 = Instant::now();
        if sys::QUIT.load(SeqCst) {
            break;
        }
        if backend.ctl.shutdown.load(Relaxed) {
            return Err("the JACK/PipeWire server shut down".into());
        }

        while let Ok(bytes) = rx.try_recv() {
            pending.extend_from_slice(&bytes);
        }
        let mut quit = false;
        for k in tui::decode(&mut pending) {
            match view.handle(shared, k) {
                tui::Action::None => {}
                tui::Action::Quit => quit = true,
                tui::Action::Reconnect => force_connect = true,
                tui::Action::Save => {
                    capture_all(cfg, shared, rec);
                    view.status = match cfg.save(path) {
                        Ok(()) => format!("saved {}", path.display()),
                        Err(e) => format!("\x1b[31msave failed: {e}\x1b[0m"),
                    };
                }
                tui::Action::Record => {
                    view.status = match toggle_record(rec, shared, &channel_names(cfg)) {
                        Ok(m) => m,
                        Err(e) => format!("\x1b[31mrecorder: {e}\x1b[0m"),
                    };
                }
            }
        }
        if quit {
            break;
        }

        if backend.ctl.ports_changed.swap(false, Relaxed) {
            changed_at = Some(Instant::now());
        }
        if force_connect || changed_at.is_some_and(|t| t.elapsed() > Duration::from_millis(250)) {
            let w = backend.autoconnect(cfg, set);
            conn = w.desc;
            if force_connect || !w.errs.is_empty() {
                view.status = if w.errs.is_empty() {
                    "all configured connections made".into()
                } else {
                    format!("\x1b[33m{}\x1b[0m", w.errs.join(" | "))
                };
            }
            force_connect = false;
            changed_at = None;
            lat_at = Instant::now() - Duration::from_secs(10); // refresh latency now
        }
        if lat_at.elapsed() > Duration::from_millis(500) {
            lat = backend.io_latency();
            lat_at = Instant::now();
        }
        if let Some(m) = lat_check.poll(backend, cfg) {
            view.latency = Some(m);
        }

        view.cols = sys::term_cols().unwrap_or(tui::MIN_COLS);
        view.update_meters(shared);
        view.rec = rec_line(rec, shared);
        let c = backend.client();
        let info = tui::Info {
            client: &backend.client_name,
            sample_rate: c.sample_rate(),
            buffer_size: c.buffer_size(),
            cpu: c.cpu_load(),
            xruns: shared.xruns.load(Relaxed),
            oversize: shared.oversize_cycles.load(Relaxed),
            lat_in: lat.0,
            lat_out: lat.1,
            cables: cable_count,
        };
        let screen = view.render(shared, cfg, &info, &conn);
        let _ = out.write_all(screen.as_bytes());
        let _ = out.flush();

        if let Some(rest) = frame.checked_sub(t0.elapsed()) {
            std::thread::sleep(rest);
        }
    }

    // Remember the mixer state for next time.
    capture_all(cfg, shared, rec);
    cfg.save(path)
}

struct GuiOpts {
    port: u16,
    explicit: bool,
    open: bool,
}

/// Same control loop as the terminal UI, driving the GUI instead.
#[allow(clippy::too_many_arguments)]
fn run_gui(
    backend: &Backend,
    cfg: &mut Config,
    path: &std::path::Path,
    set: Option<&CableSet>,
    shared: &Arc<Shared>,
    rec: &Arc<Recorder>,
    cable_count: usize,
    notes: Vec<String>,
    opts: &GuiOpts,
) -> Result<(), String> {
    let hub = gui::Hub::new(shared.clone(), rec.clone());
    hub.set_names(channel_names(cfg));
    let port = gui::start(hub.clone(), opts.port, opts.explicit)?;
    let url = gui::url(port);
    for n in &notes {
        eprintln!("vmix: warning: {n}");
    }
    let c = backend.client();
    eprintln!(
        "vmix: running as JACK client \"{}\" at {} Hz, {} frames ({:.2} ms period).",
        backend.client_name,
        c.sample_rate(),
        c.buffer_size(),
        c.buffer_size() as f64 * 1000.0 / c.sample_rate().max(1) as f64
    );
    if port != opts.port {
        eprintln!("vmix: port {} is busy, using {port} instead", opts.port);
    }
    eprintln!("vmix: GUI at {url}  (quit with the power button in the GUI, or Ctrl-C)");
    if opts.open && !gui::open_window(&url) {
        eprintln!("vmix: could not open a window; open {url} in a browser");
    }

    let mut status = notes.join(" | ");
    let mut view = tui::View::default(); // same meter ballistics as the terminal UI
    let mut conn: Vec<String> = Vec::new();
    let mut last_errs: Vec<String> = Vec::new();
    let mut changed_at: Option<Instant> = Some(Instant::now());
    let mut force_connect = false;
    let mut lat = (0u32, 0u32);
    let mut lat_at = Instant::now() - Duration::from_secs(10);
    let mut lat_check = LatencyCheck::new();
    let frame = Duration::from_millis(33);

    let result = loop {
        let t0 = Instant::now();
        if sys::QUIT.load(SeqCst) {
            break Ok(());
        }
        if backend.ctl.shutdown.load(Relaxed) {
            break Err("the JACK/PipeWire server shut down".to_string());
        }

        let mut quit = false;
        for r in hub.take_requests() {
            match r {
                gui::Request::Quit => quit = true,
                gui::Request::Reconnect => force_connect = true,
                gui::Request::Save => {
                    capture_all(cfg, shared, rec);
                    status = match cfg.save(path) {
                        Ok(()) => format!("saved {}", path.display()),
                        Err(e) => format!("save failed: {e}"),
                    };
                }
                gui::Request::Rename(ch, name) => {
                    let (n, id) = if ch < cfg.strips.len() {
                        (&mut cfg.strips[ch].name, recorder::source_id(ch))
                    } else {
                        (&mut cfg.buses[ch - cfg.strips.len()].name, recorder::source_id(ch))
                    };
                    *n = name;
                    hub.set_names(channel_names(cfg));
                    status = format!("renamed {id}; the virtual cable keeps its old name until vmix restarts");
                }
            }
        }
        if quit {
            break Ok(());
        }

        if backend.ctl.ports_changed.swap(false, Relaxed) {
            changed_at = Some(Instant::now());
        }
        if force_connect || changed_at.is_some_and(|t| t.elapsed() > Duration::from_millis(250)) {
            let w = backend.autoconnect(cfg, set);
            print_wiring(backend, cfg, &w, &mut last_errs);
            if force_connect || !w.errs.is_empty() {
                status = if w.errs.is_empty() { "all configured connections made".into() } else { w.errs.join(" | ") };
            }
            conn = w.desc;
            force_connect = false;
            changed_at = None;
            lat_at = Instant::now() - Duration::from_secs(10);
        }
        if lat_at.elapsed() > Duration::from_millis(500) {
            lat = backend.io_latency();
            lat_at = Instant::now();
        }
        if let Some(m) = lat_check.poll(backend, cfg) {
            eprintln!("vmix: warning: {m}");
            append(&mut status, &m);
        }

        view.update_meters(shared);
        let info = tui::Info {
            client: &backend.client_name,
            sample_rate: c.sample_rate(),
            buffer_size: c.buffer_size(),
            cpu: c.cpu_load(),
            xruns: shared.xruns.load(Relaxed),
            oversize: shared.oversize_cycles.load(Relaxed),
            lat_in: lat.0,
            lat_out: lat.1,
            cables: cable_count,
        };
        let rec_status = rec.status();
        let rec_settings = rec.settings();
        hub.publish(gui::state_json(
            shared,
            &gui::Frame {
                info: &info,
                cfg,
                meters: view.meters(),
                conn: &conn,
                status: &status,
                rec: &rec_status,
                rec_settings: &rec_settings,
            },
        ));

        if let Some(rest) = frame.checked_sub(t0.elapsed()) {
            std::thread::sleep(rest);
        }
    };
    hub.close();
    result?;
    // Remember the mixer state for next time (like the terminal UI).
    capture_all(cfg, shared, rec);
    cfg.save(path)
}
