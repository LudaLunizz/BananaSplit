//! Terminal control surface (ANSI escape codes, no dependencies).
//!
//! ```text
//!   #  NAME             GAIN  L          R           PEAK  M S O  A1 A2 A3 B1 B2
//! > 1● Mic             -12.0  ████████·· ███████···   -18  M · O  A1 A2 A3 B1 B2
//!  A2  Blue Headphones  +0.0  ████······ ████······   -31  · · ·
//! ```
//!
//! Fits 80 columns with 15-character names; a wider terminal gives the
//! extra columns to the names (up to 32, the longest name vmix accepts).
//! A longer name ends in `…`; the line under the mixer always shows the
//! selected row's full name.
//!
//! `●` after the number = channel is linked to the recorder (`c` toggles it,
//! `R` starts/stops a recording).

use std::fmt::Write as _;
use std::sync::atomic::Ordering::Relaxed;
use vmix::config::Config;
use vmix::engine::{BUS_IDS, MAX_GAIN_DB, MIN_GAIN_DB, NUM_BUSES, NUM_STRIPS, Shared, gain_to_db};

pub const ROWS: usize = NUM_STRIPS + NUM_BUSES;
/// The screen is laid out for at least this many columns.
pub const MIN_COLS: usize = 80;
const METER_W: usize = 10;
const NAME_W: usize = 15;
const MAX_NAME_W: usize = 32;
const FLOOR_DB: f32 = -60.0;
const DECAY_DB_PER_FRAME: f32 = 1.5; // ~45 dB/s at 30 fps

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum Key {
    Up,
    Down,
    Left,
    Right,
    Char(u8),
}

/// Decode raw terminal bytes into keys. An incomplete escape sequence at the
/// end of `buf` is left in place for the next call.
pub fn decode(buf: &mut Vec<u8>) -> Vec<Key> {
    let mut keys = Vec::new();
    let mut i = 0;
    while i < buf.len() {
        let b = buf[i];
        if b == 0x1b {
            if i + 1 >= buf.len() {
                break; // wait for more bytes
            }
            if buf[i + 1] == b'[' || buf[i + 1] == b'O' {
                if i + 2 >= buf.len() {
                    break;
                }
                // skip parameters like "1;2" until the final byte
                let mut j = i + 2;
                while j < buf.len() && (buf[j].is_ascii_digit() || buf[j] == b';') {
                    j += 1;
                }
                if j >= buf.len() {
                    break;
                }
                match buf[j] {
                    b'A' => keys.push(Key::Up),
                    b'B' => keys.push(Key::Down),
                    b'C' => keys.push(Key::Right),
                    b'D' => keys.push(Key::Left),
                    _ => {}
                }
                i = j + 1;
            } else {
                i += 1; // lone ESC: ignore
            }
        } else {
            keys.push(Key::Char(b));
            i += 1;
        }
    }
    buf.drain(..i.min(buf.len()));
    keys
}

pub enum Action {
    None,
    Quit,
    Save,
    Reconnect,
    /// Start or stop the recorder.
    Record,
}

/// One line of recorder status, filled in by the main loop.
#[derive(Debug, Default, Clone)]
pub struct RecLine {
    pub on: bool,
    pub text: String,
}

pub struct View {
    pub sel: usize,
    meters: [[f32; 2]; ROWS],
    pub status: String,
    pub rec: RecLine,
    /// Terminal width (the main loop updates it every frame).
    pub cols: usize,
    /// Latency advice from the startup check (its own line, under the status).
    pub latency: Option<String>,
}

impl Default for View {
    fn default() -> Self {
        Self {
            sel: 0,
            meters: [[FLOOR_DB; 2]; ROWS],
            status: String::new(),
            rec: RecLine::default(),
            cols: MIN_COLS,
            latency: None,
        }
    }
}

/// Cut `s` to `max` visible characters (ANSI colour codes don't count),
/// ending in `…` if anything was cut.
fn fit(s: &str, max: usize) -> String {
    if visible_len(s) <= max {
        return s.to_string();
    }
    let mut o = String::with_capacity(s.len());
    let mut n = 0;
    let mut it = s.chars();
    while let Some(c) = it.next() {
        if c == '\x1b' {
            o.push(c);
            for d in it.by_ref() {
                o.push(d);
                if d.is_ascii_alphabetic() {
                    break;
                }
            }
        } else if n + 1 >= max {
            o.push('…');
            o.push_str("\x1b[0m");
            break;
        } else {
            o.push(c);
            n += 1;
        }
    }
    o
}

/// Plain text cut to `max` characters, ending in `…` if anything was cut.
fn ellipsize(s: &str, max: usize) -> String {
    if s.chars().count() <= max {
        return s.to_string();
    }
    s.chars().take(max.saturating_sub(1)).chain(['…']).collect()
}

fn visible_len(s: &str) -> usize {
    let mut n = 0;
    let mut it = s.chars();
    while let Some(c) = it.next() {
        if c == '\x1b' {
            for d in it.by_ref() {
                if d.is_ascii_alphabetic() {
                    break;
                }
            }
        } else {
            n += 1;
        }
    }
    n
}

pub struct Info<'a> {
    pub client: &'a str,
    pub sample_rate: u32,
    pub buffer_size: u32,
    pub cpu: f32,
    pub xruns: u32,
    pub oversize: u32,
    pub lat_in: u32,
    pub lat_out: u32,
    pub cables: usize,
}

fn step_gain(cur: f32, delta: f32) -> f32 {
    (((cur + delta) * 10.0).round() / 10.0).clamp(MIN_GAIN_DB, MAX_GAIN_DB)
}

impl View {
    pub fn handle(&mut self, sh: &Shared, key: Key) -> Action {
        let is_strip = self.sel < NUM_STRIPS;
        let gain = |v: &Self| {
            if v.sel < NUM_STRIPS { &sh.strips[v.sel].gain_db } else { &sh.buses[v.sel - NUM_STRIPS].gain_db }
        };
        let toggle = |a: &std::sync::atomic::AtomicBool| {
            a.fetch_xor(true, Relaxed);
        };
        match key {
            Key::Up | Key::Char(b'k') => self.sel = self.sel.saturating_sub(1),
            Key::Down | Key::Char(b'j') | Key::Char(b'\t') => self.sel = (self.sel + 1).min(ROWS - 1),
            Key::Left | Key::Char(b'h') => gain(self).store(step_gain(gain(self).load(), -1.0)),
            Key::Right | Key::Char(b'l') => gain(self).store(step_gain(gain(self).load(), 1.0)),
            Key::Char(b',') => gain(self).store(step_gain(gain(self).load(), -0.1)),
            Key::Char(b'.') => gain(self).store(step_gain(gain(self).load(), 0.1)),
            Key::Char(b'0') => gain(self).store(0.0),
            Key::Char(b'm') => {
                if is_strip { toggle(&sh.strips[self.sel].mute) } else { toggle(&sh.buses[self.sel - NUM_STRIPS].mute) }
            }
            Key::Char(b'o') => {
                if is_strip { toggle(&sh.strips[self.sel].mono) } else { toggle(&sh.buses[self.sel - NUM_STRIPS].mono) }
            }
            Key::Char(b's') if is_strip => toggle(&sh.strips[self.sel].solo),
            Key::Char(c @ b'1'..=b'5') if is_strip => sh.toggle_route(self.sel, (c - b'1') as usize),
            // rows are numbered like the recorder sources: strips 1-6, then A1..B2
            Key::Char(b'c') => sh.toggle_rec_link(self.sel),
            Key::Char(b'R') => return Action::Record,
            Key::Char(b'r') => return Action::Reconnect,
            Key::Char(b'w') => return Action::Save,
            Key::Char(b'q') | Key::Char(3) | Key::Char(4) => return Action::Quit, // q, Ctrl-C, Ctrl-D
            _ => {}
        }
        Action::None
    }

    /// Current meter levels in dB (`[row][L/R]`, floor -60), after ballistics.
    pub fn meters(&self) -> &[[f32; 2]; ROWS] {
        &self.meters
    }

    /// Pull peaks from the audio thread and apply meter ballistics.
    pub fn update_meters(&mut self, sh: &Shared) {
        for r in 0..ROWS {
            for ch in 0..2 {
                let pk = if r < NUM_STRIPS { sh.strips[r].peak[ch].take() } else { sh.buses[r - NUM_STRIPS].peak[ch].take() };
                let db = gain_to_db(pk).max(FLOOR_DB);
                let held = self.meters[r][ch] - DECAY_DB_PER_FRAME;
                self.meters[r][ch] = db.max(held).max(FLOOR_DB);
            }
        }
    }

    /// Width of the NAME column for the current terminal width.
    fn name_w(&self) -> usize {
        NAME_W + self.cols.saturating_sub(MIN_COLS).min(MAX_NAME_W - NAME_W)
    }

    pub fn render(&self, sh: &Shared, cfg: &Config, info: &Info, conn: &[String]) -> String {
        let mut o = String::with_capacity(8192);
        o.push_str("\x1b[H");
        let line_end = "\x1b[0m\x1b[K\n";
        let cols = self.cols.max(MIN_COLS);
        let nw = self.name_w();
        // sel+id+link, name, gain, two meters, peak, flags, routes
        let row_w = 4 + 1 + nw + 1 + 6 + 2 + METER_W + 1 + METER_W + 8 + 5 + 2 + 14; // 79 at 80 cols

        let period_ms = if info.sample_rate > 0 { info.buffer_size as f64 * 1000.0 / info.sample_rate as f64 } else { 0.0 };
        let (rt_ms, measured) = if info.sample_rate > 0 && (info.lat_in > 0 || info.lat_out > 0) {
            ((info.lat_in + info.lat_out) as f64 * 1000.0 / info.sample_rate as f64, true)
        } else {
            (2.0 * period_ms, false)
        };
        let ok = rt_ms < 10.0;
        let _ = write!(o, "\x1b[1m VMIX\x1b[0m  6 strips · 5 buses · JACK client \"{}\" · {} cables{line_end}", info.client, info.cables);
        let _ = write!(
            o,
            " {} Hz · {} fr · {:.2} ms/period · RTT {}{:.2} ms {} · DSP {:.0}% · xruns {}{}{line_end}",
            info.sample_rate,
            info.buffer_size,
            period_ms,
            if measured { "" } else { "~" },
            rt_ms,
            if ok { "\x1b[32m[OK <10ms]\x1b[0m" } else { "\x1b[31;1m[>=10ms!]\x1b[0m" },
            info.cpu,
            info.xruns,
            if info.oversize > 0 { format!(" \x1b[31moversize {}\x1b[0m", info.oversize) } else { String::new() },
        );
        let _ = write!(o, "{line_end}");
        let _ = write!(
            o,
            "\x1b[2m  #  {:<nw$} {:>6}  {:<mw$} {:<mw$}  PEAK  M S O  A1 A2 A3 B1 B2{line_end}",
            "NAME",
            "GAIN",
            "L",
            "R",
            mw = METER_W
        );

        let any_solo = sh.strips.iter().any(|s| s.solo.load(Relaxed));
        let links = sh.rec_links.load(Relaxed);
        for r in 0..ROWS {
            if r == NUM_STRIPS {
                let _ = write!(o, "\x1b[2m  ── buses {}{line_end}", "─".repeat(row_w - 11));
            }
            let selected = r == self.sel;
            let (id, name, gain, mute, solo, mono, routes) = if r < NUM_STRIPS {
                let p = &sh.strips[r];
                (
                    format!("{}", r + 1),
                    cfg.strips[r].name.as_str(),
                    p.gain_db.load(),
                    p.mute.load(Relaxed),
                    Some(p.solo.load(Relaxed)),
                    p.mono.load(Relaxed),
                    Some(p.routes.load(Relaxed)),
                )
            } else {
                let b = r - NUM_STRIPS;
                let p = &sh.buses[b];
                (BUS_IDS[b].to_string(), cfg.buses[b].name.as_str(), p.gain_db.load(), p.mute.load(Relaxed), None, p.mono.load(Relaxed), None)
            };
            let dimmed = r < NUM_STRIPS && any_solo && solo == Some(false);
            let name = ellipsize(name, nw);
            let dim = if dimmed { "\x1b[2m" } else { "" };
            let link = if links & (1 << r) != 0 { format!("\x1b[31m●\x1b[0m{dim}") } else { " ".into() };
            let _ = write!(
                o,
                "{}{}{:>2}{} {:<nw$} {:>+6.1}  ",
                if selected { "\x1b[7m>\x1b[0m" } else { " " },
                dim,
                id,
                link,
                name,
                gain
            );
            meter(&mut o, self.meters[r][0]);
            o.push(' ');
            meter(&mut o, self.meters[r][1]);
            let pk = self.meters[r][0].max(self.meters[r][1]);
            // always 8 columns, so the flags line up on silent rows too
            if pk <= FLOOR_DB {
                let _ = write!(o, "    -∞  ");
            } else {
                let _ = write!(o, "  {:>4.0}  ", pk);
            }
            flag(&mut o, mute, 'M', "41;97");
            o.push(' ');
            match solo {
                Some(v) => flag(&mut o, v, 'S', "43;30"),
                None => o.push(' '),
            }
            o.push(' ');
            flag(&mut o, mono, 'O', "46;30");
            o.push_str("  ");
            if let Some(mask) = routes {
                for (b, idb) in BUS_IDS.iter().enumerate() {
                    let sep = if b > 0 { " " } else { "" };
                    if mask & (1 << b) != 0 {
                        let _ = write!(o, "{sep}\x1b[42;30m{idb}\x1b[0m");
                    } else {
                        let _ = write!(o, "{sep}\x1b[2m{idb}\x1b[0m");
                    }
                }
            }
            o.push_str(line_end);
        }

        let _ = write!(o, "{line_end}");
        let sel_name = if self.sel < NUM_STRIPS { &cfg.strips[self.sel].name } else { &cfg.buses[self.sel - NUM_STRIPS].name };
        let conn_text = conn.get(self.sel).map_or("", String::as_str);
        let arrow = if self.sel < NUM_STRIPS { "←" } else { "→" };
        let sel_line = fit(&format!("\x1b[1m{sel_name}\x1b[0m {arrow} {conn_text}"), cols - 2);
        let _ = write!(o, " {sel_line}{line_end}");
        // Recorder line (in place of a blank line, so the screen still fits 24 rows).
        let rec_text = fit(&self.rec.text, cols - 9);
        if self.rec.on {
            let _ = write!(o, " \x1b[41;97m ● REC \x1b[0m {rec_text}{line_end}");
        } else {
            let _ = write!(o, " \x1b[2m ○ rec \x1b[0m \x1b[2m{rec_text}{line_end}");
        }
        let _ = write!(o, "\x1b[2m ↑↓ select  ←→ gain ±1 dB  , . ±0.1 dB  0 = 0 dB  m mute  s solo  o mono{line_end}");
        let _ = write!(o, "\x1b[2m 1-5 route A1-B2  c rec link  R record  r reconnect  w save  q quit{line_end}");
        let _ = write!(o, " {}{line_end}", fit(&self.status, cols - 2));
        // Row 23 of 24 (the last row stays empty so the screen never scrolls).
        match &self.latency {
            Some(m) => {
                let _ = write!(o, " \x1b[33m{}{line_end}", fit(m, cols - 2));
            }
            None if !ok => {
                let _ = write!(o, " \x1b[31mround trip >= 10 ms: run `vmix --low-latency` once (see README, Latency){line_end}");
            }
            None => {}
        }
        o.push_str("\x1b[J");
        o
    }
}

fn flag(o: &mut String, on: bool, c: char, color: &str) {
    if on {
        let _ = write!(o, "\x1b[{color}m{c}\x1b[0m");
    } else {
        o.push_str("\x1b[2m·\x1b[0m");
    }
}

fn meter(o: &mut String, db: f32) {
    let lit = (((db - FLOOR_DB) / -FLOOR_DB) * METER_W as f32).round().clamp(0.0, METER_W as f32) as usize;
    for i in 0..METER_W {
        // cell i covers up to this level
        let cell_db = FLOOR_DB + (i + 1) as f32 * (-FLOOR_DB / METER_W as f32);
        if i < lit {
            let col = if cell_db > -3.0 { "31" } else if cell_db > -12.0 { "33" } else { "32" };
            let _ = write!(o, "\x1b[{col}m█");
        } else {
            o.push_str("\x1b[2m·");
        }
    }
    o.push_str("\x1b[0m");
}

#[cfg(test)]
mod tests {
    use super::*;

    fn strip_ansi(s: &str) -> String {
        let mut o = String::new();
        let mut it = s.chars().peekable();
        while let Some(c) = it.next() {
            if c == '\x1b' {
                for d in it.by_ref() {
                    if d.is_ascii_alphabetic() {
                        break;
                    }
                }
            } else {
                o.push(c);
            }
        }
        o
    }

    #[test]
    fn decode_keys_and_partial_sequences() {
        let mut b = b"q\x1b[A\x1b[1;2B\x1bOCx\x1b[".to_vec();
        let k = decode(&mut b);
        assert_eq!(k, vec![Key::Char(b'q'), Key::Up, Key::Down, Key::Right, Key::Char(b'x')]);
        assert_eq!(b, b"\x1b[");
        b.push(b'D');
        assert_eq!(decode(&mut b), vec![Key::Left]);
        assert!(b.is_empty());
    }

    #[test]
    fn handle_controls_shared_state() {
        let sh = Shared::default();
        let mut v = View::default();
        v.handle(&sh, Key::Right);
        v.handle(&sh, Key::Char(b','));
        assert!((sh.strips[0].gain_db.load() - 0.9).abs() < 1e-6);
        for _ in 0..100 {
            v.handle(&sh, Key::Right);
        }
        assert_eq!(sh.strips[0].gain_db.load(), MAX_GAIN_DB);
        v.handle(&sh, Key::Char(b'4'));
        assert_eq!(sh.strips[0].routes.load(Relaxed), 0b01000);
        v.handle(&sh, Key::Char(b'm'));
        assert!(sh.strips[0].mute.load(Relaxed));
        for _ in 0..50 {
            v.handle(&sh, Key::Down);
        }
        assert_eq!(v.sel, ROWS - 1);
        v.handle(&sh, Key::Char(b's')); // no solo on buses
        v.handle(&sh, Key::Char(b'1')); // no routing on buses
        v.handle(&sh, Key::Char(b'm'));
        assert!(sh.buses[NUM_BUSES - 1].mute.load(Relaxed));
        // recorder: c links the selected row (B2 = source 10), R asks to record
        v.handle(&sh, Key::Char(b'c'));
        assert_eq!(sh.rec_links.load(Relaxed), 1 << 10);
        v.sel = 0;
        v.handle(&sh, Key::Char(b'c'));
        v.handle(&sh, Key::Char(b'c'));
        v.handle(&sh, Key::Char(b'c'));
        assert_eq!(sh.rec_links.load(Relaxed), (1 << 10) | 1);
        assert!(matches!(v.handle(&sh, Key::Char(b'R')), Action::Record));
        assert!(matches!(v.handle(&sh, Key::Char(b'r')), Action::Reconnect));
        assert!(matches!(v.handle(&sh, Key::Char(b'q')), Action::Quit));
    }

    #[test]
    fn render_does_not_panic() {
        let sh = Shared::default();
        let cfg = Config::default();
        let mut v = View::default();
        sh.strips[0].peak[0].take();
        v.update_meters(&sh);
        let info = Info { client: "vmix", sample_rate: 48000, buffer_size: 128, cpu: 1.0, xruns: 0, oversize: 0, lat_in: 128, lat_out: 256, cables: 8 };
        let s = v.render(&sh, &cfg, &info, &[]);
        assert!(s.contains("RTT 8.00 ms"));
        // every line fits an 80-column terminal
        let plain = strip_ansi(&s);
        for line in plain.lines() {
            assert!(line.chars().count() <= 80, "{} cols: {line}", line.chars().count());
        }
        assert!(s.contains("Mic"));
        // ...also while recording with a very long file name and linked rows,
        // and the screen still fits a 24-row terminal
        sh.rec_links.store(0b111_1111_1111, Relaxed);
        sh.strips[2].solo.store(true, Relaxed);
        v.rec = RecLine { on: true, text: format!("00:00:01  multi  {}", "x".repeat(200)) };
        let s = v.render(&sh, &cfg, &info, &[]);
        let plain = strip_ansi(&s);
        for line in plain.lines() {
            assert!(line.chars().count() <= 80, "{} cols: {line}", line.chars().count());
        }
        assert!(plain.lines().count() < 24, "{} rows", plain.lines().count());
        assert!(plain.contains("● REC"));
        assert!(plain.contains(" 1● Mic"));
        assert!(plain.contains("A1● Speakers"));
        assert!(plain.contains('…'));
    }

    fn fits(s: &str, cols: usize) -> Vec<String> {
        let plain = strip_ansi(s);
        for line in plain.lines() {
            assert!(line.chars().count() < cols, "{} cols (limit {}): {line}", line.chars().count(), cols - 1);
        }
        plain.lines().map(str::to_string).collect()
    }

    #[test]
    fn long_names_at_80_and_wider() {
        let sh = Shared::default();
        let mut cfg = Config::default();
        cfg.buses[1].name = "Blue Headphones".into(); // the review: "Blue Headph"
        cfg.strips[3].name = "Game capture (Elgato HD60 S+)".into(); // 29 chars
        let info = Info { client: "vmix", sample_rate: 48000, buffer_size: 128, cpu: 1.0, xruns: 3, oversize: 0, lat_in: 416, lat_out: 416, cables: 8 };
        cfg.apply(&sh);
        let mut v = View {
            status: format!("\x1b[33mstrip 2: nothing matches \"^alsa_input.usb-Blue\" — {}\x1b[0m", "x".repeat(100)),
            sel: NUM_STRIPS + 1,
            ..View::default()
        };
        let lines = fits(&v.render(&sh, &cfg, &info, &[]), 80);
        // RTT >= 10 ms gets its own line even while the status line is busy
        assert!(lines.iter().any(|l| l.contains("run `vmix --low-latency` once")), "{lines:#?}");
        v.latency = Some(format!("round trip 17.3 ms at 128 frames (goal < 10 ms): run `vmix --low-latency` {}", "x".repeat(20)));
        let lines = fits(&v.render(&sh, &cfg, &info, &[]), 80);
        assert!(lines.len() < 24, "{} rows", lines.len());
        assert!(lines.last().unwrap().starts_with(" round trip 17.3 ms") && lines.last().unwrap().ends_with('…'));
        assert!(lines.iter().any(|l| l.starts_with(">A2  Blue Headphones  ")), "{lines:#?}");
        assert!(lines.iter().any(|l| l == " Blue Headphones → "), "full name of the selected row");
        assert!(lines.iter().any(|l| l.starts_with("  4  Game capture (…  ")), "{lines:#?}");
        assert!(lines.iter().any(|l| l.ends_with('…')), "long status is cut, not wrapped");
        assert!(lines.iter().any(|l| l.contains("RTT 17.33 ms [>=10ms!]")));
        // header columns line up with the rows (strip 1 is mono: "· · O")
        let hdr = lines.iter().find(|l| l.contains("NAME")).unwrap();
        let row = lines.iter().find(|l| l.starts_with("  1")).unwrap();
        let at = |s: &str, needle: &str| s.find(needle).map(|b| s[..b].chars().count()).unwrap();
        assert_eq!(at(hdr, "A1 A2"), at(row, "A1 A2"));
        assert_eq!(at(hdr, "M S O"), at(row, "· · O"));
        assert_eq!(at(hdr, "GAIN"), at(row, "+0.0"), "GAIN ends where the value ends");
        assert_eq!(at(hdr, "PEAK"), at(row, "-∞") - 2);
        // silent and loud rows have the same layout (PEAK used to be 7 or 8 wide)
        let mut v2 = View { sel: ROWS - 1, ..View::default() };
        v2.meters[1] = [-20.0, -24.0];
        let lines = fits(&v2.render(&sh, &cfg, &info, &[]), 80);
        let s1 = lines.iter().find(|l| l.starts_with("  1")).unwrap();
        let s2 = lines.iter().find(|l| l.starts_with("  2")).unwrap();
        assert_eq!(s1.chars().count(), s2.chars().count(), "\n{s1}\n{s2}");
        assert!(s2.contains("  -20  ") && s1.contains("    -∞  "), "\n{s1}\n{s2}");
        // a wider terminal shows more of the name
        v.cols = 100;
        let lines = fits(&v.render(&sh, &cfg, &info, &[]), 100);
        assert!(lines.iter().any(|l| l.starts_with("  4  Game capture (Elgato HD60 S+) ")), "{lines:#?}");
        v.cols = 300; // capped at 32-char names
        let lines = fits(&v.render(&sh, &cfg, &info, &[]), 300);
        assert!(lines.iter().filter(|l| l.contains("NAME")).all(|l| l.chars().count() < 100));
    }

    #[test]
    fn fit_and_ellipsize() {
        assert_eq!(ellipsize("Blue Headphones", 15), "Blue Headphones");
        assert_eq!(ellipsize("Blue Headphones!", 15), "Blue Headphone…");
        assert_eq!(fit("\x1b[33mabcdef\x1b[0m", 6), "\x1b[33mabcdef\x1b[0m");
        let f = fit("\x1b[33mabcdefg\x1b[0m", 6);
        assert_eq!(strip_ansi(&f), "abcde…");
        assert!(f.starts_with("\x1b[33m"));
    }
}
