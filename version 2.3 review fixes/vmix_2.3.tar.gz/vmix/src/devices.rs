//! Which device is which.
//!
//! PipeWire knows devices by node.name
//! (`alsa_input.usb-Blue_Microphones_Yeti-00.analog-stereo`), but its JACK
//! layer names their ports after the description
//! (`Yeti Stereo Microphone Analog Stereo:capture_FL`), adding `-NN` when
//! two devices share a description. `connect` patterns are matched against
//! the JACK names. This module bridges the two for `@default`, `@physical`,
//! `vmix --list-ports` and the hints shown when a pattern matches nothing.
//! Device information comes from `pactl` (C locale); without it (or under
//! plain JACK2) `@default` falls back to `@physical`.

use crate::cables::{self, CableSet};
use crate::jack::{JackClient, PORT_IS_INPUT, PORT_IS_OUTPUT, PORT_IS_PHYSICAL, regex_escape};
use crate::sys;
use std::cell::OnceCell;
use std::ffi::c_ulong;
use std::fmt::Write as _;
use vmix::config::{DEFAULT_DEVICE, PHYSICAL};

#[derive(Debug, Clone, PartialEq)]
pub struct Device {
    /// PipeWire node.name.
    pub name: String,
    pub description: String,
    pub nick: Option<String>,
    /// Source (input device) or sink (output device).
    pub is_source: bool,
    /// A "Monitor of <output>" source.
    pub is_monitor: bool,
}

#[derive(Debug, Default, Clone, PartialEq)]
pub struct Devices {
    pub pipewire: bool,
    pub default_source: Option<String>,
    pub default_sink: Option<String>,
    pub list: Vec<Device>,
}

fn field<'a>(line: &'a str, key: &str) -> Option<&'a str> {
    line.trim().strip_prefix(key).map(str::trim)
}

/// Parse `pactl list sinks` / `pactl list sources` (C locale).
fn parse_list(text: &str, is_source: bool) -> Vec<Device> {
    let mut out = Vec::new();
    let mut cur: Option<Device> = None;
    for line in text.lines() {
        if !line.trim().is_empty() && !line.starts_with(char::is_whitespace) {
            // "Sink #52" / "Source #53" starts the next device
            out.extend(cur.take());
            cur = Some(Device { name: String::new(), description: String::new(), nick: None, is_source, is_monitor: false });
            continue;
        }
        let Some(d) = cur.as_mut() else { continue };
        if let Some(v) = field(line, "Name:") {
            d.name = v.into();
        } else if let Some(v) = field(line, "Description:") {
            d.description = v.into();
        } else if let Some(v) = field(line, "Monitor of Sink:") {
            d.is_monitor |= v != "n/a";
        } else if let Some(v) = field(line, "node.nick = ") {
            d.nick = Some(v.trim_matches('"').to_string()).filter(|n| !n.is_empty());
        } else if let Some(v) = field(line, "device.class = ") {
            d.is_monitor |= v.trim_matches('"') == "monitor";
        }
    }
    out.extend(cur);
    out.retain(|d| !d.name.is_empty());
    for d in &mut out {
        d.is_monitor |= is_source && d.name.ends_with(".monitor");
    }
    out
}

/// Parse `pactl info`, `pactl list sinks` and `pactl list sources`.
pub fn parse(info: &str, sinks: &str, sources: &str) -> Devices {
    let mut d = Devices::default();
    let set = |v: &str| Some(v.to_string()).filter(|s| !s.is_empty() && !s.starts_with('@'));
    for line in info.lines() {
        if let Some(v) = field(line, "Server Name:") {
            d.pipewire = v.contains("PipeWire");
        } else if let Some(v) = field(line, "Default Sink:") {
            d.default_sink = set(v);
        } else if let Some(v) = field(line, "Default Source:") {
            d.default_source = set(v);
        }
    }
    d.list = parse_list(sinks, false);
    d.list.extend(parse_list(sources, true));
    d
}

impl Devices {
    pub fn query() -> Result<Devices, String> {
        let info = cables::pactl(&["info"])?;
        let sinks = cables::pactl(&["list", "sinks"])?;
        let sources = cables::pactl(&["list", "sources"])?;
        Ok(parse(&info, &sinks, &sources))
    }
}

/// How well JACK client name `client` matches device label `label`:
/// 3 exact, 2 with PipeWire's "-NN" de-duplication suffix, 1 cut off at
/// JACK's client-name limit, 0 no match.
fn label_score(label: &str, client: &str) -> u8 {
    if label.is_empty() {
        return 0;
    }
    if client == label {
        return 3;
    }
    if let Some(rest) = client.strip_prefix(label).and_then(|r| r.strip_prefix('-')) {
        if !rest.is_empty() && rest.bytes().all(|b| b.is_ascii_digit()) {
            return 2;
        }
    }
    if client.chars().count() >= 60 && label.starts_with(client) {
        return 1;
    }
    0
}

/// Does JACK client `client` belong to device `d`? (Description is the
/// default; nick with `jack.short-name`; node.name as a last resort.)
pub fn client_score(d: &Device, client: &str) -> u8 {
    [Some(d.description.as_str()), d.nick.as_deref(), Some(d.name.as_str())]
        .into_iter()
        .flatten()
        .map(|l| label_score(l, client))
        .max()
        .unwrap_or(0)
}

pub fn client_of(port: &str) -> &str {
    port.split_once(':').map_or(port, |(c, _)| c)
}

fn short_of(port: &str) -> &str {
    port.split_once(':').map_or(port, |(_, s)| s)
}

/// PipeWire flags an output device's monitor ports as outputs (and
/// sometimes as physical); feeding them into a strip records the speakers.
pub fn is_monitor_port(port: &str) -> bool {
    short_of(port).starts_with("monitor")
}

type Group = (String, Vec<String>);

/// Ports grouped by JACK client, in the order JACK lists them.
fn groups(ports: Vec<String>) -> Vec<Group> {
    let mut g: Vec<Group> = Vec::new();
    for p in ports {
        let c = client_of(&p).to_string();
        match g.iter_mut().find(|(k, _)| *k == c) {
            Some((_, v)) => v.push(p),
            None => g.push((c, vec![p])),
        }
    }
    g
}

/// Index of the group that belongs to `d` (best match, first on ties).
fn best_index(gs: &[Group], d: &Device) -> Option<usize> {
    let mut best: Option<(u8, usize)> = None;
    for (i, (client, _)) in gs.iter().enumerate() {
        let s = client_score(d, client);
        if s > 0 && best.is_none_or(|(b, _)| s > b) {
            best = Some((s, i));
        }
    }
    best.map(|(_, i)| i)
}

/// Which side of the mixer a pattern is for.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum Side {
    /// A strip takes audio from JACK *output* ports (capture, monitor, apps).
    Strip,
    /// A bus sends audio to JACK *input* ports (playback, apps).
    Bus,
}

impl Side {
    pub fn flag(self) -> c_ulong {
        match self {
            Side::Strip => PORT_IS_OUTPUT,
            Side::Bus => PORT_IS_INPUT,
        }
    }
    fn other(self) -> Side {
        match self {
            Side::Strip => Side::Bus,
            Side::Bus => Side::Strip,
        }
    }
    /// "default input" (microphone) / "default output" (speakers).
    fn device(self) -> &'static str {
        match self {
            Side::Strip => "input",
            Side::Bus => "output",
        }
    }
}

/// What a `connect` value resolved to.
#[derive(Debug, Default)]
pub struct Resolved {
    /// Full JACK port names, best first (vmix uses the first two).
    pub ports: Vec<String>,
    /// Why nothing matched, or what fallback was used.
    pub note: Option<String>,
    /// A regex that matched nothing (worth listing the real port names).
    pub missed: bool,
}

/// Resolves `connect` values against the live JACK graph. Asks pactl at
/// most once (lazily), so make one per auto-connect pass.
pub struct Resolver<'a> {
    client: &'a JackClient,
    /// "vmix:" — never connect the mixer to itself.
    own: String,
    cables: CableSet,
    devs: OnceCell<Result<Devices, String>>,
}

impl<'a> Resolver<'a> {
    pub fn new(client: &'a JackClient, own_client: &str, cables: CableSet) -> Self {
        Resolver { client, own: format!("{own_client}:"), cables, devs: OnceCell::new() }
    }

    fn devices(&self) -> Result<&Devices, String> {
        self.devs.get_or_init(Devices::query).as_ref().map_err(Clone::clone)
    }

    /// Ports matching a regex (or all with `None`), without our own.
    pub fn ports(&self, pattern: Option<&str>, flags: c_ulong) -> Vec<String> {
        self.client.ports(pattern, flags).into_iter().filter(|p| !p.starts_with(&self.own)).collect()
    }

    /// The desktop's default device for this side, or why it can't be used.
    fn default_device(&self, side: Side) -> Result<&Device, String> {
        let d = self.devices()?;
        if !d.pipewire {
            return Err("the sound server is not PipeWire".into());
        }
        let name = match side {
            Side::Strip => &d.default_source,
            Side::Bus => &d.default_sink,
        };
        let name = name.as_deref().ok_or_else(|| format!("no default {} is set", side.device()))?;
        let dev = d.list.iter().find(|x| x.name == name && x.is_source == (side == Side::Strip));
        let desc = dev.map_or(name, |x| x.description.as_str());
        if self.cables.owns(name, desc) {
            return Err(format!("the default {} is vmix's own \"{desc}\"", side.device()));
        }
        let dev = dev.ok_or_else(|| format!("pactl does not list the default {} \"{name}\"", side.device()))?;
        if dev.is_monitor {
            return Err(format!("the default input \"{desc}\" records an output (that would loop)"));
        }
        Ok(dev)
    }

    pub fn resolve(&self, pattern: &str, side: Side) -> Resolved {
        match pattern {
            PHYSICAL => self.physical(side, None),
            DEFAULT_DEVICE => match self.default_device(side) {
                Ok(dev) => {
                    let gs = groups(self.ports(None, side.flag()).into_iter().filter(|p| !is_monitor_port(p)).collect());
                    match best_index(&gs, dev) {
                        Some(i) => Resolved { ports: gs.into_iter().nth(i).map(|g| g.1).unwrap_or_default(), ..Default::default() },
                        None => Resolved {
                            note: Some(format!("the default {} \"{}\" has no JACK ports yet", side.device(), dev.description)),
                            ..Default::default()
                        },
                    }
                }
                Err(why) => self.physical(side, Some(format!("{DEFAULT_DEVICE}: {why}; using {PHYSICAL}"))),
            },
            pat => {
                let ports = self.ports(Some(pat), side.flag());
                if ports.is_empty() {
                    Resolved { note: Some(format!("nothing matches \"{pat}\"{}", self.miss_hint(pat, side))), missed: true, ..Default::default() }
                } else {
                    Resolved { ports, ..Default::default() }
                }
            }
        }
    }

    /// Physical ports of one device: the default device if it is physical,
    /// else the first one JACK lists.
    fn physical(&self, side: Side, note: Option<String>) -> Resolved {
        let gs = groups(self.ports(None, side.flag() | PORT_IS_PHYSICAL).into_iter().filter(|p| !is_monitor_port(p)).collect());
        if gs.is_empty() {
            let what = if side == Side::Strip { "capture" } else { "playback" };
            let prefix = note.map_or(String::new(), |n| format!("{n}, but "));
            return Resolved { note: Some(format!("{prefix}there is no physical {what} device")), ..Default::default() };
        }
        let i = self.default_device(side).ok().and_then(|d| best_index(&gs, d)).unwrap_or(0);
        Resolved { ports: gs.into_iter().nth(i).map(|g| g.1).unwrap_or_default(), note, missed: false }
    }

    /// Why a regex probably matched nothing, as a short suffix.
    fn miss_hint(&self, pat: &str, side: Side) -> String {
        if sys::regex_match(pat, "").is_none() {
            return " (not a valid regular expression)".into();
        }
        let wrong = self.ports(Some(pat), side.other().flag());
        if let Some(p) = wrong.first() {
            return match side {
                Side::Strip => format!(" that sends audio; \"{p}\" is an input (a strip needs capture, monitor or app output ports)"),
                Side::Bus => format!(" that takes audio; \"{p}\" is an output (a bus needs playback or app input ports)"),
            };
        }
        let all = groups(self.ports(None, side.flag()));
        if let Ok(devs) = self.devices() {
            for dev in &devs.list {
                let group = best_index(&all, dev).map(|i| &all[i]);
                let hit = sys::regex_match(pat, &dev.name) == Some(true)
                    || group.is_some_and(|(_, ports)| {
                        ports.iter().any(|p| sys::regex_match(pat, &format!("{}:{}", dev.name, short_of(p))) == Some(true))
                    });
                if hit {
                    return match group {
                        Some((client, _)) => format!(
                            " — that is the PipeWire node name; JACK calls this device \"{client}\": use connect = ^{}:",
                            regex_escape(client)
                        ),
                        None => format!(" — that is the PipeWire node name of \"{}\", which has no such JACK ports", dev.description),
                    };
                }
            }
        }
        for (client, ports) in &all {
            if sys::regex_match(pat, client) == Some(true) {
                return format!(" — JACK port names are client:port, e.g. \"{}\"", ports[0]);
            }
        }
        let low = pat.to_lowercase();
        if let Some(p) = all.iter().flat_map(|g| &g.1).find(|p| sys::regex_match(&low, &p.to_lowercase()) == Some(true)) {
            return format!(" — names are case-sensitive: did you mean \"{p}\"?");
        }
        " (vmix --list-ports shows the names)".into()
    }

    /// One line per JACK client on this side: `Name  (port port …)`.
    pub fn listing(&self, side: Side) -> Vec<String> {
        groups(self.ports(None, side.flag()))
            .into_iter()
            .map(|(client, ports)| format!("{client}  ({})", shorts(&ports)))
            .collect()
    }

    /// The report printed by `vmix --list-ports`.
    pub fn report(&self) -> String {
        let mut o = String::new();
        let devs = self.devices().ok();
        let _ = writeln!(o, "connect = patterns match these JACK names (client:port), not PipeWire node names.");
        let _ = writeln!(o, "vmix connects the first two matching ports to L and R (one port: to both).");
        for side in [Side::Strip, Side::Bus] {
            let head = match side {
                Side::Strip => "\nFor a strip, [strip1] … [strip6] (ports that send audio):",
                Side::Bus => "\nFor a bus, [bus.A1] … [bus.B2] (ports that take audio):",
            };
            let _ = writeln!(o, "{head}");
            let physical = self.ports(None, side.flag() | PORT_IS_PHYSICAL);
            let default = self.default_device(side).ok();
            let gs = groups(self.ports(None, side.flag()));
            if gs.is_empty() {
                let _ = writeln!(o, "  (none)");
            }
            let default_i = default.and_then(|d| best_index(&gs, d));
            for (i, (client, ports)) in gs.iter().enumerate() {
                let mut tags: Vec<String> = Vec::new();
                if ports.iter().any(|p| physical.contains(p)) {
                    tags.push("physical".into());
                }
                if default_i == Some(i) {
                    tags.push(format!("default {}", side.device()));
                }
                if ports.iter().all(|p| is_monitor_port(p)) {
                    tags.push("records an output (can loop)".into());
                }
                if self.cables.owns(client, client) {
                    tags.push("vmix cable".into());
                }
                let node = devs.and_then(|d| {
                    d.list
                        .iter()
                        .filter(|x| x.is_source == (side == Side::Strip) || ports.iter().all(|p| is_monitor_port(p)))
                        .filter(|x| client_score(x, client) >= 2)
                        .map(|x| x.name.as_str())
                        .find(|n| *n != client)
                });
                if let Some(n) = node {
                    tags.push(format!("PipeWire node {n}"));
                }
                let _ = writeln!(o, "  {client:<38}  {}", shorts(ports));
                if !tags.is_empty() {
                    let _ = writeln!(o, "      {}", tags.join(" · "));
                }
                let _ = writeln!(o, "      connect = ^{}:", regex_escape(client));
            }
        }
        let _ = writeln!(o);
        for kw in [DEFAULT_DEVICE, PHYSICAL] {
            let show = |side: Side| {
                let r = self.resolve(kw, side);
                match (r.ports.first(), r.note) {
                    (Some(p), None) => format!("\"{}\"", client_of(p)),
                    (Some(p), Some(n)) => format!("\"{}\" ({n})", client_of(p)),
                    (None, n) => format!("nothing ({})", n.unwrap_or_default()),
                }
            };
            let _ = writeln!(o, "{kw:<9} → strips: {}", show(Side::Strip));
            let _ = writeln!(o, "{:<9} → buses:  {}", "", show(Side::Bus));
        }
        if devs.is_none() {
            let _ = writeln!(o, "(pactl is not available, so default devices and PipeWire node names are not shown)");
        }
        o
    }
}

/// Short port names of one client, at most 6 (`a b c … +4`).
fn shorts(ports: &[String]) -> String {
    let mut v: Vec<&str> = ports.iter().take(6).map(|p| short_of(p)).collect();
    let more = format!("+{}", ports.len().saturating_sub(6));
    if ports.len() > 6 {
        v.push(&more);
    }
    v.join(" ")
}

#[cfg(test)]
mod tests {
    use super::*;

    const INFO: &str = "Server String: /run/user/1000/pulse/native\nServer Name: PulseAudio (on PipeWire 1.2.7)\n\
        Default Sink: alsa_output.usb-Blue_Yeti-00.analog-stereo\nDefault Source: alsa_input.usb-Blue_Yeti-00.analog-stereo\n";
    const SOURCES: &str = "Source #48\n\tState: SUSPENDED\n\tName: alsa_input.usb-Razer_Kiyo-02.analog-stereo\n\
        \tDescription: Razer Kiyo Analog Stereo\n\tDriver: PipeWire\n\tMonitor of Sink: n/a\n\tProperties:\n\
        \t\tnode.name = \"alsa_input.usb-Razer_Kiyo-02.analog-stereo\"\n\t\tnode.nick = \"Razer Kiyo\"\n\
        \t\tdevice.description = \"Razer Kiyo\"\n\n\
        Source #52\n\tName: alsa_input.usb-Blue_Yeti-00.analog-stereo\n\tDescription: Yeti Stereo Microphone Analog Stereo\n\
        \tMonitor of Sink: n/a\n\tProperties:\n\t\tnode.nick = \"Yeti Stereo Microphone\"\n\n\
        Source #53\n\tName: alsa_output.usb-Blue_Yeti-00.analog-stereo.monitor\n\
        \tDescription: Monitor of Yeti Stereo Microphone Analog Stereo\n\tMonitor of Sink: alsa_output.usb-Blue_Yeti-00.analog-stereo\n";
    const SINKS: &str = "Sink #51\n\tName: alsa_output.usb-Blue_Yeti-00.analog-stereo\n\
        \tDescription: Yeti Stereo Microphone Analog Stereo\n\tMonitor Source: alsa_output.usb-Blue_Yeti-00.analog-stereo.monitor\n";

    #[test]
    fn parses_pactl() {
        let d = parse(INFO, SINKS, SOURCES);
        assert!(d.pipewire);
        assert_eq!(d.default_source.as_deref(), Some("alsa_input.usb-Blue_Yeti-00.analog-stereo"));
        assert_eq!(d.default_sink.as_deref(), Some("alsa_output.usb-Blue_Yeti-00.analog-stereo"));
        assert_eq!(d.list.len(), 4);
        let sink = &d.list[0];
        assert!(!sink.is_source && !sink.is_monitor && sink.description == "Yeti Stereo Microphone Analog Stereo");
        let kiyo = &d.list[1];
        assert!(kiyo.is_source && !kiyo.is_monitor);
        assert_eq!(kiyo.description, "Razer Kiyo Analog Stereo");
        assert_eq!(kiyo.nick.as_deref(), Some("Razer Kiyo"));
        assert!(d.list[3].is_monitor && d.list[3].is_source);
        // JACK2 + PulseAudio, or no defaults
        let p = parse("Server Name: pulseaudio\nDefault Sink: @DEFAULT_SINK@\n", "", "");
        assert!(!p.pipewire && p.default_sink.is_none() && p.list.is_empty());
    }

    #[test]
    fn jack_names_map_to_devices() {
        let d = parse(INFO, SINKS, SOURCES);
        let yeti_in = &d.list[2];
        assert_eq!(client_score(yeti_in, "Yeti Stereo Microphone Analog Stereo"), 3);
        assert_eq!(client_score(yeti_in, "Yeti Stereo Microphone Analog Stereo-63"), 2);
        assert_eq!(client_score(yeti_in, "Yeti Stereo Microphone"), 3); // nick (jack.short-name)
        assert_eq!(client_score(yeti_in, "Yeti Stereo Microphone Analog Stereo-6x"), 0);
        assert_eq!(client_score(yeti_in, "Yeti"), 0);
        assert_eq!(client_score(&d.list[1], "Yeti Stereo Microphone Analog Stereo"), 0);
        let long = Device { name: "n".into(), description: "x".repeat(80), nick: None, is_source: true, is_monitor: false };
        assert_eq!(client_score(&long, &"x".repeat(63)), 1);
        assert_eq!(client_score(&long, &"x".repeat(20)), 0);
    }

    #[test]
    fn grouping_and_best_group() {
        let ports = ["Razer Kiyo Analog Stereo:capture_FL", "Razer Kiyo Analog Stereo:capture_FR", "Yeti Stereo Microphone Analog Stereo-63:capture_FL", "Yeti Stereo Microphone Analog Stereo-63:capture_FR", "Yeti Stereo Microphone Analog Stereo:capture_FL"];
        let gs = groups(ports.iter().map(|s| s.to_string()).collect());
        assert_eq!(gs.len(), 3);
        assert_eq!(gs[0].1.len(), 2);
        let d = parse(INFO, SINKS, SOURCES);
        assert_eq!(best_index(&gs, &d.list[2]), Some(2), "exact name beats the -NN copy");
        assert_eq!(best_index(&gs[..2], &d.list[2]), Some(1));
        assert_eq!(best_index(&gs, &d.list[1]), Some(0));
        assert!(is_monitor_port("Speakers:monitor_FL") && !is_monitor_port("Yeti:capture_FL"));
        assert_eq!(shorts(&gs[0].1), "capture_FL capture_FR");
        let many: Vec<String> = (1..=9).map(|i| format!("system:capture_{i}")).collect();
        assert_eq!(shorts(&many), "capture_1 capture_2 capture_3 capture_4 capture_5 capture_6 +3");
    }
}
