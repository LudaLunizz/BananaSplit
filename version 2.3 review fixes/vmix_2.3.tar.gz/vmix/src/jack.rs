//! Minimal JACK client binding, loaded at runtime with `dlopen`.
//!
//! Loading at runtime (instead of linking) means one binary works with
//! JACK2's `libjack.so.0` and with PipeWire's drop-in `libjack.so.0`
//! (`pw-jack vmix`, or distro packages that make PipeWire the system
//! libjack). Only the ~20 functions vmix needs are bound; signatures follow
//! `<jack/jack.h>`, `<jack/types.h>` and `<jack/port.h>`.

use std::ffi::{CStr, CString, c_char, c_int, c_ulong, c_void};
use std::sync::OnceLock;

pub type Client = *mut c_void;
pub type Port = *mut c_void;

pub const PORT_IS_INPUT: c_ulong = 0x1;
pub const PORT_IS_OUTPUT: c_ulong = 0x2;
pub const PORT_IS_PHYSICAL: c_ulong = 0x4;
const NO_START_SERVER: c_int = 0x01;
const USE_EXACT_NAME: c_int = 0x02;
const STATUS_NAME_NOT_UNIQUE: c_int = 0x04;
const EEXIST: c_int = 17; // JACK2 returns EEXIST, PipeWire's libjack -EEXIST
pub const LATENCY_CAPTURE: c_int = 0;
pub const LATENCY_PLAYBACK: c_int = 1;
pub const AUDIO_TYPE: &CStr = c"32 bit float mono audio";

#[repr(C)]
#[derive(Default, Clone, Copy)]
pub struct LatencyRange {
    pub min: u32,
    pub max: u32,
}

pub type ProcessCb = unsafe extern "C" fn(nframes: u32, arg: *mut c_void) -> c_int;
pub type XrunCb = unsafe extern "C" fn(arg: *mut c_void) -> c_int;
pub type ShutdownCb = unsafe extern "C" fn(arg: *mut c_void);
pub type PortRegCb = unsafe extern "C" fn(port: u32, register: c_int, arg: *mut c_void);
pub type MessageCb = unsafe extern "C" fn(msg: *const c_char);

unsafe extern "C" fn quiet(_msg: *const c_char) {}

unsafe extern "C" {
    fn dlopen(filename: *const c_char, flag: c_int) -> *mut c_void;
    fn dlsym(handle: *mut c_void, symbol: *const c_char) -> *mut c_void;
    fn dlerror() -> *mut c_char;
}
const RTLD_NOW: c_int = 2;

macro_rules! jack_api {
    ($( $name:ident : $ty:ty ),* $(,)?) => {
        pub struct Lib { $( pub $name: $ty, )* }
        impl Lib {
            /// # Safety
            /// `h` must be a valid handle returned by `dlopen` for a JACK library.
            unsafe fn resolve(h: *mut c_void) -> Result<Self, String> {
                Ok(Self { $( $name: {
                    let sym = concat!(stringify!($name), "\0");
                    // SAFETY: valid handle + NUL-terminated name.
                    let p = unsafe { dlsym(h, sym.as_ptr().cast()) };
                    if p.is_null() {
                        return Err(format!("libjack has no symbol `{}`", stringify!($name)));
                    }
                    // SAFETY: the symbol has the C signature declared in the JACK headers.
                    unsafe { std::mem::transmute::<*mut c_void, $ty>(p) }
                }, )* })
            }
        }
    };
}

jack_api! {
    jack_client_open: unsafe extern "C" fn(*const c_char, c_int, *mut c_int, ...) -> Client,
    jack_client_close: unsafe extern "C" fn(Client) -> c_int,
    jack_get_client_name: unsafe extern "C" fn(Client) -> *const c_char,
    jack_activate: unsafe extern "C" fn(Client) -> c_int,
    jack_deactivate: unsafe extern "C" fn(Client) -> c_int,
    jack_set_process_callback: unsafe extern "C" fn(Client, Option<ProcessCb>, *mut c_void) -> c_int,
    jack_set_xrun_callback: unsafe extern "C" fn(Client, Option<XrunCb>, *mut c_void) -> c_int,
    jack_set_port_registration_callback: unsafe extern "C" fn(Client, Option<PortRegCb>, *mut c_void) -> c_int,
    jack_on_shutdown: unsafe extern "C" fn(Client, Option<ShutdownCb>, *mut c_void),
    jack_port_register: unsafe extern "C" fn(Client, *const c_char, *const c_char, c_ulong, c_ulong) -> Port,
    jack_port_get_buffer: unsafe extern "C" fn(Port, u32) -> *mut c_void,
    jack_port_name: unsafe extern "C" fn(Port) -> *const c_char,
    jack_port_get_latency_range: unsafe extern "C" fn(Port, c_int, *mut LatencyRange),
    jack_connect: unsafe extern "C" fn(Client, *const c_char, *const c_char) -> c_int,
    jack_get_ports: unsafe extern "C" fn(Client, *const c_char, *const c_char, c_ulong) -> *mut *const c_char,
    jack_free: unsafe extern "C" fn(*mut c_void),
    jack_get_sample_rate: unsafe extern "C" fn(Client) -> u32,
    jack_get_buffer_size: unsafe extern "C" fn(Client) -> u32,
    jack_set_buffer_size: unsafe extern "C" fn(Client, u32) -> c_int,
    jack_cpu_load: unsafe extern "C" fn(Client) -> f32,
    jack_set_error_function: unsafe extern "C" fn(Option<MessageCb>),
    jack_set_info_function: unsafe extern "C" fn(Option<MessageCb>),
}

static LIB: OnceLock<Result<Lib, String>> = OnceLock::new();

/// Load libjack once per process.
pub fn lib() -> Result<&'static Lib, String> {
    LIB.get_or_init(|| {
        let mut errs = Vec::new();
        for name in [c"libjack.so.0", c"libjack.so"] {
            // SAFETY: NUL-terminated library name.
            let h = unsafe { dlopen(name.as_ptr(), RTLD_NOW) };
            if !h.is_null() {
                // SAFETY: handle just returned by dlopen.
                return unsafe { Lib::resolve(h) };
            }
            // SAFETY: dlerror returns NULL or a valid C string.
            let e = unsafe { dlerror() };
            if !e.is_null() {
                errs.push(unsafe { CStr::from_ptr(e) }.to_string_lossy().into_owned());
            }
        }
        Err(format!(
            "could not load libjack ({}).\n  Install PipeWire's JACK support (Fedora: pipewire-jack-audio-connection-kit, \
             Arch: pipewire-jack, Debian/Ubuntu: pipewire-jack) or JACK2, then run `vmix` \
             (or `pw-jack vmix` on Debian/Ubuntu).",
            errs.join("; ")
        ))
    })
    .as_ref()
    .map_err(Clone::clone)
}

fn status_text(st: c_int) -> String {
    const BITS: [(c_int, &str); 13] = [
        (0x01, "general failure"),
        (0x02, "invalid option"),
        (0x04, "name not unique"),
        (0x08, "server started"),
        (0x10, "unable to connect to the JACK/PipeWire server"),
        (0x20, "server communication error"),
        (0x40, "no such client"),
        (0x80, "unable to load internal client"),
        (0x100, "unable to initialize client"),
        (0x200, "unable to access shared memory"),
        (0x400, "client/server protocol version mismatch"),
        (0x800, "backend error"),
        (0x1000, "client zombified"),
    ];
    let v: Vec<&str> = BITS.iter().filter(|(b, _)| st & b != 0).map(|(_, s)| *s).collect();
    if v.is_empty() { format!("status 0x{st:x}") } else { v.join(", ") }
}

/// An open (not necessarily active) JACK client. Closing deactivates it.
pub struct JackClient {
    pub lib: &'static Lib,
    pub raw: Client,
}

// The JACK client API is thread-safe for the non-RT calls we make from the
// control thread; the raw pointer itself is just a handle.
unsafe impl Send for JackClient {}

impl JackClient {
    pub fn open(name: &str) -> Result<Self, String> {
        Self::open_with(name, true)
    }

    /// A short-lived helper client (`--list-ports`, `--cleanup`): any name
    /// JACK hands out is fine, it registers no ports and is never activated.
    /// libjack's own messages ("Cannot connect to server socket" …) are
    /// silenced: these commands print their own, and `--cleanup` runs from
    /// systemd's ExecStopPost, when the server may already be gone.
    pub fn open_aux(name: &str) -> Result<Self, String> {
        let lib = lib()?;
        // SAFETY: `quiet` is a valid callback for the whole process lifetime.
        unsafe {
            (lib.jack_set_error_function)(Some(quiet));
            (lib.jack_set_info_function)(Some(quiet));
        }
        Self::open_with(name, false)
    }

    fn open_with(name: &str, exact: bool) -> Result<Self, String> {
        let lib = lib()?;
        let cname = CString::new(name).map_err(|_| "client name contains NUL".to_string())?;
        let mut status: c_int = 0;
        // SAFETY: valid C string + out-param; no variadic args since we pass
        // neither JackServerName nor JackLoadName.
        // USE_EXACT_NAME: a second instance with the same name fails here
        // instead of silently becoming "vmix-01" and fighting over the cables.
        let opts = if exact { NO_START_SERVER | USE_EXACT_NAME } else { NO_START_SERVER };
        let raw = unsafe { (lib.jack_client_open)(cname.as_ptr(), opts, &mut status) };
        if raw.is_null() && status & STATUS_NAME_NOT_UNIQUE != 0 {
            return Err(format!(
                "a JACK client named {name:?} already exists — is vmix already running?\n  \
                 To run a second mixer, give it its own config with a different client_name."
            ));
        }
        if raw.is_null() {
            return Err(format!(
                "cannot open JACK client: {}.\n  Is PipeWire (with pipewire-jack) or jackd running?",
                status_text(status)
            ));
        }
        Ok(Self { lib, raw })
    }

    pub fn name(&self) -> String {
        // SAFETY: valid client; returned string is owned by JACK.
        let p = unsafe { (self.lib.jack_get_client_name)(self.raw) };
        if p.is_null() { String::new() } else { unsafe { CStr::from_ptr(p) }.to_string_lossy().into_owned() }
    }

    pub fn sample_rate(&self) -> u32 {
        unsafe { (self.lib.jack_get_sample_rate)(self.raw) }
    }

    pub fn buffer_size(&self) -> u32 {
        unsafe { (self.lib.jack_get_buffer_size)(self.raw) }
    }

    pub fn set_buffer_size(&self, n: u32) -> Result<(), String> {
        match unsafe { (self.lib.jack_set_buffer_size)(self.raw, n) } {
            0 => Ok(()),
            e => Err(format!("jack_set_buffer_size({n}) failed ({e})")),
        }
    }

    pub fn cpu_load(&self) -> f32 {
        unsafe { (self.lib.jack_cpu_load)(self.raw) }
    }

    pub fn register_audio_port(&self, short: &str, input: bool) -> Result<Port, String> {
        let n = CString::new(short).map_err(|_| "port name contains NUL".to_string())?;
        let flags = if input { PORT_IS_INPUT } else { PORT_IS_OUTPUT };
        // SAFETY: valid client and C strings.
        let p = unsafe { (self.lib.jack_port_register)(self.raw, n.as_ptr(), AUDIO_TYPE.as_ptr(), flags, 0) };
        if p.is_null() { Err(format!("cannot register JACK port {short:?}")) } else { Ok(p) }
    }

    pub fn port_name(&self, p: Port) -> String {
        let s = unsafe { (self.lib.jack_port_name)(p) };
        if s.is_null() { String::new() } else { unsafe { CStr::from_ptr(s) }.to_string_lossy().into_owned() }
    }

    pub fn latency(&self, p: Port, mode: c_int) -> LatencyRange {
        let mut r = LatencyRange::default();
        unsafe { (self.lib.jack_port_get_latency_range)(p, mode, &mut r) };
        r
    }

    /// Port names matching an (extended POSIX) regex, audio only, with flags.
    pub fn ports(&self, pattern: Option<&str>, flags: c_ulong) -> Vec<String> {
        let pat = pattern.and_then(|p| CString::new(p).ok());
        let pat_ptr = pat.as_ref().map_or(std::ptr::null(), |c| c.as_ptr());
        // SAFETY: valid client; NULL or valid C strings.
        let arr = unsafe { (self.lib.jack_get_ports)(self.raw, pat_ptr, AUDIO_TYPE.as_ptr(), flags) };
        let mut out = Vec::new();
        if arr.is_null() {
            return out;
        }
        let mut i = 0;
        loop {
            // SAFETY: NULL-terminated array returned by jack_get_ports.
            let s = unsafe { *arr.add(i) };
            if s.is_null() {
                break;
            }
            out.push(unsafe { CStr::from_ptr(s) }.to_string_lossy().into_owned());
            i += 1;
        }
        unsafe { (self.lib.jack_free)(arr.cast()) };
        out
    }

    /// Connect two ports by full name. Already-connected counts as success.
    pub fn connect(&self, src: &str, dst: &str) -> Result<(), String> {
        let (a, b) = match (CString::new(src), CString::new(dst)) {
            (Ok(a), Ok(b)) => (a, b),
            _ => return Err("port name contains NUL".into()),
        };
        match unsafe { (self.lib.jack_connect)(self.raw, a.as_ptr(), b.as_ptr()) } {
            0 => Ok(()),
            e if e == EEXIST || e == -EEXIST => Ok(()),
            e => Err(format!("connect {src} -> {dst} failed ({e})")),
        }
    }

    pub fn activate(&self) -> Result<(), String> {
        match unsafe { (self.lib.jack_activate)(self.raw) } {
            0 => Ok(()),
            e => Err(format!("jack_activate failed ({e})")),
        }
    }
}

impl Drop for JackClient {
    fn drop(&mut self) {
        // SAFETY: valid client; after close returns no callback runs again.
        unsafe {
            (self.lib.jack_deactivate)(self.raw);
            (self.lib.jack_client_close)(self.raw);
        }
    }
}

/// Escape a literal for use inside a POSIX extended regex.
pub fn regex_escape(s: &str) -> String {
    let mut o = String::with_capacity(s.len());
    for c in s.chars() {
        if "\\.^$|?*+()[]{}".contains(c) {
            o.push('\\');
        }
        o.push(c);
    }
    o
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn escape() {
        assert_eq!(regex_escape("a.b(c)"), r"a\.b\(c\)");
        assert_eq!(regex_escape("VMix-In1"), "VMix-In1");
    }

    #[test]
    fn status_bits() {
        assert!(status_text(0x11).contains("unable to connect"));
        assert_eq!(status_text(0), "status 0x0");
    }
}
