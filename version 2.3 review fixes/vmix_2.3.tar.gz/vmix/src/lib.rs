//! vmix — a 6-strip / 5-bus virtual audio mixer for Linux.
//!
//! The crate is split so that everything that touches audio samples
//! (`engine`, and the `recorder` that captures them to WAV) and everything
//! that touches persistent state (`config`) is plain, dependency-free Rust
//! that can be unit-tested without an audio server. The binary (`main.rs`)
//! adds the JACK backend, PipeWire virtual cables, the terminal UI and the
//! GUI (`--gui`).

pub mod config;
pub mod engine;
pub mod recorder;
