//! Real-time mixing engine.
//!
//! Signal flow (identical topology to Voicemeeter Banana, but 6 input strips):
//!
//! ```text
//!  strip input (L,R) + VBAN in ─► sanitize ─► [mono] ─► EQ ─► gain × fader × pan, mute/solo ─► meter ─┬─► route A1 ─┐
//!                                                                                                    ├─► route A2  │
//!                                                                                                    ├─► ...       ├─► bus sum ─►
//!                                                                                                    └─► route B2 ─┘
//!  (+ player, on the buses it is routed to) ─► [mono] ─► EQ ─► gain × fader × balance, mute ─► meter ─► out
//! ```
//!
//! The input gain ("trim", the GAIN knob) and the pan / balance are applied
//! together with the fader as one ramped gain per side. The EQ is linear,
//! so this is the same as applying the input gain before it. At 0 dB and
//! centre they are exactly 1.0, so the signal is unchanged bit for bit.
//!
//! Recorder and VBAN out take strips after their fader and buses as they
//! leave the mixer (see [`crate::recorder`], [`crate::vban`]).
//!
//! Guarantees of [`Engine::process`]:
//! * **Sample-synchronous.** Every strip and every bus is computed in the same
//!   call for the same frame range, so a sample entering any strip at frame
//!   `k` leaves every bus at frame `k` of the same cycle. The engine adds
//!   **zero** samples of latency; total latency is only the audio server's
//!   period(s).
//! * **Real-time safe.** No allocation, no locks, no syscalls, no panics for
//!   any input. Parameters are read from atomics once per cycle.
//! * **Click-free.** Every gain change (fader, mute, solo, routing toggle) is
//!   ramped linearly across one cycle and lands exactly on its target on the
//!   last sample of that cycle.
//! * **Recorder tap.** With a recorder attached ([`Engine::attach_recorder`]),
//!   the post-fader strips and the finished buses of the same cycle are
//!   handed to it at the end of `process`, still with no allocation, locks
//!   or syscalls (see [`crate::recorder`]).
//! * **EQ.** Every strip and bus has a 6-band parametric EQ ([`crate::eq`]);
//!   off (the default) or flat, it leaves the signal bit for bit unchanged.
//! * **VBAN.** With VBAN attached ([`Engine::attach_vban`]), incoming network
//!   streams are added to their strips' inputs at the start of `process`
//!   and outgoing streams are fed at the end, through preallocated
//!   lock-free rings (see [`crate::vban`]).
//! * **Player.** With a player attached ([`Engine::attach_player`]), a
//!   recording being played back is added to the buses it is routed to,
//!   before their EQ and fader (see [`crate::player`]).

use crate::eq::{EqParams, EqRt};
use crate::player::{PlayRt, PlayTap};
use crate::recorder::{RecRt, RecTap};
use crate::vban::{VbanRt, VbanTap};
use std::array;
use std::sync::Arc;
use std::sync::atomic::{AtomicBool, AtomicU8, AtomicU16, AtomicU32, Ordering::Relaxed};

pub const NUM_STRIPS: usize = 6;
pub const NUM_BUSES: usize = 5;
/// A1..A3 are "physical" buses (go to hardware), B1..B2 are "virtual"
/// buses (exposed as virtual microphones to other applications).
pub const BUS_IDS: [&str; NUM_BUSES] = ["A1", "A2", "A3", "B1", "B2"];
pub const NUM_PHYSICAL_BUSES: usize = 3;
/// Largest period the engine will process. JACK2 and PipeWire both cap at
/// 8192 by default; we allow twice that. Larger periods produce silence and
/// increment [`Shared::oversize_cycles`] instead of allocating.
pub const MAX_FRAMES: usize = 16384;
pub const MIN_GAIN_DB: f32 = -60.0;
pub const MAX_GAIN_DB: f32 = 12.0;
/// Range of the input gain (the GAIN knob), applied with the fader.
pub const MIN_TRIM_DB: f32 = -24.0;
pub const MAX_TRIM_DB: f32 = 24.0;

/// f32 stored in an `AtomicU32`.
#[derive(Debug, Default)]
pub struct AtomicF32(AtomicU32);

impl AtomicF32 {
    pub fn new(v: f32) -> Self {
        Self(AtomicU32::new(v.to_bits()))
    }
    #[inline]
    pub fn load(&self) -> f32 {
        f32::from_bits(self.0.load(Relaxed))
    }
    #[inline]
    pub fn store(&self, v: f32) {
        self.0.store(v.to_bits(), Relaxed)
    }
}

/// Peak meter written by the audio thread, read-and-reset by the UI.
///
/// For non-negative finite f32 values the IEEE-754 bit pattern is monotonic
/// when read as u32, so `fetch_max` on the bits is a lock-free float max.
#[derive(Debug, Default)]
pub struct PeakMeter(AtomicU32);

impl PeakMeter {
    #[inline]
    fn push(&self, v: f32) {
        debug_assert!(v >= 0.0 && v.is_finite());
        self.0.fetch_max(v.to_bits(), Relaxed);
    }
    /// Returns the peak (linear) since the last call and resets it.
    pub fn take(&self) -> f32 {
        f32::from_bits(self.0.swap(0, Relaxed))
    }
}

#[derive(Debug, Default)]
pub struct StripParams {
    /// Fader, dB.
    pub gain_db: AtomicF32,
    /// Input gain (GAIN knob), dB.
    pub trim_db: AtomicF32,
    /// Pan / balance, -1 (left) .. 0 (centre) .. +1 (right).
    pub pan: AtomicF32,
    pub mute: AtomicBool,
    pub solo: AtomicBool,
    pub mono: AtomicBool,
    /// Bit `b` set => strip feeds bus `b` (A1 = bit 0 ... B2 = bit 4).
    pub routes: AtomicU8,
    pub peak: [PeakMeter; 2],
    pub eq: EqParams,
}

#[derive(Debug, Default)]
pub struct BusParams {
    /// Fader, dB.
    pub gain_db: AtomicF32,
    /// Gain before the fader (GAIN knob), dB.
    pub trim_db: AtomicF32,
    /// Balance, -1 (left) .. 0 (centre) .. +1 (right).
    pub pan: AtomicF32,
    pub mute: AtomicBool,
    pub mono: AtomicBool,
    pub peak: [PeakMeter; 2],
    pub eq: EqParams,
}

/// State shared between the audio thread and the control/UI thread.
#[derive(Debug, Default)]
pub struct Shared {
    pub strips: [StripParams; NUM_STRIPS],
    pub buses: [BusParams; NUM_BUSES],
    /// Incremented by the backend's xrun callback.
    pub xruns: AtomicU32,
    /// Cycles larger than MAX_FRAMES (output was silenced).
    pub oversize_cycles: AtomicU32,
    /// Channels linked to the recorder: bit 0..5 = strips 1..6,
    /// bit 6..10 = buses A1..B2 (see [`crate::recorder::source_id`]).
    pub rec_links: AtomicU16,
}

impl Shared {
    pub fn new() -> Arc<Self> {
        Arc::new(Self::default())
    }

    /// EQ of channel `ch` (0..5 strips, 6..10 buses).
    pub fn eq(&self, ch: usize) -> &EqParams {
        if ch < NUM_STRIPS { &self.strips[ch].eq } else { &self.buses[ch - NUM_STRIPS].eq }
    }

    pub fn toggle_route(&self, strip: usize, bus: usize) {
        self.strips[strip].routes.fetch_xor(1 << bus, Relaxed);
    }

    /// Link/unlink recorder source `src` (0..5 strips, 6..10 buses).
    pub fn toggle_rec_link(&self, src: usize) {
        if src < NUM_STRIPS + NUM_BUSES {
            self.rec_links.fetch_xor(1 << src, Relaxed);
        }
    }
}

#[inline]
pub fn db_to_gain(db: f32) -> f32 {
    10f32.powf(db / 20.0)
}

#[inline]
pub fn gain_to_db(g: f32) -> f32 {
    if g <= 1e-6 { -120.0 } else { 20.0 * g.log10() }
}

#[inline]
pub fn clamp_db(db: f32) -> f32 {
    if db.is_nan() { 0.0 } else { db.clamp(MIN_GAIN_DB, MAX_GAIN_DB) }
}

#[inline]
pub fn clamp_trim(db: f32) -> f32 {
    if db.is_nan() { 0.0 } else { db.clamp(MIN_TRIM_DB, MAX_TRIM_DB) }
}

#[inline]
pub fn clamp_pan(p: f32) -> f32 {
    if p.is_nan() { 0.0 } else { p.clamp(-1.0, 1.0) }
}

/// (left, right) gain of the pan / balance control: the side it moves away
/// from follows a cosine (-3 dB half way, silent at the end), the other side
/// stays at unity. Centre is exactly (1, 1).
#[inline]
pub fn pan_gains(p: f32) -> (f32, f32) {
    let p = clamp_pan(p);
    let fade = |x: f32| if x >= 1.0 { 0.0 } else { (x * std::f32::consts::FRAC_PI_2).cos().clamp(0.0, 1.0) };
    if p > 0.0 {
        (fade(p), 1.0)
    } else if p < 0.0 {
        (1.0, fade(-p))
    } else {
        (1.0, 1.0)
    }
}

/// Target gain of one side: fader × input gain × pan, or 0 when silenced.
#[inline]
fn side_gains(silenced: bool, fader_db: f32, trim_db: f32, pan: f32) -> [f32; 2] {
    if silenced {
        return [0.0, 0.0];
    }
    let g = db_to_gain(clamp_db(fader_db)) * db_to_gain(clamp_trim(trim_db));
    let (l, r) = pan_gains(pan);
    [g * l, g * r]
}

/// Replace NaN/inf (from a misbehaving client) with silence so that one bad
/// application can never poison every bus.
#[inline(always)]
fn sanitize(x: f32) -> f32 {
    if x.is_finite() { x } else { 0.0 }
}

/// Linear ramp from `v0` to `v1` across `n` samples; sample `n-1` is exactly `v1`.
#[inline(always)]
fn ramp(v0: f32, v1: f32, i: usize, n: usize) -> f32 {
    if i + 1 >= n { v1 } else { v0 + (v1 - v0) * ((i + 1) as f32 / n as f32) }
}

pub struct Engine {
    shared: Arc<Shared>,
    /// Private copy of every input channel: `[strip][L/R][MAX_FRAMES]`.
    /// Copying first means input buffers can never alias output buffers
    /// (JACK may hand an input port the very buffer of the output it is
    /// connected to, e.g. if a user patches a bus back into a strip).
    scratch: Box<[f32]>,
    /// Per strip / bus: [left, right] gain of the last cycle.
    strip_gain: [[f32; 2]; NUM_STRIPS],
    route_gain: [[f32; NUM_BUSES]; NUM_STRIPS],
    bus_gain: [[f32; 2]; NUM_BUSES],
    /// Strips 0..5, then buses.
    eq: [EqRt; NUM_STRIPS + NUM_BUSES],
    rec: Option<Arc<RecTap>>,
    rec_rt: RecRt,
    vban: Option<Arc<VbanTap>>,
    vban_rt: VbanRt,
    play: Option<Arc<PlayTap>>,
    play_rt: PlayRt,
}

impl Engine {
    /// All gains start at 0 so the first cycle fades in instead of popping.
    pub fn new(shared: Arc<Shared>) -> Self {
        Self {
            shared,
            scratch: vec![0.0; NUM_STRIPS * 2 * MAX_FRAMES].into_boxed_slice(),
            strip_gain: [[0.0; 2]; NUM_STRIPS],
            route_gain: [[0.0; NUM_BUSES]; NUM_STRIPS],
            bus_gain: [[0.0; 2]; NUM_BUSES],
            eq: array::from_fn(|_| EqRt::new(48_000)),
            rec: None,
            rec_rt: RecRt::default(),
            vban: None,
            vban_rt: VbanRt::default(),
            play: None,
            play_rt: PlayRt::default(),
        }
    }

    /// The server's sample rate (for the EQ; call before the engine goes live).
    pub fn set_sample_rate(&mut self, sample_rate: u32) {
        for eq in &mut self.eq {
            eq.set_sample_rate(sample_rate);
        }
    }

    /// Feed every cycle to a recorder (call before the engine goes live).
    pub fn attach_recorder(&mut self, tap: Arc<RecTap>) {
        self.rec = Some(tap);
    }

    /// Exchange audio with the VBAN threads (call before the engine goes live).
    pub fn attach_vban(&mut self, tap: Arc<VbanTap>) {
        self.vban = Some(tap);
    }

    /// Play recordings into the buses (call before the engine goes live).
    pub fn attach_player(&mut self, tap: Arc<PlayTap>) {
        self.play = Some(tap);
    }

    pub fn shared(&self) -> &Arc<Shared> {
        &self.shared
    }

    /// A cycle that produced silence without mixing: the recorder (if any)
    /// records `n` frames of silence for it; VBAN streams wait.
    #[inline]
    fn rec_skip(&mut self, n: usize) {
        if let Some(tap) = self.rec.as_deref() {
            self.rec_rt.skip(tap, self.shared.rec_links.load(Relaxed), n);
        }
        if let Some(tap) = self.vban.as_deref() {
            self.vban_rt.idle(tap);
        }
        if let Some(tap) = self.play.as_deref() {
            self.play_rt.idle(tap);
        }
    }

    #[inline]
    fn chan_mut(&mut self, strip: usize, ch: usize) -> &mut [f32] {
        let off = (strip * 2 + ch) * MAX_FRAMES;
        &mut self.scratch[off..off + MAX_FRAMES]
    }

    /// Copy one input channel for this cycle. Extra frames beyond
    /// MAX_FRAMES are ignored (that cycle will be silenced by `process`).
    #[inline]
    pub fn load_input(&mut self, strip: usize, ch: usize, src: &[f32]) {
        let n = src.len().min(MAX_FRAMES);
        self.chan_mut(strip, ch)[..n].copy_from_slice(&src[..n]);
    }

    #[inline]
    pub fn clear_input(&mut self, strip: usize, ch: usize, n: usize) {
        let n = n.min(MAX_FRAMES);
        self.chan_mut(strip, ch)[..n].fill(0.0);
    }

    /// Mix one cycle. Call `load_input`/`clear_input` for all 12 input
    /// channels first. All 10 output slices must have the same length `n`,
    /// which must equal the length passed to the loaders.
    pub fn process(&mut self, out: &mut [[&mut [f32]; 2]; NUM_BUSES]) {
        for bus in out.iter_mut() {
            for ch in bus.iter_mut() {
                ch.fill(0.0);
            }
        }
        let n = out[0][0].len();
        if n == 0 {
            self.rec_skip(0);
            return;
        }
        if n > MAX_FRAMES || out.iter().any(|b| b[0].len() != n || b[1].len() != n) {
            self.shared.oversize_cycles.fetch_add(1, Relaxed);
            self.rec_skip(n);
            return;
        }

        // ---- VBAN in: network streams join their strips' inputs ------------
        if let Some(tap) = self.vban.as_deref() {
            self.vban_rt.pull(tap, n, &mut self.scratch, std::time::Instant::now());
        }

        let shared = &*self.shared;
        let any_solo = shared.strips.iter().any(|s| s.solo.load(Relaxed));
        // Bit s set = strip s's scratch holds this cycle's post-fader signal
        // (a fully silent strip is skipped and its scratch still holds raw input).
        let mut live: u8 = 0;

        // ---- strips -> buses ---------------------------------------------
        for s in 0..NUM_STRIPS {
            let p = &shared.strips[s];
            let silenced = p.mute.load(Relaxed) || (any_solo && !p.solo.load(Relaxed));
            let target = side_gains(silenced, p.gain_db.load(), p.trim_db.load(), p.pan.load());
            let routes = p.routes.load(Relaxed);
            let route_target: [f32; NUM_BUSES] =
                array::from_fn(|b| if routes & (1 << b) != 0 { 1.0 } else { 0.0 });
            let g0 = self.strip_gain[s];
            self.strip_gain[s] = target;

            if g0 == [0.0; 2] && target == [0.0; 2] {
                // Fully silent for the whole cycle: routing and EQ changes
                // are inaudible, so take them at once.
                self.route_gain[s] = route_target;
                self.eq[s].reset(&p.eq);
                continue;
            }
            live |= 1 << s;

            let mono = p.mono.load(Relaxed);
            let base = s * 2 * MAX_FRAMES;
            let (l, r) = self.scratch[base..base + 2 * MAX_FRAMES].split_at_mut(MAX_FRAMES);
            let (l, r) = (&mut l[..n], &mut r[..n]);

            for i in 0..n {
                let mut a = sanitize(l[i]);
                let mut b = sanitize(r[i]);
                if mono {
                    let m = 0.5 * (a + b);
                    a = m;
                    b = m;
                }
                l[i] = a;
                r[i] = b;
            }
            self.eq[s].process(&p.eq, l, r);
            let mut pk_l = 0.0f32;
            let mut pk_r = 0.0f32;
            for i in 0..n {
                let (a, b) = (l[i] * ramp(g0[0], target[0], i, n), r[i] * ramp(g0[1], target[1], i, n));
                l[i] = a;
                r[i] = b;
                pk_l = pk_l.max(a.abs());
                pk_r = pk_r.max(b.abs());
            }
            p.peak[0].push(pk_l);
            p.peak[1].push(pk_r);

            for (b, bus) in out.iter_mut().enumerate() {
                let r0 = self.route_gain[s][b];
                let r1 = route_target[b];
                self.route_gain[s][b] = r1;
                if r0 == 0.0 && r1 == 0.0 {
                    continue;
                }
                let [bl, br] = bus;
                if r0 == 1.0 && r1 == 1.0 {
                    for i in 0..n {
                        bl[i] += l[i];
                        br[i] += r[i];
                    }
                } else {
                    for i in 0..n {
                        let w = ramp(r0, r1, i, n);
                        bl[i] += l[i] * w;
                        br[i] += r[i] * w;
                    }
                }
            }
        }

        // ---- player: a recording played back joins the buses ---------------
        if let Some(tap) = self.play.as_deref() {
            self.play_rt.mix(tap, n, out);
        }

        // ---- bus masters --------------------------------------------------
        for (b, bus) in out.iter_mut().enumerate() {
            let p = &shared.buses[b];
            let target = side_gains(p.mute.load(Relaxed), p.gain_db.load(), p.trim_db.load(), p.pan.load());
            let g0 = self.bus_gain[b];
            self.bus_gain[b] = target;
            let mono = p.mono.load(Relaxed);
            let [bl, br] = bus;
            if mono {
                for i in 0..n {
                    let m = 0.5 * (bl[i] + br[i]);
                    bl[i] = m;
                    br[i] = m;
                }
            }
            self.eq[NUM_STRIPS + b].process(&p.eq, bl, br);
            let mut pk_l = 0.0f32;
            let mut pk_r = 0.0f32;
            for i in 0..n {
                let (a, c) = (bl[i] * ramp(g0[0], target[0], i, n), br[i] * ramp(g0[1], target[1], i, n));
                bl[i] = a;
                br[i] = c;
                pk_l = pk_l.max(a.abs());
                pk_r = pk_r.max(c.abs());
            }
            p.peak[0].push(pk_l);
            p.peak[1].push(pk_r);
        }

        // ---- recorder tap and VBAN out (same cycle, same frames) ----------
        let live: [bool; NUM_STRIPS] = array::from_fn(|s| live & (1 << s) != 0);
        if let Some(tap) = self.rec.as_deref() {
            let links = shared.rec_links.load(Relaxed);
            self.rec_rt.push(tap, links, n, &self.scratch, &live, out);
        }
        if let Some(tap) = self.vban.as_deref() {
            self.vban_rt.push(tap, n, &self.scratch, &live, out);
        }
    }
}

// =========================================================================
#[cfg(test)]
mod tests {
    use super::*;

    const N: usize = 128;

    struct Rig {
        eng: Engine,
        out: Vec<Vec<f32>>, // 10 channels
    }

    impl Rig {
        fn new() -> (Rig, Arc<Shared>) {
            let sh = Shared::new();
            (Rig { eng: Engine::new(sh.clone()), out: vec![vec![0.0; N]; NUM_BUSES * 2] }, sh)
        }

        /// inputs: closure (strip, ch, frame) -> sample
        fn run(&mut self, n: usize, f: impl Fn(usize, usize, usize) -> f32) {
            for s in 0..NUM_STRIPS {
                for c in 0..2 {
                    let v: Vec<f32> = (0..n).map(|i| f(s, c, i)).collect();
                    self.eng.load_input(s, c, &v);
                }
            }
            for o in &mut self.out {
                o.clear();
                o.resize(n, 7.0); // garbage: engine must overwrite
            }
            let mut it = self.out.iter_mut();
            let mut outs: [[&mut [f32]; 2]; NUM_BUSES] = array::from_fn(|_| {
                let l = it.next().unwrap().as_mut_slice();
                let r = it.next().unwrap().as_mut_slice();
                [l, r]
            });
            self.eng.process(&mut outs);
        }

        fn bus(&self, b: usize, ch: usize) -> &[f32] {
            &self.out[b * 2 + ch]
        }
    }

    fn approx(a: f32, b: f32) -> bool {
        (a - b).abs() < 1e-5
    }

    #[test]
    fn silent_with_no_routes() {
        let (mut rig, _sh) = Rig::new();
        rig.run(N, |_, _, _| 1.0);
        rig.run(N, |_, _, _| 1.0);
        for b in 0..NUM_BUSES {
            assert!(rig.bus(b, 0).iter().all(|&x| x == 0.0));
            assert!(rig.bus(b, 1).iter().all(|&x| x == 0.0));
        }
    }

    #[test]
    fn all_six_strips_are_sample_synchronous_on_every_bus() {
        let (mut rig, sh) = Rig::new();
        for s in 0..NUM_STRIPS {
            sh.strips[s].routes.store(0b11111, Relaxed);
        }
        rig.run(N, |_, _, _| 0.0); // settle ramps
        // Each strip gets a distinct-amplitude impulse at the SAME frame 37.
        // Amplitudes are powers of two so the sum identifies every strip.
        rig.run(N, |s, _, i| if i == 37 { (1u32 << s) as f32 / 64.0 } else { 0.0 });
        let expected: f32 = (0..NUM_STRIPS).map(|s| (1u32 << s) as f32 / 64.0).sum();
        for b in 0..NUM_BUSES {
            for ch in 0..2 {
                let o = rig.bus(b, ch);
                for (i, &x) in o.iter().enumerate() {
                    if i == 37 {
                        assert!(approx(x, expected), "bus {b} ch {ch}: {x}");
                    } else {
                        assert_eq!(x, 0.0, "bus {b} ch {ch} frame {i} leaked");
                    }
                }
            }
        }
    }

    #[test]
    fn zero_added_latency_impulse_at_frame_0_and_last() {
        let (mut rig, sh) = Rig::new();
        sh.strips[2].routes.store(1, Relaxed);
        rig.run(N, |_, _, _| 0.0);
        rig.run(N, |s, _, i| if s == 2 && (i == 0 || i == N - 1) { 0.5 } else { 0.0 });
        assert!(approx(rig.bus(0, 0)[0], 0.5));
        assert!(approx(rig.bus(0, 0)[N - 1], 0.5));
    }

    #[test]
    fn gain_ramps_then_settles_exactly() {
        let (mut rig, sh) = Rig::new();
        sh.strips[0].routes.store(1, Relaxed);
        sh.strips[0].gain_db.store(-6.0);
        rig.run(N, |_, _, _| 1.0); // ramp from 0
        let first = rig.bus(0, 0).to_vec();
        // monotonic ramp, no step bigger than one ramp increment
        for w in first.windows(2) {
            assert!(w[1] >= w[0]);
            assert!(w[1] - w[0] < 0.02);
        }
        let g = db_to_gain(-6.0);
        assert!(approx(*first.last().unwrap(), g));
        rig.run(N, |_, _, _| 1.0);
        assert!(rig.bus(0, 0).iter().all(|&x| approx(x, g)));
    }

    #[test]
    fn mute_and_solo() {
        let (mut rig, sh) = Rig::new();
        for s in 0..NUM_STRIPS {
            sh.strips[s].routes.store(1, Relaxed);
        }
        rig.run(N, |_, _, _| 0.0);
        // only strip 3 soloed -> bus = strip 3's signal
        sh.strips[3].solo.store(true, Relaxed);
        rig.run(N, |s, _, _| (s + 1) as f32 * 0.01);
        rig.run(N, |s, _, _| (s + 1) as f32 * 0.01);
        assert!(rig.bus(0, 0).iter().all(|&x| approx(x, 0.04)));
        // mute the soloed strip -> silence
        sh.strips[3].mute.store(true, Relaxed);
        rig.run(N, |s, _, _| (s + 1) as f32 * 0.01);
        rig.run(N, |s, _, _| (s + 1) as f32 * 0.01);
        assert!(rig.bus(0, 0).iter().all(|&x| x == 0.0));
        // unsolo -> everyone except muted strip 3
        sh.strips[3].solo.store(false, Relaxed);
        rig.run(N, |s, _, _| (s + 1) as f32 * 0.01);
        rig.run(N, |s, _, _| (s + 1) as f32 * 0.01);
        assert!(rig.bus(0, 0).iter().all(|&x| approx(x, 0.21 - 0.04)));
    }

    #[test]
    fn routing_is_per_bus() {
        let (mut rig, sh) = Rig::new();
        sh.strips[0].routes.store(0b01000, Relaxed); // B1 only
        sh.strips[1].routes.store(0b00001, Relaxed); // A1 only
        rig.run(N, |_, _, _| 0.0);
        rig.run(N, |s, _, _| if s == 0 { 0.25 } else if s == 1 { 0.5 } else { 0.0 });
        assert!(rig.bus(0, 0).iter().all(|&x| approx(x, 0.5)));
        assert!(rig.bus(3, 1).iter().all(|&x| approx(x, 0.25)));
        for b in [1, 2, 4] {
            assert!(rig.bus(b, 0).iter().all(|&x| x == 0.0));
        }
        // toggling a route ramps rather than stepping
        sh.toggle_route(0, 0);
        rig.run(N, |s, _, _| if s == 0 { 0.25 } else if s == 1 { 0.5 } else { 0.0 });
        let a1 = rig.bus(0, 0);
        assert!(a1[0] > 0.5 && a1[0] < 0.51);
        assert!(approx(a1[N - 1], 0.75));
    }

    #[test]
    fn strip_and_bus_mono() {
        let (mut rig, sh) = Rig::new();
        sh.strips[0].routes.store(0b00011, Relaxed);
        sh.strips[0].mono.store(true, Relaxed);
        rig.run(N, |_, _, _| 0.0);
        rig.run(N, |s, c, _| if s == 0 { if c == 0 { 1.0 } else { 0.0 } } else { 0.0 });
        assert!(rig.bus(0, 0).iter().all(|&x| approx(x, 0.5)));
        assert!(rig.bus(0, 1).iter().all(|&x| approx(x, 0.5)));

        sh.strips[0].mono.store(false, Relaxed);
        sh.buses[1].mono.store(true, Relaxed);
        rig.run(N, |s, c, _| if s == 0 && c == 1 { 0.8 } else { 0.0 });
        assert!(rig.bus(1, 0).iter().all(|&x| approx(x, 0.4)));
        assert!(rig.bus(1, 1).iter().all(|&x| approx(x, 0.4)));
    }

    #[test]
    fn bus_gain_and_mute() {
        let (mut rig, sh) = Rig::new();
        sh.strips[0].routes.store(0b10000, Relaxed);
        sh.buses[4].gain_db.store(6.0);
        rig.run(N, |_, _, _| 0.0);
        rig.run(N, |_, _, _| 0.1);
        rig.run(N, |_, _, _| 0.1);
        assert!(rig.bus(4, 0).iter().all(|&x| approx(x, 0.1 * db_to_gain(6.0))));
        sh.buses[4].mute.store(true, Relaxed);
        rig.run(N, |_, _, _| 0.1);
        rig.run(N, |_, _, _| 0.1);
        assert!(rig.bus(4, 0).iter().all(|&x| x == 0.0));
    }

    #[test]
    fn nan_and_inf_are_silenced() {
        let (mut rig, sh) = Rig::new();
        sh.strips[0].routes.store(1, Relaxed);
        sh.strips[1].routes.store(1, Relaxed);
        rig.run(N, |_, _, _| 0.0);
        rig.run(N, |s, _, i| match (s, i % 3) {
            (0, 0) => f32::NAN,
            (0, 1) => f32::INFINITY,
            (0, _) => f32::NEG_INFINITY,
            (1, _) => 0.3,
            _ => 0.0,
        });
        assert!(rig.bus(0, 0).iter().all(|&x| approx(x, 0.3)));
    }

    #[test]
    fn gain_param_out_of_range_or_nan_is_clamped() {
        let (mut rig, sh) = Rig::new();
        sh.strips[0].routes.store(1, Relaxed);
        sh.strips[0].gain_db.store(f32::NAN);
        rig.run(N, |_, _, _| 0.0);
        rig.run(N, |_, _, _| 0.5);
        assert!(rig.bus(0, 0).iter().all(|&x| approx(x, 0.5)));
        sh.strips[0].gain_db.store(1000.0);
        rig.run(N, |_, _, _| 0.0);
        rig.run(N, |_, _, _| 0.01);
        assert!(rig.bus(0, 0).iter().all(|&x| approx(x, 0.01 * db_to_gain(MAX_GAIN_DB))));
    }

    #[test]
    fn oversize_and_empty_cycles_do_not_panic() {
        let (mut rig, sh) = Rig::new();
        sh.strips[0].routes.store(1, Relaxed);
        rig.run(0, |_, _, _| 1.0);
        rig.run(MAX_FRAMES + 1, |_, _, _| 1.0);
        assert!(rig.bus(0, 0).iter().all(|&x| x == 0.0));
        assert_eq!(sh.oversize_cycles.load(Relaxed), 1);
        rig.run(MAX_FRAMES, |_, _, _| 1.0);
        rig.run(1, |_, _, _| 1.0);
        assert!(approx(rig.bus(0, 0)[0], 1.0));
    }

    #[test]
    fn varying_period_sizes() {
        let (mut rig, sh) = Rig::new();
        sh.strips[5].routes.store(0b00100, Relaxed);
        for &n in &[64usize, 128, 256, 32, 1024, 17] {
            rig.run(n, |_, _, _| 0.2);
        }
        assert!(rig.bus(2, 0).iter().all(|&x| approx(x, 0.2)));
        assert_eq!(rig.bus(2, 0).len(), 17);
    }

    #[test]
    fn meters_report_post_fader_peak() {
        let (mut rig, sh) = Rig::new();
        sh.strips[0].routes.store(1, Relaxed);
        sh.strips[0].gain_db.store(-20.0);
        rig.run(N, |_, _, _| 0.0);
        let _ = sh.strips[0].peak[0].take();
        rig.run(N, |_, c, i| if c == 0 && i == 5 { -1.0 } else { 0.0 });
        assert!(approx(sh.strips[0].peak[0].take(), 0.1));
        assert_eq!(sh.strips[0].peak[1].take(), 0.0);
        assert!(approx(sh.buses[0].peak[0].take(), 0.1));
        assert_eq!(sh.strips[0].peak[0].take(), 0.0, "take() resets");
    }

    #[test]
    fn input_gain_and_pan() {
        let (mut rig, sh) = Rig::new();
        sh.strips[0].routes.store(1, Relaxed);
        sh.strips[0].trim_db.store(6.0);
        sh.strips[0].gain_db.store(-6.0);
        rig.run(N, |_, _, _| 0.0);
        rig.run(N, |s, _, _| if s == 0 { 0.25 } else { 0.0 });
        let g = db_to_gain(6.0) * db_to_gain(-6.0);
        assert!(rig.bus(0, 0).iter().all(|&x| approx(x, 0.25 * g)));
        // half right: left at -3 dB, right untouched; ramped, not stepped
        sh.strips[0].pan.store(0.5);
        rig.run(N, |s, _, _| if s == 0 { 0.25 } else { 0.0 });
        let a = rig.bus(0, 0);
        assert!(a[0] > 0.25 * g * 0.99 && approx(a[N - 1], 0.25 * g * std::f32::consts::FRAC_1_SQRT_2));
        assert!(rig.bus(0, 1).iter().all(|&x| approx(x, 0.25 * g)));
        // hard left: right exactly silent
        sh.strips[0].pan.store(-1.0);
        rig.run(N, |s, _, _| if s == 0 { 0.25 } else { 0.0 });
        rig.run(N, |s, _, _| if s == 0 { 0.25 } else { 0.0 });
        assert!(rig.bus(0, 1).iter().all(|&x| x == 0.0));
        assert!(rig.bus(0, 0).iter().all(|&x| approx(x, 0.25 * g)));
        // bus balance and bus input gain
        sh.strips[0].pan.store(0.0);
        sh.buses[0].pan.store(1.0);
        sh.buses[0].trim_db.store(-6.0);
        rig.run(N, |s, _, _| if s == 0 { 0.25 } else { 0.0 });
        rig.run(N, |s, _, _| if s == 0 { 0.25 } else { 0.0 });
        assert!(rig.bus(0, 0).iter().all(|&x| x == 0.0));
        assert!(rig.bus(0, 1).iter().all(|&x| approx(x, 0.25 * g * db_to_gain(-6.0))));
        // out of range and NaN are clamped / ignored
        sh.buses[0].pan.store(f32::NAN);
        sh.buses[0].trim_db.store(f32::NAN);
        sh.strips[0].trim_db.store(1000.0);
        rig.run(N, |_, _, _| 0.0);
        rig.run(N, |s, _, _| if s == 0 { 0.001 } else { 0.0 });
        let g = db_to_gain(MAX_TRIM_DB) * db_to_gain(-6.0);
        assert!(rig.bus(0, 0).iter().all(|&x| approx(x, 0.001 * g)) && rig.bus(0, 1).iter().all(|&x| approx(x, 0.001 * g)));
    }

    #[test]
    fn centre_and_zero_gain_are_bit_exact() {
        assert_eq!(pan_gains(0.0), (1.0, 1.0));
        assert_eq!(pan_gains(-0.0), (1.0, 1.0));
        assert_eq!(pan_gains(1.0), (0.0, 1.0));
        assert_eq!(pan_gains(-1.0), (1.0, 0.0));
        assert_eq!(pan_gains(f32::NAN), (1.0, 1.0));
        assert_eq!(db_to_gain(0.0), 1.0);
        for db in [-60.0f32, -12.5, -0.1, 0.0, 3.3, 12.0] {
            assert_eq!(side_gains(false, db, 0.0, 0.0), [db_to_gain(db); 2]);
        }
        assert_eq!(side_gains(true, 0.0, 12.0, 0.3), [0.0; 2]);
    }

    #[test]
    fn player_joins_the_buses_before_their_fader() {
        use crate::player::{PlayTap, START_FRAMES};
        let (mut rig, sh) = Rig::new();
        let tap = PlayTap::new();
        rig.eng.attach_player(tap.clone());
        tap.routes.store(0b01000, Relaxed); // B1
        sh.buses[3].gain_db.store(-6.0);
        tap.test_push(&vec![0.5f32; 2 * (START_FRAMES + 4 * N)]);
        tap.test_run(true, false);
        rig.run(N, |_, _, _| 0.0); // bus gains ramp in
        rig.run(N, |_, _, _| 0.0);
        assert!(rig.bus(3, 0).iter().all(|&x| approx(x, 0.5 * db_to_gain(-6.0))));
        assert!(rig.bus(0, 0).iter().all(|&x| x == 0.0));
        // a strip on the same bus adds to it
        sh.strips[1].routes.store(0b01000, Relaxed);
        rig.run(N, |s, _, _| if s == 1 { 0.25 } else { 0.0 });
        rig.run(N, |s, _, _| if s == 1 { 0.25 } else { 0.0 });
        assert!(rig.bus(3, 1).iter().all(|&x| approx(x, 0.75 * db_to_gain(-6.0))));
        // oversize cycles still honour a flush
        tap.test_flush();
        rig.run(MAX_FRAMES + 1, |_, _, _| 0.0);
        assert_eq!(tap.test_played(), 0);
    }

    #[test]
    fn db_conversions() {
        assert!(approx(db_to_gain(0.0), 1.0));
        assert!((db_to_gain(-6.0206) - 0.5).abs() < 1e-4);
        assert!((gain_to_db(0.5) + 6.0206).abs() < 1e-3);
        assert_eq!(gain_to_db(0.0), -120.0);
    }
}
