# BananaSplit: a 6-strip virtual audio mixer for Linux

A Voicemeeter Banana-style mixer written in Rust, with **6 input strips**, **3 hardware buses (A1–A3)**, **2 virtual buses (B1–B2)**, **one virtual cable per strip**, input gain, pan and a **6-band EQ** on every strip and bus, **VBAN network audio** that works with Voicemeeter, a **multitrack recorder and player**, and **scenes**. It runs as a single real-time JACK client, natively on JACK2 or on PipeWire's JACK layer. It is a desktop app: its own window, an icon in the app menu and in the system tray, and it can start with the system (`bananasplit --gui`). It also runs in a terminal or as a background service.

```
 BananaSplit  6 strips · 5 buses · JACK client "BananaSplit" · 8 cables
 48000 Hz · 128 fr · 2.67 ms/period · RTT 6.10 ms [OK <10ms] · DSP 1% · xruns 0
 VBAN UDP 6980 · in: 1 of 1 receiving · out: 1 of 1 sending
  #  NAME              GAIN  L          R          PEAK M S O E  A1 A2 A3 B1 B2
> 1  Mic               +0.0  ██████···· ██████····  -24 · · O E  A1 A2 A3 B1 B2
  2  Discord           -7.4  █████····· █████·····  -31 · · · ·  A1 A2 A3 B1 B2
  ...
 A2  Blue Headphones   +0.0  ████······ ████······  -30 ·   · E
```

## What's new in 2.6

* **A new studio interface**, built from the BananaSplit studio design: every strip has a **GAIN** knob (input gain, ±24 dB), a segmented level meter with peak hold, a long fader, a **PAN** knob (BALANCE on buses), MUTE / SOLO with their lamps, the EQ and MONO switches, and the A1–B2 routing chips; the six inputs, the three hardware buses and the two virtual buses each have their colour; a quick-mix bar shows every input's level and routing and the A1 master; a session panel shows messages, round trip, DSP load and xruns. Dark by default, with a light theme and zoom in the menu. Every control is live and is saved.
* **A real desktop app.** `bananasplit --gui` opens BananaSplit in **its own window** (GTK + WebKitGTK, no browser) and puts an **icon in the system tray**: left click shows or hides the window, its menu has Show, Start/Stop recording and Quit. **Closing the window keeps the mixer running** in the tray, like Voicemeeter (or quits it, if you switch that off). **Start with the system** starts it in the tray when you log in. Launching it again from the app menu brings the window back. If the window crashes, the mixer keeps running. Without WebKitGTK the page opens in a browser's app window and the tray icon still works.
* **Install it like an app:** a **.deb package** (Debian, Ubuntu, Mint, Pop!_OS) and a **portable package** for every other distribution (`./install.sh`, or "Add BananaSplit to the app menu" in the GUI): app-menu entry with its icon, "Quit BananaSplit" in the launcher's right-click menu, `bananasplit --install` / `--uninstall`. The binary needs glibc 2.34 or newer (Ubuntu 22.04, Debian 12, Fedora 35, RHEL 9 and later).
* **No more `pw-jack` on Debian/Ubuntu:** when the system's libjack finds no JACK server but PipeWire is running, BananaSplit uses PipeWire's own libjack from its private folder, so it starts from the app menu as it is.
* **Player:** the recorder panel plays recordings back (PLAY / PAUSE / STOP, a waveform you can click to jump, ‹ › to go through your takes) into the buses you choose (PLAY TO, A1 by default). Multitrack takes play as their mix. Any WAV file in the recordings folder plays, from 8 kHz up to four times the mixer's sample rate.
* **Scenes:** save the whole mix (faders, gains, pans, mutes, solos, routing, EQ, armed tracks) under a name and load it back with one click, from the SCENE menu.
* The recorder panel shows the disk space left, and opens the recordings folder.
* **Only your user account can reach the mixer** over its local web port; 2.5 also answered other users of the same computer.
* Upgrading from 2.5: your config loads as it is (the new settings start at 0 dB, centre, and the dark theme). Once 2.6 has saved it, 2.5 can no longer read it. Your recordings, VBAN streams and EQs are untouched. If you copied 2.5's `contrib/bananasplit.desktop` into `~/.local/share/applications/`, `./install.sh` (or `bananasplit --install`) replaces it; with the .deb, delete that copy, so the package's entry with the new icon shows. Update a copied `contrib/systemd/bananasplit.service` the same way (it no longer needs `pw-jack`).

## What's new in 2.5

* **New name.** vmix is now **BananaSplit**: the command is `bananasplit`, the JACK client and the virtual cables are called `BananaSplit` (`BananaSplit-In1-Mic`, `BananaSplit-Out-B1`, …), the config lives in `~/.config/bananasplit/bananasplit.ini`, and recordings go to `~/Music/BananaSplit/` by default.
* **Dark mode for the GUI**, redesigned: near-black panels, banana-yellow keys and faders, and a **theme switch** in the top bar (Auto follows your desktop, or pick Light or Dark; the GUI remembers it).

Upgrading from vmix 2.4:

* The first start copies `~/.config/vmix/vmix.ini` to the new place, so your strips, routing, EQ, VBAN and recorder settings come along. The old file is left alone. If your JACK name was the old default `vmix`, it becomes `BananaSplit`; that renames the virtual cables, so pick them again once in the apps that used them (sound settings, Discord, OBS). A name you chose yourself is kept, and so is your recorder folder.
* If you ran `vmix --low-latency`, BananaSplit sees those files as installed. `bananasplit --low-latency` replaces them with its own, and `bananasplit --low-latency off` removes them too.
* Copy `contrib/bananasplit.desktop` and `contrib/systemd/bananasplit.service` again if you installed the old ones (and `systemctl --user disable --now vmix`).

## What's new in 2.4

* **VBAN**, compatible with Voicemeeter (Banana, Potato and the others) and with VB-Audio's VBAN apps: up to 8 incoming streams, each added to a strip of your choice, and up to 8 outgoing streams, each sending a strip or a bus to another computer. Incoming streams can have any sample rate, format and channel count; BananaSplit resamples them and follows the sender's clock, so they play without gaps or drift. See [VBAN](#vban-network-audio-voicemeeter-compatible).
* **EQ** on all 11 channels: 6 bands, each a bell, low or high shelf, low or high cut, or notch, from 20 Hz to 20 kHz, ±24 dB, Q 0.1–30. It is off by default; off, or flat, it leaves the audio bit for bit unchanged. See [EQ](#eq).
* Both work in the terminal UI (`e`, `E`, `v`), in the GUI (an EQ editor with a draggable curve, a VBAN window) and in `--headless` mode, and both are saved in the config file.

## What's new in 2.3

Changes from a review on real hardware:

* `--no-cables` now applies to one run only. It is no longer written into the config file.
* **`connect = @default`** follows the input and output devices chosen in your desktop's sound settings, and it is the new default for strip 1 and A1. `@physical` now prefers the default device too, instead of whichever device JACK lists first (a webcam, for example).
* **`bananasplit --list-ports`** shows every JACK name a `connect` pattern can match, with a ready-made `connect =` line per device. When a pattern matches nothing, BananaSplit says why: a PipeWire node name was used instead of the JACK name, the case is wrong, or the port points the wrong way. On stderr it also lists the ports that would work.
* **`bananasplit --low-latency`** installs and applies the PipeWire low-latency settings in one step. At startup, BananaSplit warns if the round trip is 10 ms or more and says what to do about it.
* **Killed BananaSplit:** a small watchdog process removes the virtual cables if BananaSplit is killed with SIGKILL or crashes. `bananasplit --cleanup` and the systemd unit's `ExecStopPost` cover the case where the watchdog was killed too.
* **Terminal UI:** names get 15 columns at 80 columns (more on a wider terminal) and end in `…` when cut. Long status lines are cut instead of wrapping, and the PEAK column no longer shifts by one between silent and loud rows.

## ASIO / WASAPI on Linux

ASIO and WASAPI are **Windows-only** driver APIs and do not exist on Linux. What they give you on Windows (exclusive device access, no OS mixer or resampler in the path, small fixed buffers, and one callback that sees every channel at once) is what **JACK** provides on Linux. PipeWire implements the same API.

| Windows                       | BananaSplit on Linux                                                       |
|-------------------------------|---------------------------------------------------------------------|
| ASIO driver                   | JACK2 server, or PipeWire + `pipewire-jack`                         |
| WASAPI exclusive mode         | Device opened only by JACK/PipeWire at a fixed rate and quantum     |
| VB-Cable / "Voicemeeter Input"| `BananaSplit-In1…6` virtual output devices (PipeWire sinks)                |
| "Voicemeeter Output" (B1/B2)  | `BananaSplit-Out-B1`, `BananaSplit-Out-B2` virtual microphones                    |
| Voicemeeter Banana            | `bananasplit`                                                              |

## Sync and latency

* **Sample-synchronous by design.** The whole mixer (all 12 input channels and 10 output channels) is computed inside **one** JACK process callback for the same block of frames. A sample entering any strip at frame *k* leaves every bus at frame *k* of the same cycle. The mixer itself adds **0 samples** of latency.
* **Virtual cables add no buffering.** They are nodes in the same PipeWire graph, driven by the same clock, and processed in the same cycle.
* **Sub-10 ms** depends on the server's period. Use 48 kHz with 128 frames: 2.67 ms per period, which gives about 6–8 ms hardware round-trip including driver headroom. Run `bananasplit --low-latency` once to pin this (see [Latency](#latency)). The UI shows the measured round-trip from JACK's latency API and turns red if it reaches 10 ms or more.
* **Real-time safe.** The audio callback does no allocation, no locks, no syscalls, and cannot panic. Every gain, mute, solo, or routing change is ramped over one period, so changes don't click.

## Install

**Debian, Ubuntu, Mint, Pop!_OS:** install the package, which pulls in what it needs:

```sh
sudo apt install ./bananasplit_2.6.0_amd64.deb
```

**Any other distribution (Fedora, Arch, openSUSE, …):** unpack the portable package and run its installer. It copies `bananasplit` to `~/.local/bin` and adds BananaSplit with its icon to your app menu; nothing outside your home folder is touched (`./install.sh --uninstall` removes it again).

```sh
tar -xzf bananasplit-2.6.0-linux-x86_64.tar.gz
cd bananasplit-2.6.0-linux-x86_64 && ./install.sh
```

Then start **BananaSplit** from the app menu. What it needs from the system (PipeWire is the default on current Fedora, Ubuntu, Debian, Arch, and others; the .deb asks for these itself):

| Distro         | Audio (required)                                        | App window and tray (recommended)  |
|----------------|---------------------------------------------------------|------------------------------------|
| Fedora         | `pipewire-jack-audio-connection-kit pulseaudio-utils`   | `webkit2gtk4.1`                    |
| Arch           | `pipewire-jack libpulse`                                | `webkit2gtk-4.1`                   |
| openSUSE       | `pipewire-libjack-0_3 pulseaudio-utils`                 | `libwebkit2gtk-4_1-0`              |
| Debian/Ubuntu  | `pipewire-jack pulseaudio-utils`                        | `libwebkit2gtk-4.1-0`              |

Or JACK2 (`jackd2`) instead of PipeWire. The virtual cables need PipeWire; without it, set `create_cables = false` (or start with `--no-cables`, which applies to that run only) and route with JACK. Without WebKitGTK, BananaSplit shows its window in Chromium, Chrome, Brave, Edge or Vivaldi (or your default browser) instead.

**From source:**

```sh
cargo build --release            # zero dependencies
target/release/bananasplit --install    # into ~/.local/bin and the app menu
bananasplit --low-latency               # optional but recommended for < 10 ms (see Latency)
```

`packaging/build-packages.sh` builds the .deb and the portable package. Run BananaSplit with `bananasplit --gui` (the app), `bananasplit` (terminal UI) or `bananasplit --headless` (no UI; `contrib/systemd/bananasplit.service` runs it in the background).

## Using it

1. Start BananaSplit from the app menu (or `bananasplit --gui`; `bananasplit` alone runs it in the terminal). Eight devices appear in your sound settings: `BananaSplit-In1-Mic` … `BananaSplit-In6-Aux` (outputs) and `BananaSplit-Out-B1`, `BananaSplit-Out-B2` (microphones). Strip 1 takes your default microphone and A1 plays on your default output (`@default`); `bananasplit --list-ports` shows what else you can connect.
2. Point applications at a strip by setting their output device (pavucontrol, GNOME/KDE settings, or the app itself), for example Discord to `BananaSplit-In2-Discord`. To send the whole desktop through BananaSplit, make `BananaSplit-In3-Desktop` the default output.
3. Choose where each strip goes with its A1 A2 A3 B1 B2 chips (keys `1`–`5` in the terminal UI).
4. In Discord or OBS, select **`BananaSplit-Out-B1`** as the microphone to receive the B1 mix.
5. The mixer state is saved automatically on quit; "Save settings" in the app's menu (`w` in the terminal UI) saves it at once.

Terminal UI keys: `↑↓` select · `←→` gain ±1 dB · `,` `.` ±0.1 dB · `0` 0 dB · `m` mute · `s` solo · `o` mono · `e` EQ on/off · `E` EQ page · `1-5` route · `c` link to recorder · `R` record/stop · `v` VBAN on/off · `r` reconnect · `w` save · `q` quit

A `●` after a row's number means that channel is linked to the recorder, and an `E` in the flags means its EQ is on. The line under the mixer shows the recorder: elapsed time and file while recording, otherwise the mode, format, links and folder. When VBAN is on, the line above the mixer shows how many streams are receiving and sending, and the line under the mixer lists the streams of the selected channel.

`E` opens the **EQ page** of the selected channel: its six bands, with the response drawn underneath (+18 to −15 dB, 20 Hz to 20 kHz). Keys there: `↑↓` band · `←→` field (type, frequency, gain, Q) · `,` `.` change it (a semitone, 0.5 dB, or a small Q step) · `<` `>` change it faster (a third of an octave, 3 dB) · `space` band on/off · `0` flatten the band · `e` EQ on/off · `[` `]` previous/next channel · `E` or `Enter` back to the mixer.

## The app (`bananasplit --gui`)

Start **BananaSplit** from the app menu, or run `bananasplit --gui`. The window shows, from left to right, the six **input strips** (green), the **hardware buses** A1–A3 (blue: speakers, headphones), the **virtual buses** B1–B2 (purple: the virtual microphones other apps record from) and the **recorder**; underneath, the quick-mix bar and the session panel.

**A strip, top to bottom:**

* the **name** (double-click it, or press F2, to rename) with its source underneath (`IN 01 · YETI` …; hover for the full connection) and a lamp that lights green with signal and red when it clipped;
* **GAIN**: the input gain, −24 to +24 dB (on a bus: before its fader). Drag the knob up or down, scroll over it, or use the arrow keys (Shift for fine steps); double-click for 0 dB. The **EQ** switch next to it opens the channel's EQ editor and lights while the EQ is on;
* **LEVEL**: the meter (left and right, after the fader) and the **fader**, −60 to +12 dB: drag it, scroll over it, use the arrow keys or Page Up/Down, double-click for 0 dB, or type a value into the box under it. **PK** is the highest level of the last 3 seconds (red after clipping);
* **PAN** (on buses **BALANCE**): the side it turns away from fades out, the other side stays at full level; double-click for centre. **MONO** sums left and right;
* **MUTE** and **SOLO** (strips only; while any strip is soloed, only soloed strips are heard), with their lamps;
* **TO**: where the strip goes, A1 A2 A3 B1 B2 (on buses: **OUTPUT**, the device it plays on).

Click a strip to select it (green outline); then **M** mutes it, **S** solos it, **O** switches mono, **E** opens its EQ, **1**–**5** route it, **[** and **]** select the previous or next strip. **Space** plays or pauses. **Ctrl +**, **Ctrl −** and **Ctrl 0** zoom.

**The recorder:** the **state** (ready, recording, playing, with the free disk space), the **waveform** of the selected recording (‹ › go through your takes; click into it to play from there; while recording it shows the armed channels' level), the **time code**, and **PLAY** (PAUSE while playing), **REC** and **STOP** (stops playback and recording). **PLAY TO** chooses the buses recordings play on (A1 by default): playback joins those buses before their EQ and fader, so it is heard, recorded and sent like anything else on them. **ARMED TRACKS** are the channels that are recorded: MIX puts them into one stereo file, MULTI writes one file per channel. **FORMAT** is 16-bit, 24-bit or 32-bit float. **OPEN** opens the recordings folder; the bar at the bottom is the disk.

**Scenes:** the **SCENE** menu saves the whole mix under a name ("Save the mix as a new scene…") and loads it back with one click; "Update" saves over the current scene, "Delete" (click twice) removes it. A scene holds every fader, gain, pan, mute, solo, mono, routing and EQ, and the armed tracks; it never changes names, devices, VBAN or recorder settings, and everything changes with the usual click-free ramps. Scenes are small files in `~/.config/bananasplit/scenes/`.

**MENU:** Save settings, Reconnect devices, Open the recordings folder, **Theme** (Dark, Light, or Auto to follow the desktop's light or dark style, GNOME's included), **Zoom**, **Start with the system**, **Closing the window keeps it running**, Add BananaSplit to the app menu (when it is not there yet), and **Quit BananaSplit** (click twice; it removes the virtual cables). The **VBAN** button opens the network audio window (its dot is green while streams flow).

* **EQ editor:** drag a numbered point on the curve to change that band's frequency and gain, scroll over it to change its Q, double-click it to flatten it, or select it and use the arrow keys (Page Up/Down for Q, Space for on/off). Below the curve, each band has its on switch, type, frequency (`1.5k` works), gain and Q. The switch at the top turns the channel's EQ on and off.
* **VBAN window:** the on switch, the UDP port, the incoming and outgoing streams with their status, and a list of streams that arrive but are not set up yet; **Receive** next to one of those adds it as an incoming stream.

### Window, tray and starting with the system

* The window is a separate process (GTK 3 and WebKitGTK 4.1 or 4.0, loaded when it starts, so BananaSplit itself still has no dependencies). If it crashes, the mixer keeps running; open it again from the app menu.
* **The tray icon** (StatusNotifierItem, the standard of KDE, Xfce, Cinnamon, MATE, Budgie, and of GNOME with the AppIndicator extension that Ubuntu ships): left click shows or hides the window; the menu has Show, Start/Stop recording (the icon gets a red dot while recording) and Quit. On GNOME without that extension there is no tray; BananaSplit then minimizes the window instead of hiding it, so you can always get it back from the dock.
* **Closing the window** keeps BananaSplit running in the tray (the mixer, its cables and its routing keep working, like Voicemeeter). To quit, use Quit in the menu or the tray, or "Quit BananaSplit" in the launcher's right-click menu (`bananasplit --quit`). Switch off "Closing the window keeps it running" to make closing quit.
* **Start with the system** writes `~/.config/autostart/bananasplit.desktop`, which runs `bananasplit --gui --hidden`: the mixer starts in the tray when you log in (it waits up to 30 seconds for the audio server). Switch it off in the menu.
* Launching BananaSplit again while it runs brings its window to the front (on Wayland too, through the desktop's activation token).
* If BananaSplit cannot start when launched from the app menu (no JACK or PipeWire, for example), it shows the reason in a dialog.
* The window size, theme, zoom and close behaviour are saved in the `[gui]` section of the config.
* **Without WebKitGTK** the page opens as an app window of Chromium, Chrome, Brave, Edge or Vivaldi, or in your default browser, and the tray icon still works (Show opens the page again).
* The page is served by BananaSplit itself on **http://127.0.0.1:8790** (this computer only); you can also open that address in any browser. Options: `--gui-port PORT` (default 8790; if 8790 is busy, BananaSplit picks a free port, prints it and notes it in `$XDG_RUNTIME_DIR/bananasplit/`, so launching it again and `--quit` still find it), `--no-open` (no window and no tray icon; open the printed URL yourself), `--hidden` (start in the tray). For a background service you can open at any time, change the service to run `bananasplit --gui --no-open`. Without `--gui`, no TCP port is open (VBAN, when you switch it on, uses a UDP port).
* Only you can use it: BananaSplit answers only connections from programs of the user it runs as (it checks who owns the connecting socket), so other users of the computer cannot listen in or change the mix. Requests must name `127.0.0.1`/`localhost` as their host, and changes need a header that other websites cannot send, so a web page open in your browser cannot drive it either. Programs you run yourself can, like the page does (as they could use your microphone directly).
* It controls the same mixer state as the terminal UI, with the same click-free ramps, and saves on quit the same way. Input gain, pan, the player and scenes are GUI controls; the terminal UI keeps them as they are and saves them too.

## Recorder

The recorder can take any combination of the 11 channels, numbered the same way everywhere: strips `1`–`6` and buses `A1`–`B2`. Arm a channel under ARMED TRACKS in the app's recorder panel, or link it with `c` in the terminal UI. Then press record (REC, or `R`).

* **What is recorded:** strips after their fader (gain, mute, solo and mono applied, exactly what the strip sends to the buses), and buses as they leave the mixer.
* **One mix file** (`mode = mix`): all linked channels are added into one stereo file. Links can change while recording; each change is ramped like a routing change, so it doesn't click. A strip linked together with a bus it feeds counts twice.
* **A file per source** (`mode = multi`): one stereo file per linked channel, for example `…_1-Mic.wav`, `…_A1-Speakers.wav`. They are taken from the same audio cycle, so they start on the same sample and always have the same length; drop them into a DAW and they line up. The set of tracks is fixed when recording starts.
* **Formats:** 16-bit, 24-bit (default) or 32-bit float WAV. 16- and 24-bit files clip anything above full scale, and the GUI and terminal UI warn you when that happens; 32-bit float keeps it.
* **Files** go to `~/Music/BananaSplit/` by default, named `YYYY-MM-DD_HH-MM-SS_<label>.wav` in local time. An existing file is never overwritten. The WAV header is rewritten every 2 seconds, so a recording is still playable if BananaSplit is killed. Takes over 4 GB continue in `_part2.wav`, `_part3.wav` …, split at the same sample for every track.
* **Real-time safe:** the audio callback copies each cycle into a preallocated lock-free ring buffer (no allocation, locks or syscalls; see `tests/recorder_no_alloc.rs`), and a separate thread writes the files. If the disk stalls for longer than the buffer holds (about 4 s with all 11 channels, much longer for fewer), the missing part is filled with silence so the tracks stay in sync, and the UI reports how many frames were lost.
* The recorder is available in the terminal UI and the GUI. `--headless` runs without it, exactly as before.

### Playing recordings back

The app's recorder panel also plays: it lists the WAV files in the recordings folder (newest last; ‹ › step through them), draws the selected one's waveform, and plays it with PLAY, PAUSE and STOP; clicking into the waveform plays from there. A multitrack take (the `_1-Mic.wav`, `_A1-Speakers.wav` … files of one recording) plays as one take, its tracks mixed. Files at another sample rate, from 8 kHz up to four times the mixer's (192 kHz at 48 kHz), are converted with the same windowed-sinc resampler VBAN uses; 8-, 16-, 24- and 32-bit PCM and 32/64-bit float WAV play. Stopping, seeking and changing takes fade out over one period, so they do not click. **PLAY TO** chooses the buses it plays on (`play_to` in `[recorder]`, A1 by default): playback joins those buses before their EQ and fader, so it is heard, recorded and sent over VBAN like anything else on them. The file is read by a separate thread; the audio callback only reads a preallocated lock-free buffer (see `tests/player_no_alloc.rs`). Recording and playing at the same time works; a take that is still being recorded plays up to where it was when the list was last refreshed (every 3 seconds).

## EQ

Every strip and every bus has a 6-band parametric EQ. On a strip it comes after mono and before the fader, so it shapes what the strip sends to every bus, the recorder and VBAN. On a bus it comes before the bus fader.

| Type | What it does | Gain | Q |
|---|---|---|---|
| `bell` | boosts or cuts around the frequency | ±24 dB | width: higher = narrower |
| `lowshelf`, `highshelf` | boosts or cuts everything below / above the frequency | ±24 dB | 0.71 = no bump |
| `lowcut`, `highcut` | removes everything below / above (12 dB/octave) | – | 0.71 = flat (Butterworth) |
| `notch` | removes a narrow band (hum, a whistle) | – | width |

* The defaults are a low shelf at 100 Hz, bells at 250 Hz, 600 Hz, 1.5 kHz and 4 kHz, and a high shelf at 10 kHz, all at 0 dB. A new channel's EQ is off.
* The filters are the standard "Audio EQ Cookbook" responses (the GUI and terminal curves are computed from the same formulas), built as state-variable filters so that any change, even dragging a band across the whole range, glides smoothly without clicks or zipper noise.
* An EQ that is off, or whose bells and shelves are all at 0 dB with no cut or notch switched on, does nothing at all: the filters are skipped and the audio is unchanged bit for bit.
* Boosts can push a channel above 0 dBFS. Watch the meter and lower the fader if it clips.

## VBAN (network audio, Voicemeeter compatible)

VBAN is VB-Audio's protocol for sending audio over a network as UDP packets. BananaSplit implements the VBAN audio protocol (specification revision 13), so it can exchange audio with Voicemeeter on a Windows PC, with VB-Audio's VBAN apps, and with other BananaSplit machines.

* **Incoming streams** (8): a stream is known by its **name** and its **sender's IP address**, as in Voicemeeter. Each one is added to the input of a strip you choose, before that strip's EQ, fader and routing, so it mixes like anything else on that strip. Names are compared without regard to case. BananaSplit accepts every VBAN sample rate up to four times its own (for example up to 192 kHz at 48 kHz), 8-, 16-, 24- and 32-bit PCM and 32/64-bit float, and any number of channels (channels 1 and 2 are used; a mono stream plays on both sides).
* **Outgoing streams** (8): each sends one of the 11 channels (a strip after its fader, or a bus) to an IPv4 address and port, at BananaSplit's sample rate, as 16-, 24- or 32-bit PCM or 32-bit float, stereo or mono. A broadcast address such as `192.168.1.255` sends to every computer on the network.
* **One UDP port** (6980 by default, the same as Voicemeeter) receives every incoming stream and sends every outgoing one, so packets leave from port 6980 like Voicemeeter's do. VBAN is **off** by default; while it is off, BananaSplit does not listen. A stream BananaSplit sends that comes back to it (sent to its own address or to a broadcast address) is ignored, so it cannot feed back into itself.
* **Clock drift and jitter:** two computers' audio clocks never run at exactly the same speed, and networks (Wi-Fi especially) deliver packets in bursts. For each incoming stream BananaSplit measures the sender's clock against its own and follows it by resampling (high-quality windowed sinc). The speed changes glide and stay tiny: the clock difference itself (usually a few tens of ppm) plus at most 0.05 % to keep the buffer at its level, far below what anyone can hear. BananaSplit keeps a reserve of audio for late packets, `buffer_ms` (10 ms by default) at the buffer's lowest point, on top of what the sender's packet timing needs; the latency shown next to the stream includes all of it. If the audio still drops out (a network hiccup longer than the reserve), BananaSplit fades out, waits until it holds enough to ride out the same hiccup again, and fades back in. It also adds 5 ms to the reserve (up to 200 ms, given back 1 ms per 30 s without dropouts), and trims the extra delay of the restart back slowly, about half a millisecond per second. A lost packet becomes a short silence of the same length, so the stream does not shift.
* **Real-time safe:** the audio callback only reads and writes preallocated lock-free buffers; the network work is done by two separate threads (see `tests/eq_vban_no_alloc.rs`).

### With Voicemeeter

1. On the Linux computer, switch VBAN on: `v` in the terminal UI, the switch in the GUI's VBAN window, or `enabled = true` under `[vban]`. Find its IP address with `ip -4 addr`.
2. Open UDP port 6980 in the Linux firewall if it has one: `sudo ufw allow 6980/udp` (Ubuntu) or `sudo firewall-cmd --add-port=6980/udp --permanent && sudo firewall-cmd --reload` (Fedora). Windows asks whether to allow Voicemeeter through its firewall the first time; allow it on private networks.
3. **Voicemeeter → BananaSplit:** in Voicemeeter's VBAN window, set up an outgoing stream to the Linux computer's IP, port 6980, with a name such as `Stream1`, and switch VBAN on there. 16- or 24-bit PCM works well. On BananaSplit, it then appears above the incoming streams in the GUI's VBAN window (click **Receive**), or add it to the config: `name = Stream1`, `from = <the Windows PC's IP>`, `strip = 6`.
4. **BananaSplit → Voicemeeter:** add an outgoing stream in BananaSplit with `to = <the Windows PC's IP>`, port 6980, and a name; in Voicemeeter, add an incoming stream with the same name and the Linux computer's IP as the source. 16-bit (the default) or 24-bit PCM works well. If Voicemeeter's side crackles over Wi-Fi, raise that incoming stream's Net Quality setting in Voicemeeter.

VBAN audio is not encrypted or authenticated, in Voicemeeter or here. BananaSplit only plays a stream whose name and sender IP match one you set up, so give incoming streams the sender's address rather than `any` on networks you don't trust.

## Configuration: `~/.config/bananasplit/bananasplit.ini`

Created with defaults on the first run (see `bananasplit --print-default-config`). Parsing is strict: a typo produces an error with a line number instead of being ignored.

```ini
[global]
client_name = BananaSplit
buffer_size = 128          # period requested from PipeWire (PIPEWIRE_LATENCY); 0 = don't ask
force_buffer_size = false  # true = jack_set_buffer_size() (JACK2: changes it for every client)
create_cables = true

[gui]
theme = dark               # dark | light | auto (follows the desktop)
close_to_tray = true       # closing the window keeps BananaSplit running in the tray
zoom = 1                   # 0.5 .. 2
window = 1780x1000         # the window's size, saved when it closes
scene = Live Room          # the scene loaded last (the SCENE menu shows it)

[strip1]
name = Mic
gain_db = 0.0              # the fader: -60 .. +12
trim_db = 0.0              # the GAIN knob (input gain): -24 .. +24
pan = 0.0                  # -1 (left) .. 1 (right); on a bus, the balance
mono = true
routes = B1                # any of A1,A2,A3,B1,B2 or none
connect = @default         # the default microphone; may be repeated

[strip2]
connect = ^Firefox:output_F[LR]$   # or any JACK port regex

[bus.A1]
name = Speakers
connect = @default         # the default output device
[bus.A2]
connect = ^Yeti Stereo Microphone Analog Stereo-63:   # from `bananasplit --list-ports`

[strip3]
eq = on                    # this channel's EQ: on | off (default off)
eq1 = lowcut 80 +0 0.71    # band 1-6: type freq gain Q [off]
eq4 = bell 3000 -4.5 2     # bands left out keep their defaults

[recorder]
folder = ~/Music/BananaSplit
format = wav24             # wav16 | wav24 | wav32f
mode = mix                 # mix (one stereo file) | multi (one file per linked channel)
links = 1,A1               # 1-6 = strips, A1-A3 / B1-B2 = buses, or none
play_to = A1               # the buses recordings play on (any of A1..B2, or none)

[vban]
enabled = true             # default false: nothing listens
port = 6980                # UDP; receives every incoming stream, sends every outgoing one

[vban.in1]                 # incoming streams: [vban.in1] .. [vban.in8]
on = true
name = Stream1             # the sender's stream name (case does not matter)
from = 192.168.1.20        # the sender's IPv4 address, or any
strip = 6                  # added to this strip's input (1-6)
buffer_ms = 10             # reserve for late packets (0-200; raised by itself after dropouts)

[vban.out1]                # outgoing streams: [vban.out1] .. [vban.out8]
on = true
name = Linux
to = 192.168.1.20          # the receiver's IPv4 address (x.x.x.255 = broadcast)
port = 6980
source = B1                # 1-6 = a strip after its fader, A1-A3 / B1-B2 = a bus
format = int16             # int16 | int24 | int32 | float32
channels = 2               # 2 (stereo) | 1 (mono: (L+R)/2)
```

EQ types are `bell`, `lowshelf`, `highshelf`, `lowcut`, `highcut` and `notch`; the frequency is 20–20000 Hz, the gain −24 to +24 dB (ignored by the cuts and the notch) and Q 0.1–30. BananaSplit writes only the bands and streams that differ from the defaults.

A config file from an earlier BananaSplit (without `[gui]`, `trim_db`, `pan`, `play_to`, `[recorder]`, EQ or `[vban]`) still loads; what is missing starts with its default: 0 dB input gain, centre, the dark theme, closing to the tray, the recorder linked to A1 only and playing to A1, every EQ off, and VBAN off.

**Scenes** are saved next to the config, in `~/.config/bananasplit/scenes/<name>.ini`, in the same format (the `[stripN]`, `[bus.XX]` and `[recorder]` keys a scene holds; a key left out takes its default value). You can copy them between computers. Only files that start with BananaSplit's `# BananaSplit scene` line are listed, and only those are ever replaced or deleted.

### Choosing devices

| `connect =`  | strip (takes audio from)                       | bus (sends audio to)              |
|--------------|-------------------------------------------------|-----------------------------------|
| `@default`   | the default input in your sound settings       | the default output                |
| `@physical`  | a physical capture device, the default if it is one, else the first JACK lists | a physical playback device, same rule |
| a regex      | the first two matching JACK ports → L, R       | same                              |

`@default` needs PipeWire and `pactl`. Without them, or when the default device is one of BananaSplit's own cables (for example if you made `BananaSplit-In3-Desktop` the default output), it falls back to `@physical` and says so. In that case put an explicit pattern on A1.

**Patterns match JACK names, not PipeWire node names.** PipeWire calls a device something like `alsa_input.usb-Blue_Microphones_Yeti-00.analog-stereo`, but its JACK layer names the ports after the description: `Yeti Stereo Microphone Analog Stereo:capture_FL`. A device's microphone and headphone sides often share a description, so one of them gets `-NN` appended. `bananasplit --list-ports` prints every name with a ready-made line:

```
For a strip, [strip1] … [strip6] (ports that send audio):
  Razer Kiyo Analog Stereo                capture_FL capture_FR
      physical · PipeWire node alsa_input.usb-Razer_Kiyo-02.analog-stereo
      connect = ^Razer Kiyo Analog Stereo:
  Yeti Stereo Microphone Analog Stereo    capture_FL capture_FR
      physical · default input · PipeWire node alsa_input.usb-Blue_Yeti-00.analog-stereo
      connect = ^Yeti Stereo Microphone Analog Stereo:
…
@default  → strips: "Yeti Stereo Microphone Analog Stereo"
          → buses:  "Yeti Stereo Microphone Analog Stereo-63"
```

When a pattern matches nothing, the message says why if it can: `that is the PipeWire node name; JACK calls this device "…": use connect = ^…:`, `names are case-sensitive: did you mean "…"?`, or that the matching ports point the wrong way. In `--headless` and `--gui` mode the ports that side could use are also listed on stderr.

When ports appear or disappear (hot-plugged headsets, apps starting), BananaSplit re-applies the configured connections automatically. It never removes connections, including ones you made yourself.

## Latency

`bananasplit --low-latency` writes `contrib/pipewire`'s two files (built into the binary) to `~/.config/pipewire/pipewire.conf.d/` and `pipewire-pulse.conf.d/`. It also applies the graph settings to the running PipeWire with `pw-metadata`, so 128-frame periods start immediately, without a restart. The smaller default buffers for browsers and Discord apply the next time pipewire-pulse starts (`systemctl --user restart pipewire pipewire-pulse wireplumber`, which briefly interrupts all audio). A file you have changed is never overwritten. `bananasplit --low-latency off` removes the files again (only if they are unchanged) and drops the live settings.

About 1.5 s after starting, once JACK reports the latency of the connected devices, BananaSplit checks the round trip. If it is 10 ms or more, it prints one line saying what to do. In the terminal UI that line has its own row.

| Message | Meaning |
|---|---|
| `… (goal < 10 ms): run bananasplit --low-latency` | The low-latency settings are not installed. |
| `1024-frame periods despite the low-latency config: restart PipeWire` | Installed but not active. |
| `… the sound card adds N ms (see README)` | The period is small already. The rest is the device's own buffering, typical for USB audio. You can lower it per device with a WirePlumber rule, see below. Test it, because some devices crackle with less headroom. |
| `…: start jackd with -p 128` | Plain JACK2, not PipeWire. |

Per-device ALSA buffering (WirePlumber 0.5), in `~/.config/wireplumber/wireplumber.conf.d/51-bananasplit-usb.conf`:

```
monitor.alsa.rules = [
  { matches = [ { node.name = "~alsa_.*usb-Blue.*" } ]
    actions = { update-props = { api.alsa.period-size = 128, api.alsa.headroom = 0 } } }
]
```

## If BananaSplit is killed

On a normal exit (Quit in the app's menu or tray, `bananasplit --quit`, `q` in the terminal UI, Ctrl-C, `systemctl stop`) BananaSplit removes its eight cables, and PipeWire moves any app that was playing into them back to the default output. If BananaSplit is killed with SIGKILL or crashes, a small watchdog process it started (`bananasplit --reap-cables bananasplit` in `ps`) sees that BananaSplit is gone and removes the cables within a fraction of a second. If the watchdog was killed too, the next `bananasplit` start removes the leftovers, or you can run `bananasplit --cleanup` now. `--cleanup` refuses while that BananaSplit is still running. The systemd unit runs `bananasplit --cleanup` as `ExecStopPost`. All of these match cables by their exact names, so nothing else is touched.

## Tests

```sh
cargo test                       # 141 unit tests + 4 "audio path never allocates" tests
tests/e2e/run_e2e.sh             # runs the real binary against a mock libjack (needs gcc, curl and python3)
node tests/gui/ui_check.js       # clicks every control of the app in Chromium (needs Node.js + Playwright)
tests/window/run_window_test.sh  # the app window and the tray icon on Xvfb (needs GTK 3, Xvfb, dbus-python)
```

The end-to-end test drives BananaSplit's real process callback through a mock JACK server. It checks that impulses fed to two different strips come out on A1 and B1 at the **exact same frame and cycle** they went in, with the correct mix values. It also checks that every output buffer is fully written each cycle, that 8 cables are created, wired and removed, that a stale cable from a crash is cleaned up, and that SIGINT/SIGTERM shut down cleanly. A third phase starts `bananasplit --gui`, drives it over HTTP exactly like the page does (including the security checks and a second `--gui` launch), records strip 1 and A1 in multi mode, and checks that both WAV files hold the impulse on the **same sample** with the correct values.

A fourth phase covers the 2.3 fixes on a mock of the reviewed setup: a webcam listed before a USB mic, the mic's headphone side named `…-63`, and a 17.3 ms round trip. It checks that:

* `--no-cables` leaves `create_cables = true` in the saved config;
* `@physical` and `@default` take the mic, not the webcam, and never a monitor port;
* each kind of pattern miss gets the right hint, and the available ports are listed;
* the latency advice appears;
* `--list-ports` prints the right lines;
* `--low-latency` installs, applies and undoes;
* after `kill -9` the watchdog removes all 8 cables and nothing else;
* `--cleanup` refuses while BananaSplit runs and sweeps afterwards.

The GUI phase also sets an EQ and VBAN streams over HTTP, checks that bad values are refused, and that everything is saved. A fifth phase tests VBAN and the EQ with a VBAN peer written separately, from VB-Audio's specification only (`tests/e2e/vban_peer.py`, Python standard library). The peer plays Voicemeeter: it sends a 1 kHz sine at 44.1 kHz, 24-bit, in bursts of 512 samples, mixed with packets BananaSplit must ignore (VBAN-TEXT, an unknown stream name, a wrong size, a truncated header). BananaSplit adds it to strip 4, whose EQ boosts 1 kHz by 6 dB, and sends strip 4 back at 48 kHz, 16-bit, while the mock JACK server runs in real time. The peer checks every header field, the frame counter, the source port, and that the audio is a clean 1 kHz sine at the expected level in every 100 ms (no dropout or glitch), with left and right in the right order.

Unit tests also cover the VBAN header against the specification (every sample rate and format, every rejection rule, random garbage), the resampler (44.1 ↔ 48 kHz, 8 to 192 kHz, aliasing below −85 dB), the drift tracking (simulated senders whose clocks run up to 2000 ppm off, with jitter, lost packets, stalls and pauses), two VBAN instances talking over real sockets, the EQ against the Audio EQ Cookbook formulas at three sample rates, and the EQ's click-free changes.

The no-allocation tests run thousands of cycles with parameters changing underneath: one with the recorder recording (both modes, live link changes, a full buffer), one with every EQ changing and VBAN streams flowing both ways (underruns, a full outgoing buffer, flushes), and one with the player playing, pausing, seeking and changing buses while input gain and pan move. A counting allocator proves the audio path never touches the heap.

New in 2.6:

* Phase 3 also checks that requests from another user of the computer are refused (when the test runs as root, it acts as `nobody`; otherwise it prints a SKIP line).
* A sixth end-to-end phase gives BananaSplit a system libjack that finds no JACK server and a second libjack in PipeWire's private folder: without PipeWire running it reports the error as before; with PipeWire running it opens PipeWire's libjack, the mixer runs, and JACK2's error messages stay hidden.
* A seventh phase keeps port 8790 busy: BananaSplit moves to another port and notes it, a second launch and `--quit` find it there (and `--quit` for another client name leaves it alone), and after the program file is replaced while it runs (as an update does), "Start with the system" names the new file.
* `tests/gui/ui_check.js` starts BananaSplit on the mock JACK server (in real time) and works the page in Chromium like a person: it drags faders and knobs, double-clicks, types, scrolls, renames a strip, switches MUTE, SOLO, MONO and routing, edits an EQ band by dragging it, arms tracks, records a take, plays it back and checks that it reaches A1, pauses, plays from a click into the waveform and jumps while playing, saves and loads a scene, switches the theme and zoom, uses the keyboard shortcuts, and checks after every action that the mixer's state changed the way the control says (83 checks).
* `tests/window/run_window_test.sh` runs the real app window (GTK 3 on Xvfb) with a tray written from the StatusNotifierItem and dbusmenu specifications: the window opens with the page, the tray menu starts and stops recording, closing hides to the tray and the mixer keeps running, the app-menu launch and the tray bring it back, a crashed window leaves the mixer running, Quit stops everything and saves the window size; without a tray closing minimizes, `close_to_tray = false` quits, without WebKitGTK the page opens in a browser, `--hidden` starts in the tray, a start-up error launched from the app menu appears in a dialog, the Auto theme follows the desktop's dark style live (from a settings portal written from its specification), and a window restarted while recording, after an update replaced the program file, comes from the running program (not the new file, not a browser) and shows the recording in the tray.
* Unit tests cover the input gain and pan (centre and 0 dB are bit-exact), the WAV reader (every format, broken and still-growing files), playback (bit-exact at the same rate, a 44.1 kHz sine played at 48 kHz, fades on stop and seek and before running dry, sample rates it refuses), who may connect, scenes (names, strict parsing, round trips), the desktop entries (Exec quoting, TryExec, the icons), the tray's D-Bus menu, and the new `[gui]` settings. `packaging/build-packages.sh` checks the packages it builds: the .deb's contents and control file, the desktop entry, and the portable package's install and uninstall in a throw-away home folder (which also check that files BananaSplit did not write are never touched).

## Limitations

* Not included from Voicemeeter: Intellipan, the compressor/gate, macro buttons, and VBAN's other parts: remote control (VBAN-TEXT), MIDI/serial, the service ping that lists VBAN devices, and the VB-Audio codecs (VBCA/VBCV). BananaSplit sends and receives uncompressed PCM audio only, the format Voicemeeter uses by default.
* VBAN uses IPv4 only. An incoming stream may have at most four times BananaSplit's sample rate.
* VBAN and the EQ were tested against a VBAN implementation written from the specification, not against Voicemeeter itself. Check a stream in both directions on your own network before relying on it live.
* **The app window was tested with GTK 3 on an X server and a stand-in for WebKitGTK, and the page itself in Chromium**, not on a real desktop with WebKitGTK; the tray was tested against a tray written from the specifications, not against KDE's, GNOME's or Xfce's own. Check the window, the tray and Start with the system on your desktop before relying on them live. WebKitGTK 2.40 or newer draws every detail (some lit buttons lose their tint on older versions).
* On GNOME the tray icon needs the AppIndicator extension (Ubuntu ships it; on Fedora install `gnome-shell-extension-appindicator`). Without it, closing the window minimizes it.
* On Wayland the window manager decides where the window opens; BananaSplit only sets its size.
* The page in a browser needs a current one (Chromium/Chrome 111+, Firefox 113+); the browser app-window mode needs a Chromium-based one.
* Only an x86-64 (amd64) build is packaged; on ARM, build from source.
* **App-side buffering is not under any mixer's control.** PulseAudio-API apps (browsers, Discord) choose their own buffer sizes. The `pipewire-pulse` snippet lowers the default, but an app that asks for 40 ms gets 40 ms. Native PipeWire and JACK apps follow the graph quantum.
* With **two different sound cards** on A1/A2, PipeWire clocks one and adaptively resamples the other, which is the correct way to handle two clock domains. Plain JACK2 can only drive one card.
* The 2.3 changes were tested against a mock JACK server and a fake `pactl`/`pw-metadata` that print what PipeWire prints. Check `bananasplit --list-ports` and `bananasplit --low-latency` on your own machine before relying on them live.
