# BananaSplit: a 6-strip virtual audio mixer for Linux

A Voicemeeter Banana-style mixer written in Rust, with **6 input strips**, **3 hardware buses (A1–A3)**, **2 virtual buses (B1–B2)**, **one virtual cable per strip**, a **6-band EQ** on every strip and bus, **VBAN network audio** that works with Voicemeeter, and a **recorder** that can take any of those 11 channels. It runs as a single real-time JACK client, natively on JACK2 or on PipeWire's JACK layer, and you control it from the terminal or from a graphical window (`bananasplit --gui`).

```
 BananaSplit  6 strips · 5 buses · JACK client "BananaSplit" · 8 cables
 48000 Hz · 128 fr · 2.67 ms/period · RTT 6.10 ms [OK <10ms] · DSP 1% · xruns 0
 VBAN UDP 6980 · in: 1 of 1 receiving · out: 1 of 1 sending
  #  NAME              GAIN  L          R          PEAK M S O E  A1 A2 A3 B1 B2
> 1  Mic               +0.0  ██████···· ██████····  -24 · · O E  A1 A2 A3 B1 B2
  2  Discord           -7.4  █████····· █████·····  -31 · · · ·  A1 A2 A3 B1 B2
  ...
 A2  Blue Headphones   +0.0  ████······ ████······  -30 ·   · E
```

## What's new in 2.5

* **New name.** vmix is now **BananaSplit**: the command is `bananasplit`, the JACK client and the virtual cables are called `BananaSplit` (`BananaSplit-In1-Mic`, `BananaSplit-Out-B1`, …), the config lives in `~/.config/bananasplit/bananasplit.ini`, and recordings go to `~/Music/BananaSplit/` by default.
* **Dark mode for the GUI**, redesigned: near-black panels, banana-yellow keys and faders, and a **theme switch** in the top bar (Auto follows your desktop, or pick Light or Dark; the GUI remembers it).

Upgrading from vmix 2.4:

* The first start copies `~/.config/vmix/vmix.ini` to the new place, so your strips, routing, EQ, VBAN and recorder settings come along. The old file is left alone. If your JACK name was the old default `vmix`, it becomes `BananaSplit`; that renames the virtual cables, so pick them again once in the apps that used them (sound settings, Discord, OBS). A name you chose yourself is kept, and so is your recorder folder.
* If you ran `vmix --low-latency`, BananaSplit sees those files as installed. `bananasplit --low-latency` replaces them with its own, and `bananasplit --low-latency off` removes them too.
* Copy `contrib/bananasplit.desktop` and `contrib/systemd/bananasplit.service` again if you installed the old ones (and `systemctl --user disable --now vmix`).

## What's new in 2.4

* **VBAN**, compatible with Voicemeeter (Banana, Potato and the others) and with VB-Audio's VBAN apps: up to 8 incoming streams, each added to a strip of your choice, and up to 8 outgoing streams, each sending a strip or a bus to another computer. Incoming streams can have any sample rate, format and channel count; BananaSplit resamples them and follows the sender's clock, so they play without gaps or drift. See [VBAN](#vban-network-audio-voicemeeter-compatible).
* **EQ** on all 11 channels: 6 bands, each a bell, low or high shelf, low or high cut, or notch, from 20 Hz to 20 kHz, ±24 dB, Q 0.1–30. It is off by default; off, or flat, it leaves the audio bit for bit unchanged. See [EQ](#eq).
* Both work in the terminal UI (`e`, `E`, `v`), in the GUI (an EQ editor with a draggable curve, a VBAN window) and in `--headless` mode, and both are saved in the config file.

## What's new in 2.3

Changes from a review on real hardware:

* `--no-cables` now applies to one run only. It is no longer written into the config file.
* **`connect = @default`** follows the input and output devices chosen in your desktop's sound settings, and it is the new default for strip 1 and A1. `@physical` now prefers the default device too, instead of whichever device JACK lists first (a webcam, for example).
* **`bananasplit --list-ports`** shows every JACK name a `connect` pattern can match, with a ready-made `connect =` line per device. When a pattern matches nothing, BananaSplit says why: a PipeWire node name was used instead of the JACK name, the case is wrong, or the port points the wrong way. On stderr it also lists the ports that would work.
* **`bananasplit --low-latency`** installs and applies the PipeWire low-latency settings in one step. At startup, BananaSplit warns if the round trip is 10 ms or more and says what to do about it.
* **Killed BananaSplit:** a small watchdog process removes the virtual cables if BananaSplit is killed with SIGKILL or crashes. `bananasplit --cleanup` and the systemd unit's `ExecStopPost` cover the case where the watchdog was killed too.
* **Terminal UI:** names get 15 columns at 80 columns (more on a wider terminal) and end in `…` when cut. Long status lines are cut instead of wrapping, and the PEAK column no longer shifts by one between silent and loud rows.

## ASIO / WASAPI on Linux

ASIO and WASAPI are **Windows-only** driver APIs and do not exist on Linux. What they give you on Windows (exclusive device access, no OS mixer or resampler in the path, small fixed buffers, and one callback that sees every channel at once) is what **JACK** provides on Linux. PipeWire implements the same API.

| Windows                       | BananaSplit on Linux                                                       |
|-------------------------------|---------------------------------------------------------------------|
| ASIO driver                   | JACK2 server, or PipeWire + `pipewire-jack`                         |
| WASAPI exclusive mode         | Device opened only by JACK/PipeWire at a fixed rate and quantum     |
| VB-Cable / "Voicemeeter Input"| `BananaSplit-In1…6` virtual output devices (PipeWire sinks)                |
| "Voicemeeter Output" (B1/B2)  | `BananaSplit-Out-B1`, `BananaSplit-Out-B2` virtual microphones                    |
| Voicemeeter Banana            | `bananasplit`                                                              |

## Sync and latency

* **Sample-synchronous by design.** The whole mixer (all 12 input channels and 10 output channels) is computed inside **one** JACK process callback for the same block of frames. A sample entering any strip at frame *k* leaves every bus at frame *k* of the same cycle. The mixer itself adds **0 samples** of latency.
* **Virtual cables add no buffering.** They are nodes in the same PipeWire graph, driven by the same clock, and processed in the same cycle.
* **Sub-10 ms** depends on the server's period. Use 48 kHz with 128 frames: 2.67 ms per period, which gives about 6–8 ms hardware round-trip including driver headroom. Run `bananasplit --low-latency` once to pin this (see [Latency](#latency)). The UI shows the measured round-trip from JACK's latency API and turns red if it reaches 10 ms or more.
* **Real-time safe.** The audio callback does no allocation, no locks, no syscalls, and cannot panic. Every gain, mute, solo, or routing change is ramped over one period, so changes don't click.

## Install

Requirements (PipeWire, the default on current Fedora, Ubuntu, Debian, Arch, and others):

| Distro         | Packages                                                     |
|----------------|--------------------------------------------------------------|
| Fedora         | `pipewire-jack-audio-connection-kit pulseaudio-utils`        |
| Arch           | `pipewire-jack libpulse`                                     |
| Debian/Ubuntu  | `pipewire-jack pulseaudio-utils`                             |

Or JACK2 (`jackd2`). The virtual cables need PipeWire; without it, set `create_cables = false` (or start with `--no-cables`, which applies to that run only) and route with JACK.

```sh
cargo build --release            # zero dependencies
install -Dm755 target/release/bananasplit ~/.local/bin/bananasplit
bananasplit --low-latency               # optional but recommended for < 10 ms (see Latency)
```

Run it with `bananasplit` (terminal UI) or `bananasplit --gui` (graphical window). On **Debian/Ubuntu**, run `pw-jack bananasplit` so it uses PipeWire's libjack instead of JACK2's. To run it in the background, use `contrib/systemd/bananasplit.service`, which runs `bananasplit --headless`.

## Using it

1. Start `bananasplit`. Eight devices appear in your sound settings: `BananaSplit-In1-Mic` … `BananaSplit-In6-Aux` (outputs) and `BananaSplit-Out-B1`, `BananaSplit-Out-B2` (microphones). Strip 1 takes your default microphone and A1 plays on your default output (`@default`); `bananasplit --list-ports` shows what else you can connect.
2. Point applications at a strip by setting their output device (pavucontrol, GNOME/KDE settings, or the app itself), for example Discord to `BananaSplit-In2-Discord`. To send the whole desktop through BananaSplit, make `BananaSplit-In3-Desktop` the default output.
3. Choose where each strip goes with keys `1`–`5` (A1 A2 A3 B1 B2).
4. In Discord or OBS, select **`BananaSplit-Out-B1`** as the microphone to receive the B1 mix.
5. Press `w` to save. The mixer state is also saved automatically on quit.

Keys: `↑↓` select · `←→` gain ±1 dB · `,` `.` ±0.1 dB · `0` 0 dB · `m` mute · `s` solo · `o` mono · `e` EQ on/off · `E` EQ page · `1-5` route · `c` link to recorder · `R` record/stop · `v` VBAN on/off · `r` reconnect · `w` save · `q` quit

A `●` after a row's number means that channel is linked to the recorder, and an `E` in the flags means its EQ is on. The line under the mixer shows the recorder: elapsed time and file while recording, otherwise the mode, format, links and folder. When VBAN is on, the line above the mixer shows how many streams are receiving and sending, and the line under the mixer lists the streams of the selected channel.

`E` opens the **EQ page** of the selected channel: its six bands, with the response drawn underneath (+18 to −15 dB, 20 Hz to 20 kHz). Keys there: `↑↓` band · `←→` field (type, frequency, gain, Q) · `,` `.` change it (a semitone, 0.5 dB, or a small Q step) · `<` `>` change it faster (a third of an octave, 3 dB) · `space` band on/off · `0` flatten the band · `e` EQ on/off · `[` `]` previous/next channel · `E` or `Enter` back to the mixer.

## GUI

```sh
bananasplit --gui
```

opens the mixer in its own window: six numbered input strips, the five buses, and the recorder. Every strip has a stereo meter with a clip light, a fader (drag it, scroll over it, or use the arrow keys; double-click for 0 dB; type an exact value in the box below), mute, mono, solo, the A1–B2 routing keys, an EQ key, and a round button that links it to the recorder. Click a strip's name to rename it. VBAN, the theme switch, Save, Reconnect and Quit are in the top bar, next to the sample rate, period, measured round trip, DSP load and xruns.

* **Theme:** Auto (the default) follows your desktop's light or dark setting; Light and Dark override it. The choice is remembered by the browser that shows the GUI.

* **EQ:** the `EQ` key switches a channel's EQ on and off; `…` next to it opens the editor. Drag a numbered point on the curve to change that band's frequency and gain, scroll over it to change its Q, double-click it to flatten it, or select it and use the arrow keys (Page Up/Down for Q, Space for on/off). Below the curve, each band has its on switch, type, frequency (`1.5k` works), gain and Q.
* **VBAN:** the `VBAN` button opens the network audio window (its dot is green while streams are flowing): the on switch, the UDP port, the incoming and outgoing streams with their status, and a list of streams that arrive but are not set up yet. **Receive** next to one of those adds it as an incoming stream.
* The GUI has no dependencies. BananaSplit serves the page itself on **http://127.0.0.1:8790** (this computer only) and opens it as an app window with Chromium, Chrome, Brave, Edge or Vivaldi, or in your default browser. Without `--gui`, no TCP port is open (VBAN, when you switch it on, uses a UDP port).
* It controls the same mixer state as the terminal UI, with the same click-free ramps, and saves on quit the same way.
* Running `bananasplit --gui` again while it is already running just reopens the window, so it works from an app launcher. Install `contrib/bananasplit.desktop` to `~/.local/share/applications/` for a menu entry.
* Options: `--gui-port PORT` (default 8790; if 8790 is busy, BananaSplit picks a free port and prints it), `--no-open` (don't open a window; open the printed URL yourself). For a background service you can open at any time, change the service to run `bananasplit --gui --no-open`.
* Only pages served by BananaSplit itself can change the mixer. Requests must name `127.0.0.1`/`localhost` as their host, and changes need a header that other websites cannot send, so a web page open in your browser cannot drive it.

## Recorder

The recorder can take any combination of the 11 channels, numbered the same way everywhere: strips `1`–`6` and buses `A1`–`B2`. Link a channel with its round button in the GUI, with a numbered chip in the GUI's recorder panel, or with `c` in the terminal UI. Then press record (the big button, or `R`).

* **What is recorded:** strips after their fader (gain, mute, solo and mono applied, exactly what the strip sends to the buses), and buses as they leave the mixer.
* **One mix file** (`mode = mix`): all linked channels are added into one stereo file. Links can change while recording; each change is ramped like a routing change, so it doesn't click. A strip linked together with a bus it feeds counts twice.
* **A file per source** (`mode = multi`): one stereo file per linked channel, for example `…_1-Mic.wav`, `…_A1-Speakers.wav`. They are taken from the same audio cycle, so they start on the same sample and always have the same length; drop them into a DAW and they line up. The set of tracks is fixed when recording starts.
* **Formats:** 16-bit, 24-bit (default) or 32-bit float WAV. 16- and 24-bit files clip anything above full scale, and the GUI and terminal UI warn you when that happens; 32-bit float keeps it.
* **Files** go to `~/Music/BananaSplit/` by default, named `YYYY-MM-DD_HH-MM-SS_<label>.wav` in local time. An existing file is never overwritten. The WAV header is rewritten every 2 seconds, so a recording is still playable if BananaSplit is killed. Takes over 4 GB continue in `_part2.wav`, `_part3.wav` …, split at the same sample for every track.
* **Real-time safe:** the audio callback copies each cycle into a preallocated lock-free ring buffer (no allocation, locks or syscalls; see `tests/recorder_no_alloc.rs`), and a separate thread writes the files. If the disk stalls for longer than the buffer holds (about 4 s with all 11 channels, much longer for fewer), the missing part is filled with silence so the tracks stay in sync, and the UI reports how many frames were lost.
* The recorder is available in the terminal UI and the GUI. `--headless` runs without it, exactly as before.

## EQ

Every strip and every bus has a 6-band parametric EQ. On a strip it comes after mono and before the fader, so it shapes what the strip sends to every bus, the recorder and VBAN. On a bus it comes before the bus fader.

| Type | What it does | Gain | Q |
|---|---|---|---|
| `bell` | boosts or cuts around the frequency | ±24 dB | width: higher = narrower |
| `lowshelf`, `highshelf` | boosts or cuts everything below / above the frequency | ±24 dB | 0.71 = no bump |
| `lowcut`, `highcut` | removes everything below / above (12 dB/octave) | – | 0.71 = flat (Butterworth) |
| `notch` | removes a narrow band (hum, a whistle) | – | width |

* The defaults are a low shelf at 100 Hz, bells at 250 Hz, 600 Hz, 1.5 kHz and 4 kHz, and a high shelf at 10 kHz, all at 0 dB. A new channel's EQ is off.
* The filters are the standard "Audio EQ Cookbook" responses (the GUI and terminal curves are computed from the same formulas), built as state-variable filters so that any change, even dragging a band across the whole range, glides smoothly without clicks or zipper noise.
* An EQ that is off, or whose bells and shelves are all at 0 dB with no cut or notch switched on, does nothing at all: the filters are skipped and the audio is unchanged bit for bit.
* Boosts can push a channel above 0 dBFS. Watch the meter and lower the fader if it clips.

## VBAN (network audio, Voicemeeter compatible)

VBAN is VB-Audio's protocol for sending audio over a network as UDP packets. BananaSplit implements the VBAN audio protocol (specification revision 13), so it can exchange audio with Voicemeeter on a Windows PC, with VB-Audio's VBAN apps, and with other BananaSplit machines.

* **Incoming streams** (8): a stream is known by its **name** and its **sender's IP address**, as in Voicemeeter. Each one is added to the input of a strip you choose, before that strip's EQ, fader and routing, so it mixes like anything else on that strip. Names are compared without regard to case. BananaSplit accepts every VBAN sample rate up to four times its own (for example up to 192 kHz at 48 kHz), 8-, 16-, 24- and 32-bit PCM and 32/64-bit float, and any number of channels (channels 1 and 2 are used; a mono stream plays on both sides).
* **Outgoing streams** (8): each sends one of the 11 channels (a strip after its fader, or a bus) to an IPv4 address and port, at BananaSplit's sample rate, as 16-, 24- or 32-bit PCM or 32-bit float, stereo or mono. A broadcast address such as `192.168.1.255` sends to every computer on the network.
* **One UDP port** (6980 by default, the same as Voicemeeter) receives every incoming stream and sends every outgoing one, so packets leave from port 6980 like Voicemeeter's do. VBAN is **off** by default; while it is off, BananaSplit does not listen. A stream BananaSplit sends that comes back to it (sent to its own address or to a broadcast address) is ignored, so it cannot feed back into itself.
* **Clock drift and jitter:** two computers' audio clocks never run at exactly the same speed, and networks (Wi-Fi especially) deliver packets in bursts. For each incoming stream BananaSplit measures the sender's clock against its own and follows it by resampling (high-quality windowed sinc). The speed changes glide and stay tiny: the clock difference itself (usually a few tens of ppm) plus at most 0.05 % to keep the buffer at its level, far below what anyone can hear. BananaSplit keeps a reserve of audio for late packets, `buffer_ms` (10 ms by default) at the buffer's lowest point, on top of what the sender's packet timing needs; the latency shown next to the stream includes all of it. If the audio still drops out (a network hiccup longer than the reserve), BananaSplit fades out, waits until it holds enough to ride out the same hiccup again, and fades back in. It also adds 5 ms to the reserve (up to 200 ms, given back 1 ms per 30 s without dropouts), and trims the extra delay of the restart back slowly, about half a millisecond per second. A lost packet becomes a short silence of the same length, so the stream does not shift.
* **Real-time safe:** the audio callback only reads and writes preallocated lock-free buffers; the network work is done by two separate threads (see `tests/eq_vban_no_alloc.rs`).

### With Voicemeeter

1. On the Linux computer, switch VBAN on: `v` in the terminal UI, the switch in the GUI's VBAN window, or `enabled = true` under `[vban]`. Find its IP address with `ip -4 addr`.
2. Open UDP port 6980 in the Linux firewall if it has one: `sudo ufw allow 6980/udp` (Ubuntu) or `sudo firewall-cmd --add-port=6980/udp --permanent && sudo firewall-cmd --reload` (Fedora). Windows asks whether to allow Voicemeeter through its firewall the first time; allow it on private networks.
3. **Voicemeeter → BananaSplit:** in Voicemeeter's VBAN window, set up an outgoing stream to the Linux computer's IP, port 6980, with a name such as `Stream1`, and switch VBAN on there. 16- or 24-bit PCM works well. On BananaSplit, it then appears above the incoming streams in the GUI's VBAN window (click **Receive**), or add it to the config: `name = Stream1`, `from = <the Windows PC's IP>`, `strip = 6`.
4. **BananaSplit → Voicemeeter:** add an outgoing stream in BananaSplit with `to = <the Windows PC's IP>`, port 6980, and a name; in Voicemeeter, add an incoming stream with the same name and the Linux computer's IP as the source. 16-bit (the default) or 24-bit PCM works well. If Voicemeeter's side crackles over Wi-Fi, raise that incoming stream's Net Quality setting in Voicemeeter.

VBAN audio is not encrypted or authenticated, in Voicemeeter or here. BananaSplit only plays a stream whose name and sender IP match one you set up, so give incoming streams the sender's address rather than `any` on networks you don't trust.

## Configuration: `~/.config/bananasplit/bananasplit.ini`

Created with defaults on the first run (see `bananasplit --print-default-config`). Parsing is strict: a typo produces an error with a line number instead of being ignored.

```ini
[global]
client_name = BananaSplit
buffer_size = 128          # period requested from PipeWire (PIPEWIRE_LATENCY); 0 = don't ask
force_buffer_size = false  # true = jack_set_buffer_size() (JACK2: changes it for every client)
create_cables = true

[strip1]
name = Mic
gain_db = 0.0              # -60 .. +12
mono = true
routes = B1                # any of A1,A2,A3,B1,B2 or none
connect = @default         # the default microphone; may be repeated

[strip2]
connect = ^Firefox:output_F[LR]$   # or any JACK port regex

[bus.A1]
name = Speakers
connect = @default         # the default output device
[bus.A2]
connect = ^Yeti Stereo Microphone Analog Stereo-63:   # from `bananasplit --list-ports`

[strip3]
eq = on                    # this channel's EQ: on | off (default off)
eq1 = lowcut 80 +0 0.71    # band 1-6: type freq gain Q [off]
eq4 = bell 3000 -4.5 2     # bands left out keep their defaults

[recorder]
folder = ~/Music/BananaSplit
format = wav24             # wav16 | wav24 | wav32f
mode = mix                 # mix (one stereo file) | multi (one file per linked channel)
links = 1,A1               # 1-6 = strips, A1-A3 / B1-B2 = buses, or none

[vban]
enabled = true             # default false: nothing listens
port = 6980                # UDP; receives every incoming stream, sends every outgoing one

[vban.in1]                 # incoming streams: [vban.in1] .. [vban.in8]
on = true
name = Stream1             # the sender's stream name (case does not matter)
from = 192.168.1.20        # the sender's IPv4 address, or any
strip = 6                  # added to this strip's input (1-6)
buffer_ms = 10             # reserve for late packets (0-200; raised by itself after dropouts)

[vban.out1]                # outgoing streams: [vban.out1] .. [vban.out8]
on = true
name = Linux
to = 192.168.1.20          # the receiver's IPv4 address (x.x.x.255 = broadcast)
port = 6980
source = B1                # 1-6 = a strip after its fader, A1-A3 / B1-B2 = a bus
format = int16             # int16 | int24 | int32 | float32
channels = 2               # 2 (stereo) | 1 (mono: (L+R)/2)
```

EQ types are `bell`, `lowshelf`, `highshelf`, `lowcut`, `highcut` and `notch`; the frequency is 20–20000 Hz, the gain −24 to +24 dB (ignored by the cuts and the notch) and Q 0.1–30. BananaSplit writes only the bands and streams that differ from the defaults.

A config file from an earlier BananaSplit (without `[recorder]`, EQ or `[vban]`) still loads; the recorder then starts with the defaults above, linked to A1 only, every EQ is off, and VBAN is off.

### Choosing devices

| `connect =`  | strip (takes audio from)                       | bus (sends audio to)              |
|--------------|-------------------------------------------------|-----------------------------------|
| `@default`   | the default input in your sound settings       | the default output                |
| `@physical`  | a physical capture device, the default if it is one, else the first JACK lists | a physical playback device, same rule |
| a regex      | the first two matching JACK ports → L, R       | same                              |

`@default` needs PipeWire and `pactl`. Without them, or when the default device is one of BananaSplit's own cables (for example if you made `BananaSplit-In3-Desktop` the default output), it falls back to `@physical` and says so. In that case put an explicit pattern on A1.

**Patterns match JACK names, not PipeWire node names.** PipeWire calls a device something like `alsa_input.usb-Blue_Microphones_Yeti-00.analog-stereo`, but its JACK layer names the ports after the description: `Yeti Stereo Microphone Analog Stereo:capture_FL`. A device's microphone and headphone sides often share a description, so one of them gets `-NN` appended. `bananasplit --list-ports` prints every name with a ready-made line:

```
For a strip, [strip1] … [strip6] (ports that send audio):
  Razer Kiyo Analog Stereo                capture_FL capture_FR
      physical · PipeWire node alsa_input.usb-Razer_Kiyo-02.analog-stereo
      connect = ^Razer Kiyo Analog Stereo:
  Yeti Stereo Microphone Analog Stereo    capture_FL capture_FR
      physical · default input · PipeWire node alsa_input.usb-Blue_Yeti-00.analog-stereo
      connect = ^Yeti Stereo Microphone Analog Stereo:
…
@default  → strips: "Yeti Stereo Microphone Analog Stereo"
          → buses:  "Yeti Stereo Microphone Analog Stereo-63"
```

When a pattern matches nothing, the message says why if it can: `that is the PipeWire node name; JACK calls this device "…": use connect = ^…:`, `names are case-sensitive: did you mean "…"?`, or that the matching ports point the wrong way. In `--headless` and `--gui` mode the ports that side could use are also listed on stderr.

When ports appear or disappear (hot-plugged headsets, apps starting), BananaSplit re-applies the configured connections automatically. It never removes connections, including ones you made yourself.

## Latency

`bananasplit --low-latency` writes `contrib/pipewire`'s two files (built into the binary) to `~/.config/pipewire/pipewire.conf.d/` and `pipewire-pulse.conf.d/`. It also applies the graph settings to the running PipeWire with `pw-metadata`, so 128-frame periods start immediately, without a restart. The smaller default buffers for browsers and Discord apply the next time pipewire-pulse starts (`systemctl --user restart pipewire pipewire-pulse wireplumber`, which briefly interrupts all audio). A file you have changed is never overwritten. `bananasplit --low-latency off` removes the files again (only if they are unchanged) and drops the live settings.

About 1.5 s after starting, once JACK reports the latency of the connected devices, BananaSplit checks the round trip. If it is 10 ms or more, it prints one line saying what to do. In the terminal UI that line has its own row.

| Message | Meaning |
|---|---|
| `… (goal < 10 ms): run bananasplit --low-latency` | The low-latency settings are not installed. |
| `1024-frame periods despite the low-latency config: restart PipeWire` | Installed but not active. |
| `… the sound card adds N ms (see README)` | The period is small already. The rest is the device's own buffering, typical for USB audio. You can lower it per device with a WirePlumber rule, see below. Test it, because some devices crackle with less headroom. |
| `…: start jackd with -p 128` | Plain JACK2, not PipeWire. |

Per-device ALSA buffering (WirePlumber 0.5), in `~/.config/wireplumber/wireplumber.conf.d/51-bananasplit-usb.conf`:

```
monitor.alsa.rules = [
  { matches = [ { node.name = "~alsa_.*usb-Blue.*" } ]
    actions = { update-props = { api.alsa.period-size = 128, api.alsa.headroom = 0 } } }
]
```

## If BananaSplit is killed

On a normal exit (`q`, the GUI's power button, Ctrl-C, `systemctl stop`) BananaSplit removes its eight cables, and PipeWire moves any app that was playing into them back to the default output. If BananaSplit is killed with SIGKILL or crashes, a small watchdog process it started (`bananasplit --reap-cables bananasplit` in `ps`) sees that BananaSplit is gone and removes the cables within a fraction of a second. If the watchdog was killed too, the next `bananasplit` start removes the leftovers, or you can run `bananasplit --cleanup` now. `--cleanup` refuses while that BananaSplit is still running. The systemd unit runs `bananasplit --cleanup` as `ExecStopPost`. All of these match cables by their exact names, so nothing else is touched.

## Tests

```sh
cargo test                       # 111 unit tests + 3 "audio path never allocates" tests
tests/e2e/run_e2e.sh             # runs the real binary against a mock libjack (needs gcc, curl and python3)
```

The end-to-end test drives BananaSplit's real process callback through a mock JACK server. It checks that impulses fed to two different strips come out on A1 and B1 at the **exact same frame and cycle** they went in, with the correct mix values. It also checks that every output buffer is fully written each cycle, that 8 cables are created, wired and removed, that a stale cable from a crash is cleaned up, and that SIGINT/SIGTERM shut down cleanly. A third phase starts `bananasplit --gui`, drives it over HTTP exactly like the page does (including the security checks and a second `--gui` launch), records strip 1 and A1 in multi mode, and checks that both WAV files hold the impulse on the **same sample** with the correct values.

A fourth phase covers the 2.3 fixes on a mock of the reviewed setup: a webcam listed before a USB mic, the mic's headphone side named `…-63`, and a 17.3 ms round trip. It checks that:

* `--no-cables` leaves `create_cables = true` in the saved config;
* `@physical` and `@default` take the mic, not the webcam, and never a monitor port;
* each kind of pattern miss gets the right hint, and the available ports are listed;
* the latency advice appears;
* `--list-ports` prints the right lines;
* `--low-latency` installs, applies and undoes;
* after `kill -9` the watchdog removes all 8 cables and nothing else;
* `--cleanup` refuses while BananaSplit runs and sweeps afterwards.

The GUI phase also sets an EQ and VBAN streams over HTTP, checks that bad values are refused, and that everything is saved. A fifth phase tests VBAN and the EQ with a VBAN peer written separately, from VB-Audio's specification only (`tests/e2e/vban_peer.py`, Python standard library). The peer plays Voicemeeter: it sends a 1 kHz sine at 44.1 kHz, 24-bit, in bursts of 512 samples, mixed with packets BananaSplit must ignore (VBAN-TEXT, an unknown stream name, a wrong size, a truncated header). BananaSplit adds it to strip 4, whose EQ boosts 1 kHz by 6 dB, and sends strip 4 back at 48 kHz, 16-bit, while the mock JACK server runs in real time. The peer checks every header field, the frame counter, the source port, and that the audio is a clean 1 kHz sine at the expected level in every 100 ms (no dropout or glitch), with left and right in the right order.

Unit tests also cover the VBAN header against the specification (every sample rate and format, every rejection rule, random garbage), the resampler (44.1 ↔ 48 kHz, 8 to 192 kHz, aliasing below −85 dB), the drift tracking (simulated senders whose clocks run up to 2000 ppm off, with jitter, lost packets, stalls and pauses), two VBAN instances talking over real sockets, the EQ against the Audio EQ Cookbook formulas at three sample rates, and the EQ's click-free changes.

The no-allocation tests run thousands of cycles with parameters changing underneath: one with the recorder recording (both modes, live link changes, a full buffer), one with every EQ changing and VBAN streams flowing both ways (underruns, a full outgoing buffer, flushes). A counting allocator proves the audio path never touches the heap.

## Limitations

* Not included from Voicemeeter: Intellipan, the compressor/gate, playback of recordings, and VBAN's other parts: remote control (VBAN-TEXT), MIDI/serial, the service ping that lists VBAN devices, and the VB-Audio codecs (VBCA/VBCV). BananaSplit sends and receives uncompressed PCM audio only, the format Voicemeeter uses by default.
* VBAN uses IPv4 only. An incoming stream may have at most four times BananaSplit's sample rate.
* VBAN and the EQ were tested against a VBAN implementation written from the specification, not against Voicemeeter itself. Check a stream in both directions on your own network before relying on it live.
* The GUI page needs a current browser (Chromium/Chrome 111+, Firefox 113+); the app-window mode needs a Chromium-based one.
* **App-side buffering is not under any mixer's control.** PulseAudio-API apps (browsers, Discord) choose their own buffer sizes. The `pipewire-pulse` snippet lowers the default, but an app that asks for 40 ms gets 40 ms. Native PipeWire and JACK apps follow the graph quantum.
* With **two different sound cards** on A1/A2, PipeWire clocks one and adaptively resamples the other, which is the correct way to handle two clock domains. Plain JACK2 can only drive one card.
* The 2.3 changes were tested against a mock JACK server and a fake `pactl`/`pw-metadata` that print what PipeWire prints. Check `bananasplit --list-ports` and `bananasplit --low-latency` on your own machine before relying on them live.
