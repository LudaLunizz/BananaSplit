/* Mock libjack.so.0 for end-to-end testing of the vmix binary without an
 * audio server. It plays the role of the JACK server: owns port buffers,
 * performs connections, runs the client's process callback in a separate
 * thread and checks what comes out. Results go to $MOCKJACK_REPORT. */
#include <errno.h>
#include <pthread.h>
#include <regex.h>
#include <stdarg.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#define NF 128
#define MAXP 64
#define MAXC 256
typedef int (*proc_cb)(uint32_t, void *);
typedef int (*xrun_cb)(void *);
typedef void (*preg_cb)(uint32_t, int, void *);
typedef void (*shut_cb)(void *);

typedef struct { char name[128]; unsigned long flags; float buf[NF]; int ours; } port_t;
static port_t ports[MAXP];
static int nports;
static struct { int src, dst; } conns[MAXC];
static int nconns;
static proc_cb pcb; static void *parg;
static xrun_cb xcb; static void *xarg;
static preg_cb rcb; static void *rarg;
static char cname[64];
static pthread_t th;
static volatile int running;
static pthread_mutex_t mu = PTHREAD_MUTEX_INITIALIZER;

static int add_port(const char *full, unsigned long flags, int ours) {
  snprintf(ports[nports].name, sizeof ports[nports].name, "%s", full);
  ports[nports].flags = flags; ports[nports].ours = ours;
  return nports++;
}
static int find(const char *n) { for (int i = 0; i < nports; i++) if (!strcmp(ports[i].name, n)) return i; return -1; }

void *jack_client_open(const char *name, int opts, int *status, ...) {
  (void)opts; strncpy(cname, name, 63); if (status) *status = 0;
  /* external ports: physical capture (outputs), physical playback (inputs), an app */
  add_port("Speakers:monitor_FL", 0x2 | 0x4, 0); add_port("Speakers:monitor_FR", 0x2 | 0x4, 0);
  add_port("system:capture_1", 0x2 | 0x4, 0); add_port("system:capture_2", 0x2 | 0x4, 0);
  add_port("system:playback_1", 0x1 | 0x4, 0); add_port("system:playback_2", 0x1 | 0x4, 0);
  add_port("Firefox:output_FL", 0x2, 0); add_port("Firefox:output_FR", 0x2, 0);
  add_port("OBS:input_1", 0x1, 0);
  if (getenv("MOCKJACK_CABLES")) { /* what PipeWire's JACK layer shows for vmix's cables */
    const char *in[6] = {"vmix-In1-Mic","vmix-In2-Discord","vmix-In3-Desktop","vmix-In4-Game","vmix-In5-Music","vmix-In6-Aux"};
    char b[128];
    for (int i = 0; i < 6; i++) {
      snprintf(b, sizeof b, "%s:playback_FL", in[i]); add_port(b, 0x1, 0);
      snprintf(b, sizeof b, "%s:playback_FR", in[i]); add_port(b, 0x1, 0);
      snprintf(b, sizeof b, "%s:monitor_FL", in[i]);  add_port(b, 0x2, 0);
      snprintf(b, sizeof b, "%s:monitor_FR", in[i]);  add_port(b, 0x2, 0);
    }
    add_port("vmix-Out-B1:input_FL", 0x1, 0); add_port("vmix-Out-B1:input_FR", 0x1, 0);
    add_port("vmix-Out-B1:capture_FL", 0x2, 0); add_port("vmix-Out-B1:capture_FR", 0x2, 0);
    add_port("vmix-Out-B2:input_FL", 0x1, 0); add_port("vmix-Out-B2:input_FR", 0x1, 0);
  }
  return (void *)1;
}
int jack_client_close(void *c) { (void)c; running = 0; if (th) pthread_join(th, NULL); th = 0; return 0; }
const char *jack_get_client_name(void *c) { (void)c; return cname; }
int jack_set_process_callback(void *c, proc_cb f, void *a) { (void)c; pcb = f; parg = a; return 0; }
int jack_set_xrun_callback(void *c, xrun_cb f, void *a) { (void)c; xcb = f; xarg = a; return 0; }
int jack_set_port_registration_callback(void *c, preg_cb f, void *a) { (void)c; rcb = f; rarg = a; return 0; }
void jack_on_shutdown(void *c, shut_cb f, void *a) { (void)c; (void)f; (void)a; }
void *jack_port_register(void *c, const char *s, const char *t, unsigned long fl, unsigned long b) {
  (void)c; (void)b;
  if (strcmp(t, "32 bit float mono audio")) return NULL;
  char full[128]; snprintf(full, sizeof full, "%s:%s", cname, s);
  return &ports[add_port(full, fl, 1)];
}
void *jack_port_get_buffer(void *p, uint32_t n) { (void)n; return ((port_t *)p)->buf; }
const char *jack_port_name(void *p) { return ((port_t *)p)->name; }
typedef struct { uint32_t min, max; } lr_t;
void jack_port_get_latency_range(void *p, int mode, lr_t *r) { (void)p; r->min = r->max = mode == 0 ? NF : 2 * NF; }
int jack_connect(void *c, const char *a, const char *b) {
  (void)c; pthread_mutex_lock(&mu);
  int s = find(a), d = find(b), rc = 0;
  if (s < 0 || d < 0 || !(ports[s].flags & 2) || !(ports[d].flags & 1)) rc = EINVAL;
  else {
    for (int i = 0; i < nconns; i++) if (conns[i].src == s && conns[i].dst == d) rc = EEXIST;
    if (!rc) { conns[nconns].src = s; conns[nconns].dst = d; nconns++; }
  }
  pthread_mutex_unlock(&mu); return rc;
}
const char **jack_get_ports(void *c, const char *pat, const char *type, unsigned long flags) {
  (void)c; (void)type; regex_t re; int use = pat && *pat;
  if (use && regcomp(&re, pat, REG_EXTENDED | REG_NOSUB)) return NULL;
  const char **out = calloc(MAXP + 1, sizeof *out); int k = 0;
  for (int i = 0; i < nports; i++) {
    if ((ports[i].flags & flags) != flags) continue;
    if (use && regexec(&re, ports[i].name, 0, NULL, 0)) continue;
    out[k++] = ports[i].name;
  }
  if (use) regfree(&re);
  if (!k) { free(out); return NULL; }
  return out;
}
void jack_free(void *p) { free(p); }
uint32_t jack_get_sample_rate(void *c) { (void)c; return 48000; }
uint32_t jack_get_buffer_size(void *c) { (void)c; return NF; }
int jack_set_buffer_size(void *c, uint32_t n) { (void)c; (void)n; return 0; }
float jack_cpu_load(void *c) { (void)c; return 1.0f; }
int jack_deactivate(void *c) { (void)c; running = 0; if (th) pthread_join(th, NULL); th = 0; return 0; }

/* ---- the "server" --------------------------------------------------- */
static float ext_signal(const char *name, int cyc, int i) {
  /* every port fires a distinct impulse at cycle 30, frame 77 */
  if (cyc != 500 || i != 77) return 0.0f;
  if (!strcmp(name, "system:capture_1")) return 0.5f;
  if (!strcmp(name, "system:capture_2")) return 0.25f;
  if (!strcmp(name, "Firefox:output_FL")) return 0.125f;
  if (!strcmp(name, "Firefox:output_FR")) return 0.0625f;
  return 0.0f;
}

static void *server(void *u) {
  (void)u; FILE *rep = fopen(getenv("MOCKJACK_REPORT"), "w");
  int hits = 0, cycles = 0;
  for (int cyc = 0; running && cyc < 2000; cyc++) {
    pthread_mutex_lock(&mu);
    for (int i = 0; i < nports; i++) {
      if (ports[i].ours && (ports[i].flags & 1)) {          /* our inputs: sum of sources */
        memset(ports[i].buf, 0, sizeof ports[i].buf);
        for (int c = 0; c < nconns; c++) if (conns[c].dst == i)
          for (int f = 0; f < NF; f++) ports[i].buf[f] += ext_signal(ports[conns[c].src].name, cyc, f);
      }
      if (ports[i].ours && (ports[i].flags & 2)) for (int f = 0; f < NF; f++) ports[i].buf[f] = 999.0f; /* garbage */
    }
    pthread_mutex_unlock(&mu);
    pcb(NF, parg);
    cycles++;
    if (cyc == 5 && xcb) xcb(xarg);
    if (cyc == 10 && rcb) rcb(0, 1, rarg);
    /* inspect what reached system:playback_1/2 and OBS:input_1 */
    pthread_mutex_lock(&mu);
    for (int c = 0; c < nconns; c++) {
      port_t *s = &ports[conns[c].src], *d = &ports[conns[c].dst];
      if (!s->ours) continue;
      for (int f = 0; f < NF; f++) {
        float v = s->buf[f];
        if (v == 999.0f) { fprintf(rep, "GARBAGE %s\n", s->name); break; }
        if (v != 0.0f && cyc > 3) { fprintf(rep, "SIGNAL cycle=%d frame=%d %s -> %s value=%.6f\n", cyc, f, s->name, d->name, v); hits++; }
      }
    }
    pthread_mutex_unlock(&mu);
    usleep(2000);
  }
  for (int c = 0; c < nconns; c++) fprintf(rep, "CONN %s -> %s\n", ports[conns[c].src].name, ports[conns[c].dst].name);
  fprintf(rep, "CYCLES %d HITS %d\n", cycles, hits);
  fclose(rep);
  return NULL;
}

int jack_activate(void *c) {
  (void)c; running = 1; usleep(300000); /* let vmix auto-connect first */
  return pthread_create(&th, NULL, server, NULL);
}
