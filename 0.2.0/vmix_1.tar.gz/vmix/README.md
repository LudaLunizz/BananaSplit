# vmix: a 6-strip virtual audio mixer for Linux

A Voicemeeter Banana-style mixer written in Rust, with **6 input strips**, **3 hardware buses (A1–A3)**, **2 virtual buses (B1–B2)**, and **one virtual cable per strip**. It runs as a single real-time JACK client, natively on JACK2 or on PipeWire's JACK layer.

```
 VMIX  6 strips · 5 buses · JACK client "vmix" · 8 cables
 48000 Hz  128 frames  period 2.67 ms  round-trip 6.10 ms [<10 ms OK]  DSP 1.2%  xruns 0

  #  NAME         GAIN   L            R             PEAK  M S O  A1 A2 A3 B1 B2
> 1  Mic           +0.0  ███████····· ███████·····    -24  · · O  A1 A2 A3 B1 B2
  2  Discord       -7.4  █████······· █████·······    -31  · · ·  A1 A2 A3 B1 B2
  ...
```

## ASIO / WASAPI on Linux

ASIO and WASAPI are **Windows-only** driver APIs and do not exist on Linux. What they give you on Windows (exclusive device access, no OS mixer or resampler in the path, small fixed buffers, and one callback that sees every channel at once) is what **JACK** provides on Linux. PipeWire implements the same API.

| Windows                       | vmix on Linux                                                       |
|-------------------------------|---------------------------------------------------------------------|
| ASIO driver                   | JACK2 server, or PipeWire + `pipewire-jack`                         |
| WASAPI exclusive mode         | Device opened only by JACK/PipeWire at a fixed rate and quantum     |
| VB-Cable / "Voicemeeter Input"| `vmix-In1…6` virtual output devices (PipeWire sinks)                |
| "Voicemeeter Output" (B1/B2)  | `vmix-Out-B1`, `vmix-Out-B2` virtual microphones                    |
| Voicemeeter Banana            | `vmix`                                                              |

## Sync and latency

* **Sample-synchronous by design.** The whole mixer (all 12 input channels and 10 output channels) is computed inside **one** JACK process callback for the same block of frames. A sample entering any strip at frame *k* leaves every bus at frame *k* of the same cycle. The mixer itself adds **0 samples** of latency.
* **Virtual cables add no buffering.** They are nodes in the same PipeWire graph, driven by the same clock, and processed in the same cycle.
* **Sub-10 ms** depends on the server's period. Use 48 kHz with 128 frames: 2.67 ms per period, which gives about 6–8 ms hardware round-trip including driver headroom. Install `contrib/pipewire/pipewire.conf.d/10-vmix-lowlatency.conf` to pin this (with `max-quantum = 128`, no other app can raise it). The UI shows the measured round-trip from JACK's latency API and turns red if it reaches 10 ms or more.
* **Real-time safe.** The audio callback does no allocation, no locks, no syscalls, and cannot panic. Every gain, mute, solo, or routing change is ramped over one period, so changes don't click.

## Install

Requirements (PipeWire, the default on current Fedora, Ubuntu, Debian, Arch, and others):

| Distro         | Packages                                                     |
|----------------|--------------------------------------------------------------|
| Fedora         | `pipewire-jack-audio-connection-kit pulseaudio-utils`        |
| Arch           | `pipewire-jack libpulse`                                     |
| Debian/Ubuntu  | `pipewire-jack pulseaudio-utils`                             |

Or JACK2 (`jackd2`). The virtual cables need PipeWire; without it, use `--no-cables` and route with JACK.

```sh
cargo build --release            # zero dependencies
install -Dm755 target/release/vmix ~/.local/bin/vmix

# optional but recommended for guaranteed < 10 ms:
mkdir -p ~/.config/pipewire/pipewire.conf.d ~/.config/pipewire/pipewire-pulse.conf.d
cp contrib/pipewire/pipewire.conf.d/*.conf       ~/.config/pipewire/pipewire.conf.d/
cp contrib/pipewire/pipewire-pulse.conf.d/*.conf ~/.config/pipewire/pipewire-pulse.conf.d/
systemctl --user restart pipewire pipewire-pulse wireplumber
```

Run it with `vmix`. On **Debian/Ubuntu**, run `pw-jack vmix` so it uses PipeWire's libjack instead of JACK2's. To run it in the background, use `contrib/systemd/vmix.service`, which runs `vmix --headless`.

## Using it

1. Start `vmix`. Eight devices appear in your sound settings: `vmix-In1-Mic` … `vmix-In6-Aux` (outputs) and `vmix-Out-B1`, `vmix-Out-B2` (microphones).
2. Point applications at a strip by setting their output device (pavucontrol, GNOME/KDE settings, or the app itself), for example Discord to `vmix-In2-Discord`. To send the whole desktop through vmix, make `vmix-In3-Desktop` the default output.
3. Choose where each strip goes with keys `1`–`5` (A1 A2 A3 B1 B2).
4. In Discord or OBS, select **`vmix-Out-B1`** as the microphone to receive the B1 mix.
5. Press `w` to save. The mixer state is also saved automatically on quit.

Keys: `↑↓` select · `←→` gain ±1 dB · `,` `.` ±0.1 dB · `0` 0 dB · `m` mute · `s` solo · `o` mono · `1-5` route · `r` reconnect · `w` save · `q` quit

## Configuration: `~/.config/vmix/vmix.ini`

Created with defaults on the first run (see `vmix --print-default-config`). Parsing is strict: a typo produces an error with a line number instead of being ignored.

```ini
[global]
client_name = vmix
buffer_size = 128          # period requested from PipeWire (PIPEWIRE_LATENCY); 0 = don't ask
force_buffer_size = false  # true = jack_set_buffer_size() (JACK2: changes it for every client)
create_cables = true

[strip1]
name = Mic
gain_db = 0.0              # -60 .. +12
mono = true
routes = B1                # any of A1,A2,A3,B1,B2 or none
connect = @physical        # physical capture device; may be repeated

[strip2]
connect = ^Firefox:output_F[LR]$   # or any JACK port regex

[bus.A1]
name = Speakers
connect = @physical        # physical playback device
[bus.A2]
connect = ^Headphones-description:playback_F[LR]$
```

`@physical` picks the **first** physical device that JACK lists. With several sound cards, put an explicit regex in `connect`. You can see the exact port names in `qpwgraph`, `pw-link -io`, or `jack_lsp`. When ports appear or disappear (hot-plugged headsets, apps starting), vmix re-applies the configured connections automatically. It never removes connections you made yourself.

## Tests

```sh
cargo test                       # 27 unit tests + "audio path never allocates" test
tests/e2e/run_e2e.sh             # runs the real binary against a mock libjack
```

The end-to-end test drives vmix's real process callback through a mock JACK server. It checks that impulses fed to two different strips come out on A1 and B1 at the **exact same frame and cycle** they went in, with the correct mix values. It also checks that every output buffer is fully written each cycle, that 8 cables are created, wired and removed, that a stale cable from a crash is cleaned up, and that SIGINT/SIGTERM shut down cleanly.

## Limitations

* Not included from Voicemeeter: EQ, VBAN network streaming, recorder, Intellipan, and the compressor/gate.
* **App-side buffering is not under any mixer's control.** PulseAudio-API apps (browsers, Discord) choose their own buffer sizes. The `pipewire-pulse` snippet lowers the default, but an app that asks for 40 ms gets 40 ms. Native PipeWire and JACK apps follow the graph quantum.
* With **two different sound cards** on A1/A2, PipeWire clocks one and adaptively resamples the other, which is the correct way to handle two clock domains. Plain JACK2 can only drive one card.
* The mixer and cables were tested against a mock server. Test them on your own hardware before relying on them live.
