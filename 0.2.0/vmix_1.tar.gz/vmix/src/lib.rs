//! vmix — a 6-strip / 5-bus virtual audio mixer for Linux.
//!
//! The crate is split so that everything that touches audio samples
//! (`engine`) and everything that touches persistent state (`config`) is
//! plain, dependency-free Rust that can be unit-tested without an audio
//! server. The binary (`main.rs`) adds the JACK backend, PipeWire virtual
//! cables and the terminal UI.

pub mod config;
pub mod engine;
