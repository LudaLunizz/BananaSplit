//! vmix — 6-strip / 5-bus virtual audio mixer for Linux (JACK / PipeWire).

mod backend;
mod cables;
mod jack;
mod sys;
mod tui;

use backend::Backend;
use cables::{CableSet, Cables};
use std::io::{Read, Write};
use std::path::PathBuf;
use std::process::ExitCode;
use std::sync::atomic::Ordering::{Relaxed, SeqCst};
use std::sync::mpsc;
use std::time::{Duration, Instant};
use vmix::config::Config;
use vmix::engine::Shared;

const HELP: &str = "\
vmix — 6-strip, 5-bus low-latency virtual audio mixer (JACK / PipeWire)

USAGE:
    vmix [--config FILE] [--headless] [--no-cables]
    vmix --print-default-config

OPTIONS:
    -c, --config FILE        Config file (default: $XDG_CONFIG_HOME/vmix/vmix.ini)
        --headless           No UI; run until SIGINT/SIGTERM (for systemd)
        --no-cables          Do not create PipeWire virtual cables
        --print-default-config
    -h, --help
    -V, --version
";

struct Args {
    config: PathBuf,
    headless: bool,
    no_cables: bool,
}

fn parse_args() -> Result<Option<Args>, String> {
    let mut a = Args { config: Config::default_path(), headless: false, no_cables: false };
    let mut it = std::env::args().skip(1);
    while let Some(arg) = it.next() {
        match arg.as_str() {
            "-c" | "--config" => a.config = it.next().ok_or("--config needs a file")?.into(),
            "--headless" => a.headless = true,
            "--no-cables" => a.no_cables = true,
            "--print-default-config" => {
                print!("{}", Config::default().to_ini());
                return Ok(None);
            }
            "-h" | "--help" => {
                print!("{HELP}");
                return Ok(None);
            }
            "-V" | "--version" => {
                println!("vmix {}", env!("CARGO_PKG_VERSION"));
                return Ok(None);
            }
            other => return Err(format!("unknown argument {other:?} (see --help)")),
        }
    }
    Ok(Some(a))
}

fn main() -> ExitCode {
    match run() {
        Ok(()) => ExitCode::SUCCESS,
        Err(e) => {
            eprintln!("vmix: {e}");
            ExitCode::FAILURE
        }
    }
}

fn run() -> Result<(), String> {
    let Some(args) = parse_args()? else { return Ok(()) };
    let mut cfg = Config::load_or_create(&args.config)?;
    if args.no_cables {
        cfg.create_cables = false;
    }
    if !args.headless && !sys::stdin_is_tty() {
        return Err("not running in a terminal; use --headless".into());
    }
    sys::install_signal_handlers();

    // Ask PipeWire for a small period for our node (honoured as long as it is
    // within the server's min/max quantum). Harmless under JACK2.
    if cfg.buffer_size > 0 && std::env::var_os("PIPEWIRE_LATENCY").is_none() {
        // SAFETY: still single-threaded at this point.
        unsafe { std::env::set_var("PIPEWIRE_LATENCY", format!("{}/48000", cfg.buffer_size)) };
    }

    let client = jack::JackClient::open(&cfg.client_name)?;
    let mut notes: Vec<String> = Vec::new();
    if cfg.force_buffer_size && cfg.buffer_size > 0 && client.buffer_size() != cfg.buffer_size {
        if let Err(e) = client.set_buffer_size(cfg.buffer_size) {
            notes.push(e);
        }
    }

    // Cables before ports so they exist when we auto-connect.
    let cable_set = CableSet::for_config(&cfg);
    let (cables, warn) = if cfg.create_cables { Cables::create(&cable_set) } else { (Cables::none(), Vec::new()) };
    notes.extend(warn);
    let cables_active = cables.count() > 0;

    let shared = Shared::new();
    cfg.apply(&shared);
    let backend = Backend::start(client, shared.clone())?;

    // Give PipeWire a moment to publish the cable ports.
    if cables_active {
        let deadline = Instant::now() + Duration::from_secs(3);
        while Instant::now() < deadline {
            let all = cable_set.all().all(|c| !backend.client().ports(Some(&c.jack_regex()), 0).is_empty());
            if all {
                break;
            }
            std::thread::sleep(Duration::from_millis(50));
        }
    }

    let set_ref = if cables_active { Some(&cable_set) } else { None };
    let result = if args.headless {
        run_headless(&backend, &cfg, set_ref, notes)
    } else {
        run_tui(&backend, &mut cfg, &args.config, set_ref, &shared, cables.count(), notes)
    };
    drop(backend); // close JACK first...
    drop(cables); // ...then remove the cables
    result
}

fn run_headless(backend: &Backend, cfg: &Config, set: Option<&CableSet>, notes: Vec<String>) -> Result<(), String> {
    for n in notes {
        eprintln!("vmix: warning: {n}");
    }
    let c = backend.client();
    eprintln!(
        "vmix: running as JACK client \"{}\" at {} Hz, {} frames ({:.2} ms period). Ctrl-C to stop.",
        backend.client_name,
        c.sample_rate(),
        c.buffer_size(),
        c.buffer_size() as f64 * 1000.0 / c.sample_rate().max(1) as f64
    );
    let mut last_errs: Vec<String> = Vec::new();
    let mut changed_at: Option<Instant> = Some(Instant::now());
    while !sys::QUIT.load(SeqCst) {
        if backend.ctl.shutdown.load(Relaxed) {
            return Err("the JACK/PipeWire server shut down".into());
        }
        if backend.ctl.ports_changed.swap(false, Relaxed) {
            changed_at = Some(Instant::now());
        }
        if changed_at.is_some_and(|t| t.elapsed() > Duration::from_millis(250)) {
            changed_at = None;
            let (_, errs) = backend.autoconnect(cfg, set);
            if errs != last_errs {
                for e in &errs {
                    eprintln!("vmix: {e}");
                }
                last_errs = errs;
            }
        }
        std::thread::sleep(Duration::from_millis(50));
    }
    Ok(())
}

fn run_tui(
    backend: &Backend,
    cfg: &mut Config,
    path: &std::path::Path,
    set: Option<&CableSet>,
    shared: &Shared,
    cable_count: usize,
    notes: Vec<String>,
) -> Result<(), String> {
    let _term = sys::RawTerminal::enter()?;

    let (tx, rx) = mpsc::channel::<Vec<u8>>();
    std::thread::spawn(move || {
        let mut stdin = std::io::stdin();
        let mut buf = [0u8; 64];
        loop {
            match stdin.read(&mut buf) {
                Ok(0) | Err(_) => break,
                Ok(n) => {
                    if tx.send(buf[..n].to_vec()).is_err() {
                        break;
                    }
                }
            }
        }
    });

    let mut view = tui::View::default();
    if !notes.is_empty() {
        view.status = format!("\x1b[33m{}\x1b[0m", notes.join(" | "));
    }
    let mut pending = Vec::new();
    let mut conn: Vec<String> = Vec::new();
    let mut changed_at: Option<Instant> = Some(Instant::now());
    let mut force_connect = false;
    let mut lat = (0u32, 0u32);
    let mut lat_at = Instant::now() - Duration::from_secs(10);
    let mut out = std::io::stdout();
    let frame = Duration::from_millis(33);

    loop {
        let t0 = Instant::now();
        if sys::QUIT.load(SeqCst) {
            break;
        }
        if backend.ctl.shutdown.load(Relaxed) {
            return Err("the JACK/PipeWire server shut down".into());
        }

        while let Ok(bytes) = rx.try_recv() {
            pending.extend_from_slice(&bytes);
        }
        let mut quit = false;
        for k in tui::decode(&mut pending) {
            match view.handle(shared, k) {
                tui::Action::None => {}
                tui::Action::Quit => quit = true,
                tui::Action::Reconnect => force_connect = true,
                tui::Action::Save => {
                    cfg.capture(shared);
                    view.status = match cfg.save(path) {
                        Ok(()) => format!("saved {}", path.display()),
                        Err(e) => format!("\x1b[31msave failed: {e}\x1b[0m"),
                    };
                }
            }
        }
        if quit {
            break;
        }

        if backend.ctl.ports_changed.swap(false, Relaxed) {
            changed_at = Some(Instant::now());
        }
        if force_connect || changed_at.is_some_and(|t| t.elapsed() > Duration::from_millis(250)) {
            let (d, errs) = backend.autoconnect(cfg, set);
            conn = d;
            if force_connect || !errs.is_empty() {
                view.status = if errs.is_empty() {
                    "all configured connections made".into()
                } else {
                    format!("\x1b[33m{}\x1b[0m", errs.join(" | "))
                };
            }
            force_connect = false;
            changed_at = None;
            lat_at = Instant::now() - Duration::from_secs(10); // refresh latency now
        }
        if lat_at.elapsed() > Duration::from_millis(500) {
            lat = backend.io_latency();
            lat_at = Instant::now();
        }

        view.update_meters(shared);
        let c = backend.client();
        let info = tui::Info {
            client: &backend.client_name,
            sample_rate: c.sample_rate(),
            buffer_size: c.buffer_size(),
            cpu: c.cpu_load(),
            xruns: shared.xruns.load(Relaxed),
            oversize: shared.oversize_cycles.load(Relaxed),
            lat_in: lat.0,
            lat_out: lat.1,
            cables: cable_count,
        };
        let screen = view.render(shared, cfg, &info, &conn);
        let _ = out.write_all(screen.as_bytes());
        let _ = out.flush();

        if let Some(rest) = frame.checked_sub(t0.elapsed()) {
            std::thread::sleep(rest);
        }
    }

    // Remember the mixer state for next time.
    cfg.capture(shared);
    cfg.save(path)
}
