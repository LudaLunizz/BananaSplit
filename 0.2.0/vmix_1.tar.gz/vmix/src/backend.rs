//! JACK backend: ports, real-time callback, auto-connection.
//!
//! The whole mixer runs inside ONE JACK process callback. JACK (and
//! PipeWire's JACK layer) call it once per period for every port at once, so
//! all 12 input and 10 output channels are processed for the same frames in
//! the same cycle — inherently sample-synchronous, with no extra buffering.

#![allow(clippy::needless_range_loop)] // index loops mirror the [strip][channel] layout

use crate::cables::CableSet;
use crate::jack::{
    JackClient, LATENCY_CAPTURE, LATENCY_PLAYBACK, PORT_IS_INPUT, PORT_IS_OUTPUT, PORT_IS_PHYSICAL, Port,
};
use std::ffi::{c_int, c_ulong, c_void};
use std::sync::Arc;
use std::sync::atomic::{AtomicBool, Ordering::Relaxed};
use vmix::config::{Config, PHYSICAL};
use vmix::engine::{BUS_IDS, Engine, MAX_FRAMES, NUM_BUSES, NUM_PHYSICAL_BUSES, NUM_STRIPS, Shared};

struct RtCtx {
    lib: &'static crate::jack::Lib,
    engine: Engine,
    ins: [[Port; 2]; NUM_STRIPS],
    outs: [[Port; 2]; NUM_BUSES],
}

pub struct CtlCtx {
    pub shared: Arc<Shared>,
    pub ports_changed: AtomicBool,
    pub shutdown: AtomicBool,
}

unsafe extern "C" fn process_cb(nframes: u32, arg: *mut c_void) -> c_int {
    // SAFETY: `arg` is the RtCtx box owned by Backend, alive until the client
    // is closed; JACK never runs two process callbacks of one client at once.
    let ctx = unsafe { &mut *arg.cast::<RtCtx>() };
    let n = nframes as usize;
    let lib = ctx.lib;

    // 1) Copy inputs into the engine (before any output buffer is touched,
    //    so an input that aliases one of our outputs is still read correctly).
    for s in 0..NUM_STRIPS {
        for c in 0..2 {
            let p = unsafe { (lib.jack_port_get_buffer)(ctx.ins[s][c], nframes) }.cast::<f32>();
            if p.is_null() || n > MAX_FRAMES {
                ctx.engine.clear_input(s, c, n);
            } else {
                // SAFETY: JACK guarantees `nframes` valid samples.
                ctx.engine.load_input(s, c, unsafe { std::slice::from_raw_parts(p, n) });
            }
        }
    }

    // 2) Mix straight into the output port buffers.
    let mut ptrs = [[std::ptr::null_mut::<f32>(); 2]; NUM_BUSES];
    for b in 0..NUM_BUSES {
        for c in 0..2 {
            let p = unsafe { (lib.jack_port_get_buffer)(ctx.outs[b][c], nframes) }.cast::<f32>();
            if p.is_null() {
                return 0;
            }
            ptrs[b][c] = p;
        }
    }
    // SAFETY: ten distinct output ports => ten distinct, non-overlapping
    // buffers of `nframes` samples each.
    let mut outs: [[&mut [f32]; 2]; NUM_BUSES] =
        std::array::from_fn(|b| std::array::from_fn(|c| unsafe { std::slice::from_raw_parts_mut(ptrs[b][c], n) }));
    ctx.engine.process(&mut outs);
    0
}

unsafe extern "C" fn xrun_cb(arg: *mut c_void) -> c_int {
    let ctl = unsafe { &*arg.cast::<CtlCtx>() };
    ctl.shared.xruns.fetch_add(1, Relaxed);
    0
}

unsafe extern "C" fn port_reg_cb(_port: u32, _register: c_int, arg: *mut c_void) {
    let ctl = unsafe { &*arg.cast::<CtlCtx>() };
    ctl.ports_changed.store(true, Relaxed);
}

unsafe extern "C" fn shutdown_cb(arg: *mut c_void) {
    let ctl = unsafe { &*arg.cast::<CtlCtx>() };
    ctl.shutdown.store(true, Relaxed);
}

pub struct Backend {
    client: Option<JackClient>,
    rt: *mut RtCtx,
    pub ctl: Arc<CtlCtx>,
    pub in_names: [[String; 2]; NUM_STRIPS],
    pub out_names: [[String; 2]; NUM_BUSES],
    in_ports: [[Port; 2]; NUM_STRIPS],
    out_ports: [[Port; 2]; NUM_BUSES],
    pub client_name: String,
}

impl Backend {
    pub fn start(client: JackClient, shared: Arc<Shared>) -> Result<Backend, String> {
        let mut in_ports = [[std::ptr::null_mut(); 2]; NUM_STRIPS];
        let mut out_ports = [[std::ptr::null_mut(); 2]; NUM_BUSES];
        for (s, pair) in in_ports.iter_mut().enumerate() {
            pair[0] = client.register_audio_port(&format!("in{}_L", s + 1), true)?;
            pair[1] = client.register_audio_port(&format!("in{}_R", s + 1), true)?;
        }
        for (b, pair) in out_ports.iter_mut().enumerate() {
            pair[0] = client.register_audio_port(&format!("{}_L", BUS_IDS[b]), false)?;
            pair[1] = client.register_audio_port(&format!("{}_R", BUS_IDS[b]), false)?;
        }
        let in_names = in_ports.map(|p| p.map(|x| client.port_name(x)));
        let out_names = out_ports.map(|p| p.map(|x| client.port_name(x)));

        let ctl = Arc::new(CtlCtx {
            shared: shared.clone(),
            ports_changed: AtomicBool::new(true),
            shutdown: AtomicBool::new(false),
        });
        let rt = Box::into_raw(Box::new(RtCtx {
            lib: client.lib,
            engine: Engine::new(shared),
            ins: in_ports,
            outs: out_ports,
        }));
        let client_name = client.name();
        let mut me = Backend {
            client: Some(client),
            rt,
            ctl,
            in_names,
            out_names,
            in_ports,
            out_ports,
            client_name,
        };

        let c = me.client();
        let lib = c.lib;
        let ctl_ptr = Arc::as_ptr(&me.ctl).cast_mut().cast::<c_void>();
        // SAFETY: callbacks + context pointers stay valid until the client is
        // closed in Drop, which happens before the contexts are freed.
        unsafe {
            if (lib.jack_set_process_callback)(c.raw, Some(process_cb), me.rt.cast()) != 0 {
                return Err("jack_set_process_callback failed".into());
            }
            (lib.jack_set_xrun_callback)(c.raw, Some(xrun_cb), ctl_ptr);
            (lib.jack_set_port_registration_callback)(c.raw, Some(port_reg_cb), ctl_ptr);
            (lib.jack_on_shutdown)(c.raw, Some(shutdown_cb), ctl_ptr);
        }
        c.activate()?;
        me.client_name = me.client().name();
        Ok(me)
    }

    pub fn client(&self) -> &JackClient {
        self.client.as_ref().expect("client present until drop")
    }

    /// (capture latency into strips, playback latency out of A buses), frames.
    pub fn io_latency(&self) -> (u32, u32) {
        let c = self.client();
        let cap = self.in_ports.iter().flatten().map(|&p| c.latency(p, LATENCY_CAPTURE).max).max().unwrap_or(0);
        let play = self.out_ports[..NUM_PHYSICAL_BUSES]
            .iter()
            .flatten()
            .map(|&p| c.latency(p, LATENCY_PLAYBACK).max)
            .max()
            .unwrap_or(0);
        (cap, play)
    }

    /// Make every connection the config asks for. Idempotent; never removes
    /// connections. Returns (per-row description of what is connected, errors).
    pub fn autoconnect(&self, cfg: &Config, cables: Option<&CableSet>) -> (Vec<String>, Vec<String>) {
        let c = self.client();
        let own = format!("{}:", self.client_name);
        let mut errs = Vec::new();
        let mut desc = Vec::with_capacity(NUM_STRIPS + NUM_BUSES);

        let find = |pattern: &str, dir: c_ulong| -> Vec<String> {
            let (pat, flags) =
                if pattern == PHYSICAL { (None, dir | PORT_IS_PHYSICAL) } else { (Some(pattern), dir) };
            let mut v: Vec<String> = c.ports(pat, flags).into_iter().filter(|p| !p.starts_with(&own)).collect();
            if pattern == PHYSICAL {
                // PipeWire can flag a sound card's *monitor* ports as physical
                // outputs; using them for a strip would feed the speakers back
                // into the mixer.
                v.retain(|p| !p.split_once(':').is_some_and(|(_, short)| short.starts_with("monitor")));
                // keep only the first device so L/R never span two devices
                if let Some(first) = v.first().and_then(|p| p.split_once(':')).map(|(cl, _)| format!("{cl}:")) {
                    v.retain(|p| p.starts_with(&first));
                }
            }
            v
        };
        let client_of = |p: &str| p.split_once(':').map_or(p.to_string(), |(c, _)| c.to_string());

        for s in 0..NUM_STRIPS {
            let mut groups: Vec<(String, Vec<String>)> = Vec::new();
            if let Some(set) = cables {
                groups.push((set.strips[s].description.clone(), find(&set.strips[s].jack_regex(), PORT_IS_OUTPUT)));
            }
            for pat in &cfg.strips[s].connect {
                groups.push((pat.clone(), find(pat, PORT_IS_OUTPUT)));
            }
            let mut seen = Vec::new();
            for (label, srcs) in groups {
                let [l, r] = &self.in_names[s];
                let res = match srcs.len() {
                    0 => Err(format!("strip {}: nothing matches {label:?}", s + 1)),
                    1 => c.connect(&srcs[0], l).and_then(|_| c.connect(&srcs[0], r)),
                    _ => c.connect(&srcs[0], l).and_then(|_| c.connect(&srcs[1], r)),
                };
                match res {
                    Ok(()) => seen.push(client_of(&srcs[0])),
                    Err(e) => errs.push(e),
                }
            }
            desc.push(if seen.is_empty() { "(nothing connected)".into() } else { seen.join(" + ") });
        }

        for b in 0..NUM_BUSES {
            let mut groups: Vec<(String, Vec<String>)> = Vec::new();
            if b >= NUM_PHYSICAL_BUSES {
                if let Some(set) = cables {
                    let spec = &set.buses[b - NUM_PHYSICAL_BUSES];
                    groups.push((spec.description.clone(), find(&spec.jack_regex(), PORT_IS_INPUT)));
                }
            }
            for pat in &cfg.buses[b].connect {
                groups.push((pat.clone(), find(pat, PORT_IS_INPUT)));
            }
            let mut seen = Vec::new();
            for (label, dsts) in groups {
                let [l, r] = &self.out_names[b];
                let res = match dsts.len() {
                    0 => Err(format!("bus {}: nothing matches {label:?}", BUS_IDS[b])),
                    1 => c.connect(l, &dsts[0]).and_then(|_| c.connect(r, &dsts[0])),
                    _ => c.connect(l, &dsts[0]).and_then(|_| c.connect(r, &dsts[1])),
                };
                match res {
                    Ok(()) => seen.push(client_of(&dsts[0])),
                    Err(e) => errs.push(e),
                }
            }
            desc.push(if seen.is_empty() { "(nothing connected)".into() } else { seen.join(" + ") });
        }
        (desc, errs)
    }
}

impl Drop for Backend {
    fn drop(&mut self) {
        // Close the client first: after jack_client_close returns, no
        // callback can run, so freeing the contexts is safe.
        drop(self.client.take());
        // SAFETY: created by Box::into_raw in start(), freed exactly once.
        unsafe { drop(Box::from_raw(self.rt)) };
    }
}
