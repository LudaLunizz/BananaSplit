#!/bin/sh
# End-to-end test: runs the real vmix binary against mockjack (no audio server needed).
set -e
HERE=$(cd "$(dirname "$0")" && pwd)
BIN=${1:-$HERE/../../target/release/vmix}
gcc -shared -fPIC -O2 -o "$HERE/libjack.so.0" "$HERE/mockjack.c" -lpthread
TMP=$(mktemp -d); cp "$HERE/e2e.ini" "$TMP/vmix.ini"
export MOCKJACK_REPORT="$TMP/report.txt"
LD_LIBRARY_PATH="$HERE" "$BIN" --headless --config "$TMP/vmix.ini" 2>"$TMP/stderr.txt" &
PID=$!
sleep 7
kill -INT $PID; wait $PID; RC=$?
cat "$TMP/stderr.txt"; cat "$MOCKJACK_REPORT"
fail() { echo "E2E FAIL: $1"; exit 1; }
[ $RC -eq 0 ] || fail "exit code $RC"
grep -q GARBAGE "$MOCKJACK_REPORT" && fail "output buffers not fully written"
grep -q "^SIGNAL cycle=500 frame=77 vmix:A1_L -> system:playback_1 value=0.625000$" "$MOCKJACK_REPORT" || fail "A1_L"
grep -q "^SIGNAL cycle=500 frame=77 vmix:A1_R -> system:playback_2 value=0.312500$" "$MOCKJACK_REPORT" || fail "A1_R"
grep -q "^SIGNAL cycle=500 frame=77 vmix:B1_L -> OBS:input_1 value=0.500000$" "$MOCKJACK_REPORT" || fail "B1_L"
grep -q "^SIGNAL cycle=500 frame=77 vmix:B1_R -> OBS:input_1 value=0.250000$" "$MOCKJACK_REPORT" || fail "B1_R"
[ "$(grep -c '^SIGNAL' "$MOCKJACK_REPORT")" -eq 4 ] || fail "signal leaked to other frames/cycles/buses"
grep -q "^CYCLES 2000 " "$MOCKJACK_REPORT" || fail "process callback did not run every cycle"
echo "E2E PASS: all outputs sample-aligned at cycle 500 frame 77, zero added latency"
rm -rf "$TMP"

# ---- phase 2: PipeWire virtual cables (fake pactl + cable ports in the mock) ----
TMP=$(mktemp -d)
export PACTL_LOG="$TMP/pactl.log" MOCKJACK_REPORT="$TMP/report.txt" MOCKJACK_CABLES=1 XDG_CONFIG_HOME="$TMP"
PATH="$HERE/fakebin:$PATH" LD_LIBRARY_PATH="$HERE" "$BIN" --headless 2>"$TMP/stderr.txt" &
PID=$!
sleep 2
kill -TERM $PID; wait $PID; RC=$?
[ $RC -eq 0 ] || fail "cables: exit code $RC"
grep -q "^pactl unload-module 7$" "$PACTL_LOG" || fail "stale cable not removed"
grep -q "unload-module 9" "$PACTL_LOG" && fail "removed a module that is not ours"
[ "$(grep -c 'load-module module-null-sink' "$PACTL_LOG")" -eq 8 ] || fail "expected 8 cables"
[ "$(grep -c '^pactl unload-module 1[0-9][0-9]$' "$PACTL_LOG")" -eq 8 ] || fail "cables not removed on exit"
grep -q "node.description=vmix-Out-B1 media.class=Audio/Source/Virtual" "$PACTL_LOG" || fail "B1 virtual mic args"
for s in 1 2 3 4 5 6; do
  grep -q "^CONN vmix-In$s-[A-Za-z]*:monitor_FL -> vmix:in${s}_L$" "$MOCKJACK_REPORT" || fail "cable $s L"
  grep -q "^CONN vmix-In$s-[A-Za-z]*:monitor_FR -> vmix:in${s}_R$" "$MOCKJACK_REPORT" || fail "cable $s R"
done
grep -q "^CONN vmix:B1_L -> vmix-Out-B1:input_FL$" "$MOCKJACK_REPORT" || fail "B1 -> virtual mic"
grep -q "^CONN vmix:B2_R -> vmix-Out-B2:input_FR$" "$MOCKJACK_REPORT" || fail "B2 -> virtual mic"
echo "E2E PASS: 8 virtual cables created, wired, and removed; stale cable cleaned up"
rm -rf "$TMP"
