#[cfg(target_os = "windows")]
include!("main_windows.rs");

#[cfg(not(target_os = "windows"))]
include!("main_linux.rs");
