//! Virtual cables (PipeWire).
//!
//! * One **virtual output device per strip** (`Audio/Sink`), e.g.
//!   "BananaSplit-In3-Desktop". Point any application (or the system default output)
//!   at it and its audio lands on that strip. This is the equivalent of
//!   "VB-Audio CABLE Input" / "Voicemeeter Input".
//! * One **virtual microphone per B bus** (`Audio/Source/Virtual`), e.g.
//!   "BananaSplit-Out-B1". Pick it as the microphone in Discord/OBS/etc. This is the
//!   equivalent of "Voicemeeter Output" / "CABLE Output".
//!
//! Cables are created with `pactl load-module module-null-sink`, which
//! pipewire-pulse implements natively. They live in the same PipeWire graph
//! and are driven by the same clock as the mixer, so they add no buffering
//! and stay sample-aligned.
//!
//! Removal, from most to least common:
//! * normal exit (q, the GUI's power button, Ctrl-C, SIGTERM): `Drop`;
//! * BananaSplit killed with SIGKILL, or crashed: a small watchdog process
//!   (`bananasplit --reap-cables NAME`, started next to the cables) notices that
//!   its pipe from BananaSplit closed without the "done" line and removes them;
//! * watchdog killed too (e.g. `systemctl kill -s KILL`): the next start,
//!   `bananasplit --cleanup`, or the systemd unit's `ExecStopPost`.
//!
//! Every path matches modules by exact `sink_name`, so nothing that is not
//! a cable of this BananaSplit (same `client_name`) is ever touched.

use crate::jack::regex_escape;
use crate::sys;
use std::io::{BufRead, Write};
use std::process::{Child, ChildStdin, Command, ExitCode, Stdio};
use std::time::{Duration, Instant};
use bananasplit::config::Config;
use bananasplit::engine::{BUS_IDS, NUM_BUSES, NUM_PHYSICAL_BUSES, NUM_STRIPS};

/// Hidden command line flag of the watchdog process.
pub const REAPER_FLAG: &str = "--reap-cables";
/// Last line BananaSplit sends the watchdog on a normal exit.
const DISARM: &str = "done";

#[cfg(test)]
const NUM_VIRTUAL_BUSES: usize = NUM_BUSES - NUM_PHYSICAL_BUSES;

#[derive(Debug, Clone)]
pub struct CableSpec {
    /// PipeWire node.name (stable, used for cleanup).
    pub node_name: String,
    /// Human-readable name shown in sound settings.
    pub description: String,
    /// true = virtual microphone (B bus), false = virtual output (strip).
    pub is_source: bool,
}

impl CableSpec {
    /// Regex matching this cable's JACK client name. PipeWire's JACK layer
    /// names ports after node.description by default (node.name if
    /// `jack.short-name` is set), so accept either.
    pub fn jack_regex(&self) -> String {
        format!("^({}|{})[^:]*:", regex_escape(&self.node_name), regex_escape(&self.description))
    }
}

fn sanitize(s: &str) -> String {
    let t: String = s
        .chars()
        .map(|c| if c.is_ascii_alphanumeric() || c == '-' || c == '_' { c } else { '-' })
        .collect();
    let t = t.trim_matches('-').to_string();
    t.chars().take(24).collect()
}

pub struct CableSet {
    pub strips: Vec<CableSpec>, // NUM_STRIPS
    pub buses: Vec<CableSpec>,  // NUM_VIRTUAL_BUSES (B1, B2)
}

impl CableSet {
    pub fn for_config(cfg: &Config) -> CableSet {
        let prefix = cfg.client_name.to_ascii_lowercase().replace('-', "_");
        let strips = (0..NUM_STRIPS)
            .map(|i| {
                let nm = sanitize(&cfg.strips[i].name);
                CableSpec {
                    node_name: format!("{prefix}_in{}", i + 1),
                    description: if nm.is_empty() {
                        format!("{}-In{}", cfg.client_name, i + 1)
                    } else {
                        format!("{}-In{}-{nm}", cfg.client_name, i + 1)
                    },
                    is_source: false,
                }
            })
            .collect();
        let buses = (NUM_PHYSICAL_BUSES..NUM_BUSES)
            .map(|b| CableSpec {
                node_name: format!("{prefix}_out_{}", BUS_IDS[b].to_ascii_lowercase()),
                description: format!("{}-Out-{}", cfg.client_name, BUS_IDS[b]),
                is_source: true,
            })
            .collect();
        CableSet { strips, buses }
    }

    pub fn all(&self) -> impl Iterator<Item = &CableSpec> {
        self.strips.iter().chain(self.buses.iter())
    }

    pub fn node_names(&self) -> Vec<String> {
        self.all().map(|c| c.node_name.clone()).collect()
    }

    /// Is this PipeWire node (by node.name or description) one of our cables?
    pub fn owns(&self, node_name: &str, description: &str) -> bool {
        self.all().any(|c| c.node_name == node_name || c.description == description)
    }
}

/// Run pactl (C locale, so its output can be parsed).
pub fn pactl(args: &[&str]) -> Result<String, String> {
    let out = Command::new("pactl").args(args).env("LC_ALL", "C").stdin(Stdio::null()).output().map_err(|e| {
        format!("cannot run pactl ({e}); install pulseaudio-utils (Fedora, Debian, Ubuntu) or libpulse (Arch)")
    })?;
    if out.status.success() {
        Ok(String::from_utf8_lossy(&out.stdout).into_owned())
    } else {
        Err(format!("pactl {}: {}", args.join(" "), String::from_utf8_lossy(&out.stderr).trim()))
    }
}

/// Module ids in `pactl list short modules` output that are null-sinks with
/// one of `node_names` as their exact `sink_name`.
fn matching_modules(list: &str, node_names: &[String]) -> Vec<String> {
    let ours: Vec<String> = node_names.iter().map(|n| format!("sink_name={n}")).collect();
    list.lines()
        .filter_map(|line| {
            let mut f = line.split('\t');
            let (Some(id), Some(name), args) = (f.next(), f.next(), f.next().unwrap_or("")) else { return None };
            (name == "module-null-sink" && args.split_whitespace().any(|a| ours.iter().any(|o| o == a)))
                .then(|| id.to_string())
        })
        .collect()
}

/// Unload every cable module with one of these node names. Returns how many
/// were removed.
pub fn sweep(node_names: &[String]) -> Result<usize, String> {
    let list = pactl(&["list", "short", "modules"])?;
    Ok(matching_modules(&list, node_names).iter().filter(|id| pactl(&["unload-module", id]).is_ok()).count())
}

/// PIDs of cable watchdogs for `client` (other than this process).
fn reapers_of(client: &str) -> Vec<u32> {
    let me = std::process::id();
    let Ok(dir) = std::fs::read_dir("/proc") else { return Vec::new() };
    dir.filter_map(|e| e.ok()?.file_name().to_str()?.parse::<u32>().ok())
        .filter(|&pid| pid != me)
        .filter(|pid| {
            std::fs::read(format!("/proc/{pid}/cmdline")).is_ok_and(|b| {
                let mut a = b.split(|&c| c == 0).skip(1);
                a.next() == Some(REAPER_FLAG.as_bytes()) && a.next() == Some(client.as_bytes())
            })
        })
        .collect()
}

/// Wait (up to `timeout`) until no cable watchdog for `client` is running.
/// Called after BananaSplit owns its JACK name, so any watchdog left belongs to a
/// BananaSplit that has just died and is removing its cables right now; creating
/// new cables before it finishes could race with it. Returns false on timeout.
pub fn wait_for_reapers(client: &str, timeout: Duration) -> bool {
    let end = Instant::now() + timeout;
    loop {
        if reapers_of(client).is_empty() {
            return true;
        }
        if Instant::now() >= end {
            return false;
        }
        std::thread::sleep(Duration::from_millis(25));
    }
}

/// `bananasplit --reap-cables NAME`: read the cable node names from stdin, then
/// wait. If BananaSplit sends "done" it removed the cables itself; if the pipe just
/// closes, BananaSplit died without cleaning up, so remove them here.
pub fn reaper_main(client: &str) -> ExitCode {
    sys::ignore_termination_signals();
    sys::close_inherited_fds();
    let mut names = Vec::new();
    for line in std::io::stdin().lock().lines() {
        match line {
            Ok(l) if l == DISARM => return ExitCode::SUCCESS,
            Ok(l) if !l.is_empty() => names.push(l),
            Ok(_) => {}
            Err(_) => break,
        }
    }
    match sweep(&names) {
        Ok(0) => {}
        Ok(n) => eprintln!("bananasplit: removed {n} virtual cables of \"{client}\" (BananaSplit did not exit cleanly)"),
        Err(e) => eprintln!("bananasplit: could not remove the virtual cables of \"{client}\": {e}"),
    }
    ExitCode::SUCCESS
}

struct Reaper {
    child: Child,
    stdin: ChildStdin,
}

fn spawn_reaper(client: &str, set: &CableSet) -> Result<Reaper, String> {
    let exe = std::env::current_exe().map_err(|e| e.to_string())?;
    let mut child = Command::new(exe)
        .args([REAPER_FLAG, client])
        .stdin(Stdio::piped())
        .stdout(Stdio::null())
        .stderr(Stdio::inherit())
        .spawn()
        .map_err(|e| e.to_string())?;
    let mut stdin = child.stdin.take().ok_or("no pipe")?;
    let mut text = set.node_names().join("\n");
    text.push('\n');
    if let Err(e) = stdin.write_all(text.as_bytes()) {
        let _ = child.kill();
        let _ = child.wait();
        return Err(e.to_string());
    }
    Ok(Reaper { child, stdin })
}

/// Loaded cable modules; unloaded on drop.
pub struct Cables {
    modules: Vec<u32>,
    reaper: Option<Reaper>,
}

impl Cables {
    /// Create all cables. Returns the guard plus non-fatal warnings.
    /// Leftovers of an earlier BananaSplit must already be gone (see [`sweep`]).
    pub fn create(client: &str, set: &CableSet) -> (Cables, Vec<String>) {
        let mut warnings = Vec::new();
        let mut me = Cables { modules: Vec::new(), reaper: None };

        match pactl(&["info"]) {
            Ok(info) if info.contains("PipeWire") => {}
            Ok(_) => {
                warnings.push(
                    "virtual cables need PipeWire (pipewire-pulse); the sound server is not PipeWire, skipping cables".into(),
                );
                return (me, warnings);
            }
            Err(e) => {
                warnings.push(format!("no virtual cables: {e}"));
                return (me, warnings);
            }
        }

        // The watchdog first, so even a kill during creation is cleaned up.
        match spawn_reaper(client, set) {
            Ok(r) => me.reaper = Some(r),
            Err(e) => warnings.push(format!(
                "cable watchdog not started ({e}); if BananaSplit is killed, run `bananasplit --cleanup` to remove its cables"
            )),
        }

        for c in set.all() {
            let sink_name = format!("sink_name={}", c.node_name);
            let props = format!("sink_properties=device.description={}", c.description);
            let node_desc = format!("node.description={}", c.description);
            let mut args =
                vec!["load-module", "module-null-sink", sink_name.as_str(), props.as_str(), node_desc.as_str()];
            if c.is_source {
                args.push("media.class=Audio/Source/Virtual");
            } else {
                args.push("media.class=Audio/Sink");
            }
            args.push("channels=2");
            args.push("channel_map=front-left,front-right");
            match pactl(&args) {
                Ok(out) => match out.trim().parse::<u32>() {
                    Ok(id) => me.modules.push(id),
                    Err(_) => warnings.push(format!("unexpected pactl output for {}: {out:?}", c.description)),
                },
                Err(e) => warnings.push(e),
            }
        }
        (me, warnings)
    }

    pub fn none() -> Cables {
        Cables { modules: Vec::new(), reaper: None }
    }

    pub fn count(&self) -> usize {
        self.modules.len()
    }
}

impl Drop for Cables {
    fn drop(&mut self) {
        for id in self.modules.drain(..).rev() {
            let _ = pactl(&["unload-module", &id.to_string()]);
        }
        // Tell the watchdog the cables are gone, then let it exit.
        if let Some(mut r) = self.reaper.take() {
            let _ = writeln!(r.stdin, "{DISARM}");
            drop(r.stdin);
            let _ = r.child.wait();
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn names_are_stable_and_safe() {
        let mut cfg = Config::default();
        cfg.strips[2].name = "Desk top (main)!".into();
        let set = CableSet::for_config(&cfg);
        assert_eq!(set.strips.len(), NUM_STRIPS);
        assert_eq!(set.buses.len(), NUM_VIRTUAL_BUSES);
        assert_eq!(set.strips[2].node_name, "bananasplit_in3");
        assert_eq!(set.strips[2].description, "BananaSplit-In3-Desk-top--main");
        assert_eq!(set.buses[0].node_name, "bananasplit_out_b1");
        assert_eq!(set.buses[1].description, "BananaSplit-Out-B2");
        assert!(set.buses.iter().all(|b| b.is_source));
        assert_eq!(set.strips[0].jack_regex(), "^(bananasplit_in1|BananaSplit-In1-Mic)[^:]*:");
        for c in set.all() {
            assert!(!c.description.contains(' '), "pactl args must not contain spaces");
        }
        assert!(set.owns("bananasplit_out_b1", "whatever"));
        assert!(set.owns("x", "BananaSplit-In1-Mic"));
        assert!(!set.owns("alsa_input.usb-Blue", "Yeti Stereo Microphone"));
    }

    #[test]
    fn module_matching_is_exact() {
        let list = "7\tmodule-null-sink\tsink_name=bananasplit_in3 sink_properties=device.description=old\n\
                    8\tmodule-null-sink\tsink_name=bananasplit_in30\n\
                    9\tmodule-null-sink\tsink_name=someone_else\n\
                    10\tmodule-loopback\tsink_name=bananasplit_in1\n\
                    11\tmodule-null-sink\tsink_name=bananasplit_out_b2 channels=2\n";
        let names = CableSet::for_config(&Config::default()).node_names();
        assert_eq!(matching_modules(list, &names), ["7", "11"]);
        assert!(matching_modules(list, &[]).is_empty());
    }
}
