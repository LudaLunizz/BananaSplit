//! Persistent configuration (simple INI format, no dependencies).
//!
//! ```ini
//! [global]
//! client_name = BananaSplit
//! buffer_size = 128
//! force_buffer_size = false
//! create_cables = true
//!
//! [strip1]
//! name = Mic
//! gain_db = 0.0
//! mute = false
//! solo = false
//! mono = true
//! routes = B1
//! connect = @default
//!
//! [bus.A1]
//! name = Speakers
//! gain_db = 0.0
//! mute = false
//! mono = false
//! connect = @default
//!
//! [recorder]
//! folder = ~/Music/BananaSplit
//! format = wav24      # wav16 | wav24 | wav32f
//! mode = mix          # mix (one stereo file) | multi (one file per channel)
//! links = 1,A1        # channels feeding the recorder: 1-6, A1-A3, B1-B2 or none
//!
//! [vban]
//! enabled = true
//! port = 6980
//!
//! [vban.in1]
//! on = true
//! name = Stream1
//! from = 192.168.1.20 # the sender's IPv4 address, or any
//! strip = 4           # the strip it is added to
//! buffer_ms = 10      # reserve kept in the jitter buffer
//!
//! [vban.out1]
//! on = true
//! name = Stream1
//! to = 192.168.1.20   # the receiver (a .255 address broadcasts)
//! port = 6980
//! source = B1         # 1-6 (a strip, after its fader) or A1-B2 (a bus)
//! format = int16      # int16 | int24 | int32 | float32
//! channels = 2        # 1 = mono (L+R)/2, 2 = stereo
//! ```
//!
//! Every strip and bus also has `eq = on | off` and up to six bands,
//! `eq1` .. `eq6 = type freq_hz gain_db q [off]` (see [`crate::eq`]); a band
//! that is not written is the flat default.
//!
//! `connect` may be repeated. Each value is `@default` (the system's default
//! input device for a strip / default output device for a bus, as chosen in
//! the desktop's sound settings), `@physical` (a physical capture / playback
//! device, preferring the default one), or a JACK port-name regular
//! expression. The first two matching ports are connected to L/R; a single
//! (mono) port is connected to both. An empty `connect =` line clears the
//! list.
//!
//! Parsing is strict: unknown sections/keys and bad values are errors with a
//! line number, so a typo can never be silently ignored. A file without a
//! `[recorder]` or `[vban]` section or EQ keys (written by an older BananaSplit)
//! loads with their defaults.

use crate::engine::{BUS_IDS, NUM_BUSES, NUM_STRIPS, Shared, clamp_db};
use crate::eq::{BANDS, Band, DEFAULT_BANDS, EqSettings};
use crate::recorder::{self, ALL_LINKS, Format, Mode, Settings};
use crate::vban::{self, FromAddr, NUM_IN, NUM_OUT, SampleFormat, VbanConfig};
use std::fmt::Write as _;
use std::path::{Path, PathBuf};
use std::sync::atomic::Ordering::Relaxed;

pub const PHYSICAL: &str = "@physical";
pub const DEFAULT_DEVICE: &str = "@default";
#[cfg(target_os = "windows")]
const DESKTOP_CAPTURE: &[&str] = &["CABLE Output"];
#[cfg(not(target_os = "windows"))]
const DESKTOP_CAPTURE: &[&str] = &[];
#[cfg(target_os = "windows")]
const VIRTUAL_MIC: &[&str] = &["CABLE Input"];
#[cfg(not(target_os = "windows"))]
const VIRTUAL_MIC: &[&str] = &[];

/// A `connect` value: one of the `@` keywords, or anything else (a regex).
fn check_connect(v: &str) -> Result<(), String> {
    if v.starts_with('@') && v != PHYSICAL && v != DEFAULT_DEVICE {
        return Err(format!("unknown connect keyword {v:?} (expected {DEFAULT_DEVICE}, {PHYSICAL} or a JACK port regex)"));
    }
    Ok(())
}

#[derive(Debug, Clone, PartialEq)]
pub struct RecorderConfig {
    pub folder: String,
    pub format: Format,
    pub mode: Mode,
    /// Linked channels, same bit layout as [`Shared::rec_links`].
    pub links: u16,
}

impl Default for RecorderConfig {
    fn default() -> Self {
        let s = Settings::default();
        RecorderConfig { folder: s.folder, format: s.format, mode: s.mode, links: 1 << NUM_STRIPS } // A1
    }
}

impl RecorderConfig {
    pub fn settings(&self) -> Settings {
        Settings { folder: self.folder.clone(), format: self.format, mode: self.mode }
    }

    pub fn set_settings(&mut self, s: &Settings) {
        self.folder = s.folder.clone();
        self.format = s.format;
        self.mode = s.mode;
    }
}

#[derive(Debug, Clone, PartialEq)]
pub struct StripConfig {
    pub name: String,
    pub gain_db: f32,
    pub mute: bool,
    pub solo: bool,
    pub mono: bool,
    pub routes: u8,
    pub connect: Vec<String>,
    pub eq: EqSettings,
}

#[derive(Debug, Clone, PartialEq)]
pub struct BusConfig {
    pub name: String,
    pub gain_db: f32,
    pub mute: bool,
    pub mono: bool,
    pub connect: Vec<String>,
    pub eq: EqSettings,
}

#[derive(Debug, Clone, PartialEq)]
pub struct Config {
    pub client_name: String,
    /// Requested period in frames (0 = don't request anything).
    pub buffer_size: u32,
    /// Call jack_set_buffer_size() if the server runs a larger period.
    /// Under JACK2 this changes the period for every client.
    pub force_buffer_size: bool,
    /// Create PipeWire virtual cables (one sink per strip, one virtual
    /// microphone per B bus) via `pactl`.
    pub create_cables: bool,
    pub strips: [StripConfig; NUM_STRIPS],
    pub buses: [BusConfig; NUM_BUSES],
    pub recorder: RecorderConfig,
    pub vban: VbanConfig,
}

impl Default for Config {
    fn default() -> Self {
        let strip = |name: &str, routes: u8, mono: bool, connect: &[&str]| StripConfig {
            name: name.into(),
            gain_db: 0.0,
            mute: false,
            solo: false,
            mono,
            routes,
            connect: connect.iter().map(|s| s.to_string()).collect(),
            eq: EqSettings::default(),
        };
        let bus = |name: &str, connect: &[&str]| BusConfig {
            name: name.into(),
            gain_db: 0.0,
            mute: false,
            mono: false,
            connect: connect.iter().map(|s| s.to_string()).collect(),
            eq: EqSettings::default(),
        };
        const A1: u8 = 1;
        const A2: u8 = 2;
        const B1: u8 = 8;
        Config {
            client_name: "BananaSplit".into(),
            buffer_size: 128,
            force_buffer_size: false,
            create_cables: true,
            strips: [
                strip("Mic", B1, true, &[DEFAULT_DEVICE]),
                strip("Discord", A1 | A2, false, &[]),
                strip("Desktop", A1, false, DESKTOP_CAPTURE),
                strip("Game", A1, false, &[]),
                strip("Music", A1, false, &[]),
                strip("Aux", A1, false, &[]),
            ],
            buses: [
                bus("Speakers", &[DEFAULT_DEVICE]),
                bus("Headphones", &[]),
                bus("A3", &[]),
                bus("Virtual B1", VIRTUAL_MIC),
                bus("Virtual B2", &[]),
            ],
            recorder: RecorderConfig::default(),
            vban: VbanConfig::default(),
        }
    }
}

#[derive(Debug)]
pub struct ParseError {
    pub line: usize,
    pub msg: String,
}

impl std::fmt::Display for ParseError {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        write!(f, "line {}: {}", self.line, self.msg)
    }
}
impl std::error::Error for ParseError {}

enum Section {
    None,
    Global,
    Strip(usize),
    Bus(usize),
    Recorder,
    Vban,
    VbanIn(usize),
    VbanOut(usize),
}

/// `eq`, `eq1` .. `eq6` keys of a strip or bus.
fn eq_key(eq: &mut EqSettings, k: &str, v: &str) -> Option<Result<(), String>> {
    if k == "eq" {
        return Some(parse_bool(v).map(|b| eq.on = b));
    }
    let n: usize = k.strip_prefix("eq")?.parse().ok()?;
    if !(1..=BANDS).contains(&n) {
        return Some(Err(format!("unknown key {k:?} (EQ bands are eq1..eq{BANDS})")));
    }
    Some(Band::parse(v).map(|b| eq.bands[n - 1] = b))
}

fn write_eq(o: &mut String, eq: &EqSettings) {
    let _ = writeln!(o, "eq = {}", if eq.on { "on" } else { "off" });
    for (i, b) in eq.bands.iter().enumerate() {
        if *b != DEFAULT_BANDS[i] {
            let _ = writeln!(o, "eq{} = {}", i + 1, b.to_config());
        }
    }
}

fn vban_slot(h: &str, prefix: &str, n: usize) -> Option<Result<usize, String>> {
    let k: usize = h.get(..prefix.len()).filter(|p| p.eq_ignore_ascii_case(prefix)).and(h.get(prefix.len()..))?.parse().ok()?;
    Some(if (1..=n).contains(&k) { Ok(k - 1) } else { Err(format!("unknown section [{h}] (VBAN streams are {prefix}1..{prefix}{n})")) })
}

fn parse_bool(v: &str) -> Result<bool, String> {
    match v.to_ascii_lowercase().as_str() {
        "true" | "yes" | "on" | "1" => Ok(true),
        "false" | "no" | "off" | "0" => Ok(false),
        _ => Err(format!("expected true/false, got {v:?}")),
    }
}

fn parse_gain(v: &str) -> Result<f32, String> {
    let g: f32 = v.parse().map_err(|_| format!("expected a number, got {v:?}"))?;
    if !g.is_finite() {
        return Err(format!("gain must be finite, got {v:?}"));
    }
    Ok(clamp_db(g))
}

pub fn parse_routes(v: &str) -> Result<u8, String> {
    let mut mask = 0u8;
    for tok in v.split(',').map(str::trim).filter(|t| !t.is_empty()) {
        if tok.eq_ignore_ascii_case("none") {
            continue;
        }
        match BUS_IDS.iter().position(|b| b.eq_ignore_ascii_case(tok)) {
            Some(i) => mask |= 1 << i,
            None => return Err(format!("unknown bus {tok:?} (expected A1, A2, A3, B1, B2)")),
        }
    }
    Ok(mask)
}

pub fn format_routes(mask: u8) -> String {
    let v: Vec<&str> = (0..NUM_BUSES).filter(|b| mask & (1 << b) != 0).map(|b| BUS_IDS[b]).collect();
    if v.is_empty() { "none".into() } else { v.join(",") }
}

fn valid_client_name(v: &str) -> bool {
    !v.is_empty() && v.len() <= 32 && v.chars().all(|c| c.is_ascii_alphanumeric() || c == '-' || c == '_')
}

impl Config {
    pub fn parse(text: &str) -> Result<Config, ParseError> {
        let mut cfg = Config::default();
        let mut sec = Section::None;
        // A `connect` list from the file replaces the default list the first
        // time it is seen in a section, then appends.
        let mut strip_seen = [false; NUM_STRIPS];
        let mut bus_seen = [false; NUM_BUSES];

        for (idx, raw) in text.lines().enumerate() {
            let line_no = idx + 1;
            let err = |msg: String| ParseError { line: line_no, msg };
            let line = raw.trim();
            if line.is_empty() || line.starts_with('#') || line.starts_with(';') {
                continue;
            }
            if let Some(h) = line.strip_prefix('[') {
                let h = h.strip_suffix(']').ok_or_else(|| err("missing ']'".into()))?.trim();
                sec = if h.eq_ignore_ascii_case("global") {
                    Section::Global
                } else if h.eq_ignore_ascii_case("recorder") {
                    Section::Recorder
                } else if h.eq_ignore_ascii_case("vban") {
                    Section::Vban
                } else if let Some(r) = vban_slot(h, "vban.in", NUM_IN) {
                    Section::VbanIn(r.map_err(err)?)
                } else if let Some(r) = vban_slot(h, "vban.out", NUM_OUT) {
                    Section::VbanOut(r.map_err(err)?)
                } else if let Some(n) = h.strip_prefix("strip") {
                    match n.parse::<usize>() {
                        Ok(i) if (1..=NUM_STRIPS).contains(&i) => Section::Strip(i - 1),
                        _ => return Err(err(format!("unknown section [{h}] (strips are strip1..strip{NUM_STRIPS})"))),
                    }
                } else if let Some(id) = h.strip_prefix("bus.") {
                    match BUS_IDS.iter().position(|b| b.eq_ignore_ascii_case(id)) {
                        Some(i) => Section::Bus(i),
                        None => return Err(err(format!("unknown section [{h}] (buses are bus.A1..bus.B2)"))),
                    }
                } else {
                    return Err(err(format!("unknown section [{h}]")));
                };
                continue;
            }
            let (k, v) = line.split_once('=').ok_or_else(|| err("expected key = value".into()))?;
            let (k, v) = (k.trim(), v.trim());
            match sec {
                Section::None => return Err(err("key outside of a section".into())),
                Section::Global => match k {
                    "client_name" => {
                        if !valid_client_name(v) {
                            return Err(err("client_name must be 1-32 chars of [A-Za-z0-9_-]".into()));
                        }
                        cfg.client_name = v.into();
                    }
                    "buffer_size" => {
                        let n: u32 = v.parse().map_err(|_| err(format!("bad buffer_size {v:?}")))?;
                        if n != 0 && (!n.is_power_of_two() || !(16..=8192).contains(&n)) {
                            return Err(err("buffer_size must be 0 or a power of two in 16..=8192".into()));
                        }
                        cfg.buffer_size = n;
                    }
                    "force_buffer_size" => cfg.force_buffer_size = parse_bool(v).map_err(err)?,
                    "create_cables" => cfg.create_cables = parse_bool(v).map_err(err)?,
                    _ => return Err(err(format!("unknown key {k:?} in [global]"))),
                },
                Section::Strip(i) => {
                    let s = &mut cfg.strips[i];
                    match k {
                        "name" => s.name = v.into(),
                        "gain_db" => s.gain_db = parse_gain(v).map_err(err)?,
                        "mute" => s.mute = parse_bool(v).map_err(err)?,
                        "solo" => s.solo = parse_bool(v).map_err(err)?,
                        "mono" => s.mono = parse_bool(v).map_err(err)?,
                        "routes" => s.routes = parse_routes(v).map_err(err)?,
                        "connect" => {
                            check_connect(v).map_err(err)?;
                            if !strip_seen[i] {
                                s.connect.clear();
                                strip_seen[i] = true;
                            }
                            if v.is_empty() { s.connect.clear() } else { s.connect.push(v.into()) }
                        }
                        _ => match eq_key(&mut s.eq, k, v) {
                            Some(r) => r.map_err(err)?,
                            None => return Err(err(format!("unknown key {k:?} in [strip{}]", i + 1))),
                        },
                    }
                }
                Section::Bus(i) => {
                    let b = &mut cfg.buses[i];
                    match k {
                        "name" => b.name = v.into(),
                        "gain_db" => b.gain_db = parse_gain(v).map_err(err)?,
                        "mute" => b.mute = parse_bool(v).map_err(err)?,
                        "mono" => b.mono = parse_bool(v).map_err(err)?,
                        "connect" => {
                            check_connect(v).map_err(err)?;
                            if !bus_seen[i] {
                                b.connect.clear();
                                bus_seen[i] = true;
                            }
                            if v.is_empty() { b.connect.clear() } else { b.connect.push(v.into()) }
                        }
                        _ => match eq_key(&mut b.eq, k, v) {
                            Some(r) => r.map_err(err)?,
                            None => return Err(err(format!("unknown key {k:?} in [bus.{}]", BUS_IDS[i]))),
                        },
                    }
                }
                Section::Recorder => {
                    let r = &mut cfg.recorder;
                    match k {
                        "folder" => {
                            recorder::validate_folder(v).map_err(err)?;
                            r.folder = v.into();
                        }
                        "format" => r.format = Format::parse(v).map_err(err)?,
                        "mode" => r.mode = Mode::parse(v).map_err(err)?,
                        "links" => r.links = recorder::parse_links(v).map_err(err)?,
                        _ => return Err(err(format!("unknown key {k:?} in [recorder]"))),
                    }
                }
                Section::Vban => match k {
                    "enabled" => cfg.vban.enabled = parse_bool(v).map_err(err)?,
                    "port" => cfg.vban.port = vban::parse_port(v).map_err(err)?,
                    _ => return Err(err(format!("unknown key {k:?} in [vban]"))),
                },
                Section::VbanIn(i) => {
                    let s = &mut cfg.vban.ins[i];
                    match k {
                        "on" => s.on = parse_bool(v).map_err(err)?,
                        "name" => {
                            vban::proto::validate_name(v).map_err(err)?;
                            s.name = v.into();
                        }
                        "from" => s.from = FromAddr::parse(v).map_err(err)?,
                        "strip" => s.strip = vban::parse_strip(v).map_err(err)?,
                        "buffer_ms" => s.buffer_ms = vban::parse_buffer_ms(v).map_err(err)?,
                        _ => return Err(err(format!("unknown key {k:?} in [vban.in{}]", i + 1))),
                    }
                }
                Section::VbanOut(i) => {
                    let s = &mut cfg.vban.outs[i];
                    match k {
                        "on" => s.on = parse_bool(v).map_err(err)?,
                        "name" => {
                            vban::proto::validate_name(v).map_err(err)?;
                            s.name = v.into();
                        }
                        "to" => s.to = vban::parse_to(v).map_err(err)?,
                        "port" => s.port = vban::parse_port(v).map_err(err)?,
                        "source" => s.source = vban::parse_source(v).map_err(err)?,
                        "format" => s.format = SampleFormat::parse_send(v).map_err(err)?,
                        "channels" => s.channels = vban::parse_channels(v).map_err(err)?,
                        _ => return Err(err(format!("unknown key {k:?} in [vban.out{}]", i + 1))),
                    }
                }
            }
        }
        Ok(cfg)
    }

    pub fn to_ini(&self) -> String {
        let mut o = String::new();
        let _ = writeln!(o, "# BananaSplit configuration — written by BananaSplit; comments are not preserved.");
        let _ = writeln!(o, "# connect = @default | @physical | <JACK port regex>   (may be repeated;");
        let _ = writeln!(o, "#           `bananasplit --list-ports` shows the port names and a ready-made line)");
        let _ = writeln!(o, "# eq = on | off;  eq1 .. eq6 = type freq_hz gain_db q [off], type = bell | lowshelf |");
        let _ = writeln!(o, "#           highshelf | lowcut | highcut | notch. A band not written here is flat:");
        let _ = writeln!(o, "#           lowshelf 100, bell 250 / 600 / 1500 / 4000, highshelf 10000, all +0 dB");
        let _ = writeln!(o, "\n[global]");
        let _ = writeln!(o, "client_name = {}", self.client_name);
        let _ = writeln!(o, "buffer_size = {}", self.buffer_size);
        let _ = writeln!(o, "force_buffer_size = {}", self.force_buffer_size);
        let _ = writeln!(o, "create_cables = {}", self.create_cables);
        for (i, s) in self.strips.iter().enumerate() {
            let _ = writeln!(o, "\n[strip{}]", i + 1);
            let _ = writeln!(o, "name = {}", s.name);
            let _ = writeln!(o, "gain_db = {}", s.gain_db);
            let _ = writeln!(o, "mute = {}", s.mute);
            let _ = writeln!(o, "solo = {}", s.solo);
            let _ = writeln!(o, "mono = {}", s.mono);
            let _ = writeln!(o, "routes = {}", format_routes(s.routes));
            if s.connect.is_empty() {
                let _ = writeln!(o, "connect =");
            }
            for c in &s.connect {
                let _ = writeln!(o, "connect = {c}");
            }
            write_eq(&mut o, &s.eq);
        }
        for (i, b) in self.buses.iter().enumerate() {
            let _ = writeln!(o, "\n[bus.{}]", BUS_IDS[i]);
            let _ = writeln!(o, "name = {}", b.name);
            let _ = writeln!(o, "gain_db = {}", b.gain_db);
            let _ = writeln!(o, "mute = {}", b.mute);
            let _ = writeln!(o, "mono = {}", b.mono);
            if b.connect.is_empty() {
                let _ = writeln!(o, "connect =");
            }
            for c in &b.connect {
                let _ = writeln!(o, "connect = {c}");
            }
            write_eq(&mut o, &b.eq);
        }
        let r = &self.recorder;
        let _ = writeln!(o, "\n[recorder]");
        let _ = writeln!(o, "# links: 1-6 = strips, A1-A3 / B1-B2 = buses; mode = mix | multi");
        let _ = writeln!(o, "folder = {}", r.folder);
        let _ = writeln!(o, "format = {}", r.format.as_str());
        let _ = writeln!(o, "mode = {}", r.mode.as_str());
        let _ = writeln!(o, "links = {}", recorder::format_links(r.links));
        let v = &self.vban;
        let _ = writeln!(o, "\n[vban]");
        let _ = writeln!(o, "# Network audio, compatible with Voicemeeter's VBAN. Streams (up to 8 each way):");
        let _ = writeln!(o, "#   [vban.in1] .. [vban.in8]:   on, name, from = <sender IPv4> | any, strip = 1-6, buffer_ms");
        let _ = writeln!(o, "#   [vban.out1] .. [vban.out8]: on, name, to = <receiver IPv4>, port, source = 1-6 | A1-B2,");
        let _ = writeln!(o, "#                               format = int16 | int24 | int32 | float32, channels = 1 | 2");
        let _ = writeln!(o, "enabled = {}", v.enabled);
        let _ = writeln!(o, "port = {}", v.port);
        for (i, s) in v.ins.iter().enumerate() {
            if *s == vban::InStream::default_for(i) {
                continue;
            }
            let _ = writeln!(o, "\n[vban.in{}]", i + 1);
            let _ = writeln!(o, "on = {}", s.on);
            let _ = writeln!(o, "name = {}", s.name);
            let _ = writeln!(o, "from = {}", s.from.as_string());
            let _ = writeln!(o, "strip = {}", s.strip + 1);
            let _ = writeln!(o, "buffer_ms = {}", s.buffer_ms);
        }
        for (i, s) in v.outs.iter().enumerate() {
            if *s == vban::OutStream::default_for(i) {
                continue;
            }
            let _ = writeln!(o, "\n[vban.out{}]", i + 1);
            let _ = writeln!(o, "on = {}", s.on);
            let _ = writeln!(o, "name = {}", s.name);
            let _ = writeln!(o, "to = {}", s.to.map_or(String::new(), |ip| ip.to_string()));
            let _ = writeln!(o, "port = {}", s.port);
            let _ = writeln!(o, "source = {}", recorder::source_id(s.source));
            let _ = writeln!(o, "format = {}", s.format.as_str());
            let _ = writeln!(o, "channels = {}", s.channels);
        }
        o
    }

    /// Push mixer parameters into the shared real-time state.
    pub fn apply(&self, sh: &Shared) {
        for (s, p) in self.strips.iter().zip(&sh.strips) {
            p.gain_db.store(clamp_db(s.gain_db));
            p.mute.store(s.mute, Relaxed);
            p.solo.store(s.solo, Relaxed);
            p.mono.store(s.mono, Relaxed);
            p.routes.store(s.routes & 0b11111, Relaxed);
            p.eq.apply(&s.eq);
        }
        for (b, p) in self.buses.iter().zip(&sh.buses) {
            p.gain_db.store(clamp_db(b.gain_db));
            p.mute.store(b.mute, Relaxed);
            p.mono.store(b.mono, Relaxed);
            p.eq.apply(&b.eq);
        }
        sh.rec_links.store(self.recorder.links & ALL_LINKS, Relaxed);
    }

    /// Pull current mixer parameters back from the shared state.
    pub fn capture(&mut self, sh: &Shared) {
        for (s, p) in self.strips.iter_mut().zip(&sh.strips) {
            s.gain_db = p.gain_db.load();
            s.mute = p.mute.load(Relaxed);
            s.solo = p.solo.load(Relaxed);
            s.mono = p.mono.load(Relaxed);
            s.routes = p.routes.load(Relaxed);
            s.eq = p.eq.settings();
        }
        for (b, p) in self.buses.iter_mut().zip(&sh.buses) {
            b.gain_db = p.gain_db.load();
            b.mute = p.mute.load(Relaxed);
            b.mono = p.mono.load(Relaxed);
            b.eq = p.eq.settings();
        }
        self.recorder.links = sh.rec_links.load(Relaxed) & ALL_LINKS;
    }

    pub fn default_path() -> PathBuf {
        config_home().join("bananasplit").join("bananasplit.ini")
    }

    /// Where versions up to 2.4, still called vmix, kept the config.
    pub fn legacy_path() -> PathBuf {
        config_home().join("vmix").join("vmix.ini")
    }

    /// First start after the rename from vmix: if `path` does not exist yet
    /// and the old `legacy` file does, write its settings to `path`. The old
    /// file is left alone, so vmix 2.4 still starts with it. The old default
    /// JACK name "vmix" becomes "BananaSplit" (which renames the virtual
    /// cables too); a name the user picked is kept. Returns a note for the
    /// user when something was copied.
    pub fn migrate_legacy(path: &Path, legacy: &Path) -> Result<Option<String>, String> {
        if path.exists() {
            return Ok(None);
        }
        let text = match std::fs::read_to_string(legacy) {
            Ok(text) => text,
            Err(e) if e.kind() == std::io::ErrorKind::NotFound => return Ok(None),
            Err(e) => return Err(format!("{}: {e}", legacy.display())),
        };
        let mut cfg = Config::parse(&text).map_err(|e| format!("{}: {e}", legacy.display()))?;
        let renamed = cfg.client_name == LEGACY_CLIENT_NAME;
        if renamed {
            cfg.client_name = Config::default().client_name;
        }
        cfg.save(path)?;
        let mut note = format!("copied the vmix settings from {} to {}", legacy.display(), path.display());
        if renamed {
            note.push_str(&format!(
                "; the virtual cables are now called {}-In1 … and {}-Out-B1 …, so pick them again in your apps",
                cfg.client_name, cfg.client_name
            ));
        }
        Ok(Some(note))
    }

    /// Load from `path`; if it does not exist, write the defaults there.
    pub fn load_or_create(path: &Path) -> Result<Config, String> {
        match std::fs::read_to_string(path) {
            Ok(text) => Config::parse(&text).map_err(|e| format!("{}: {e}", path.display())),
            Err(e) if e.kind() == std::io::ErrorKind::NotFound => {
                let cfg = Config::default();
                cfg.save(path)?;
                Ok(cfg)
            }
            Err(e) => Err(format!("{}: {e}", path.display())),
        }
    }

    /// Load from `path`, or the defaults if it does not exist. Never writes.
    pub fn load_or_default(path: &Path) -> Result<Config, String> {
        match std::fs::read_to_string(path) {
            Ok(text) => Config::parse(&text).map_err(|e| format!("{}: {e}", path.display())),
            Err(e) if e.kind() == std::io::ErrorKind::NotFound => Ok(Config::default()),
            Err(e) => Err(format!("{}: {e}", path.display())),
        }
    }

    /// Atomic save (write temp file, then rename).
    pub fn save(&self, path: &Path) -> Result<(), String> {
        if let Some(dir) = path.parent() {
            if !dir.as_os_str().is_empty() {
                std::fs::create_dir_all(dir).map_err(|e| format!("{}: {e}", dir.display()))?;
            }
        }
        let tmp = path.with_extension("ini.tmp");
        std::fs::write(&tmp, self.to_ini()).map_err(|e| format!("{}: {e}", tmp.display()))?;
        std::fs::rename(&tmp, path).map_err(|e| format!("{}: {e}", path.display()))
    }
}

/// The JACK name vmix (this program before 2.5) used by default.
pub const LEGACY_CLIENT_NAME: &str = "vmix";

/// On Windows use `%APPDATA%`; on Unix use `$XDG_CONFIG_HOME`, else `~/.config`.
fn config_home() -> PathBuf {
    #[cfg(target_os = "windows")]
    {
        std::env::var_os("APPDATA").map(PathBuf::from).or_else(|| {
            std::env::var_os("USERPROFILE").map(|p| PathBuf::from(p).join("AppData").join("Roaming"))
        }).unwrap_or_else(|| PathBuf::from("."))
    }
    #[cfg(not(target_os = "windows"))]
    {
        std::env::var_os("XDG_CONFIG_HOME")
            .filter(|v| !v.is_empty())
            .map(PathBuf::from)
            .or_else(|| std::env::var_os("HOME").map(|h| PathBuf::from(h).join(".config")))
            .unwrap_or_else(|| PathBuf::from("."))
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn default_round_trips() {
        let c = Config::default();
        assert_eq!(Config::parse(&c.to_ini()).unwrap(), c);
    }

    #[test]
    #[allow(clippy::field_reassign_with_default)]
    fn modified_round_trips() {
        let mut c = Config::default();
        c.client_name = "mix_2".into();
        c.buffer_size = 64;
        c.strips[4].gain_db = -12.5;
        c.strips[4].routes = 0b10101;
        c.strips[4].connect = vec!["^Firefox:output_F[LR]$".into(), "a{1,2}".into()];
        c.strips[0].connect.clear();
        c.buses[2].mono = true;
        c.buses[2].connect = vec!["^USB Audio:playback_F[LR]$".into()];
        c.recorder.folder = "/srv/rec dir/BananaSplit".into();
        c.recorder.format = Format::Wav32f;
        c.recorder.mode = Mode::Multi;
        c.recorder.links = 0b110_0010_0001;
        assert_eq!(Config::parse(&c.to_ini()).unwrap(), c);
        c.recorder.links = 0;
        assert_eq!(Config::parse(&c.to_ini()).unwrap(), c);
        // EQ
        c.strips[0].eq.on = true;
        c.strips[0].eq.bands[0] = Band { on: true, kind: crate::eq::Kind::LowCut, freq: 80.0, gain_db: 0.0, q: 0.71 };
        c.strips[0].eq.bands[4].gain_db = 3.5;
        c.buses[1].eq.bands[5] = Band { on: false, ..c.buses[1].eq.bands[5] };
        c.buses[4].eq.on = true;
        assert_eq!(Config::parse(&c.to_ini()).unwrap(), c);
        // VBAN
        c.vban.enabled = true;
        c.vban.port = 6990;
        c.vban.ins[0] = vban::InStream { on: true, name: "Voicemeeter Out".into(), from: FromAddr::Ip([192, 168, 1, 20].into()), strip: 3, buffer_ms: 0 };
        c.vban.ins[7].from = FromAddr::Any;
        c.vban.outs[2] = vban::OutStream { on: true, name: "Mix".into(), to: Some([192, 168, 1, 255].into()), port: 6981, source: 0, format: SampleFormat::F32, channels: 1 };
        c.vban.outs[3].to = Some([10, 0, 0, 1].into());
        let text = c.to_ini();
        assert_eq!(Config::parse(&text).unwrap(), c);
        assert_eq!(text.matches("\n[vban.").count(), 4, "only streams that differ from the defaults are written");
    }

    #[test]
    fn eq_and_vban_errors() {
        let e = Config::parse("[strip2]\neq7 = bell 1000 0 1\n").unwrap_err();
        assert!(e.line == 2 && e.msg.contains("eq7"), "{e}");
        assert!(Config::parse("[bus.A1]\neq1 = bell 1000 0\n").is_err());
        assert!(Config::parse("[bus.A1]\neq = maybe\n").is_err());
        assert!(Config::parse("[strip1]\neqx = 1\n").unwrap_err().msg.contains("eqx"));
        let c = Config::parse("[strip3]\neq = on\neq2 = notch 50 0 10\n").unwrap();
        assert!(c.strips[2].eq.on && c.strips[2].eq.bands[1].kind == crate::eq::Kind::Notch);
        assert_eq!(Config::parse("[vban.in9]\n").unwrap_err().line, 1);
        assert!(Config::parse("[vban.out0]\n").is_err());
        assert!(Config::parse("[vban]\nport = 0\n").is_err());
        assert!(Config::parse("[vban.in1]\nname = 0123456789abcdefg\n").is_err());
        assert!(Config::parse("[vban.in1]\nfrom = 192.168.1.300\n").is_err());
        assert!(Config::parse("[vban.in1]\nstrip = 7\n").is_err());
        assert!(Config::parse("[vban.in1]\nbuffer_ms = 500\n").is_err());
        assert!(Config::parse("[vban.out1]\nsource = B3\n").is_err());
        assert!(Config::parse("[vban.out1]\nformat = mp3\n").is_err());
        assert!(Config::parse("[vban.out1]\nchannels = 8\n").is_err());
        assert!(Config::parse("[vban.out1]\nto = any\n").is_err());
        assert!(Config::parse("[vban.out1]\nvolume = 1\n").unwrap_err().msg.contains("volume"));
        let c = Config::parse("[VBAN]\nenabled = yes\n[vban.IN2]\non = 1\nfrom = any\n[vban.out8]\nsource = a2\nformat = 24\n").unwrap();
        assert!(c.vban.enabled && c.vban.ins[1].on && c.vban.ins[1].from == FromAddr::Any);
        assert_eq!((c.vban.outs[7].source, c.vban.outs[7].format), (7, SampleFormat::I24));
        // older files (no EQ, no [vban]) load with the defaults
        let old = Config::parse("[global]\nclient_name = BananaSplit\n[strip1]\nname = Mic\n").unwrap();
        assert_eq!((&old.strips[0].eq, &old.vban), (&EqSettings::default(), &VbanConfig::default()));
    }

    #[test]
    fn recorder_section() {
        // a config written before the recorder existed still loads
        let old = "[global]\nclient_name = BananaSplit\n[strip1]\nname = Mic\n";
        assert_eq!(Config::parse(old).unwrap().recorder, RecorderConfig::default());
        let c = Config::parse("[Recorder]\nfolder = ~/rec\nformat = wav16\nmode = multi\nlinks = 2, b1\n").unwrap();
        assert_eq!(c.recorder.folder, "~/rec");
        assert_eq!(c.recorder.format, Format::Wav16);
        assert_eq!(c.recorder.mode, Mode::Multi);
        assert_eq!(c.recorder.links, 0b010_0000_0010);
        let e = Config::parse("[recorder]\nformat = mp3\n").unwrap_err();
        assert_eq!(e.line, 2);
        assert!(Config::parse("[recorder]\nmode = stereo\n").is_err());
        assert!(Config::parse("[recorder]\nlinks = 1,C9\n").unwrap_err().msg.contains("C9"));
        assert!(Config::parse("[recorder]\nfolder =\n").is_err());
        assert!(Config::parse("[recorder]\ngain = 1\n").unwrap_err().msg.contains("gain"));
    }

    #[test]
    fn strict_errors_have_line_numbers() {
        let e = Config::parse("[global]\nbuffer_size = 100\n").unwrap_err();
        assert_eq!(e.line, 2);
        let e = Config::parse("[strip7]\n").unwrap_err();
        assert_eq!(e.line, 1);
        let e = Config::parse("[strip1]\nroutes = A1,C3\n").unwrap_err();
        assert!(e.msg.contains("C3"));
        let e = Config::parse("[bus.A1]\nvolume = 3\n").unwrap_err();
        assert!(e.msg.contains("volume"));
        assert!(Config::parse("gain_db = 1\n").is_err());
        assert!(Config::parse("[global]\nclient_name = bad name\n").is_err());
        assert!(Config::parse("[strip1]\ngain_db = inf\n").is_err());
        let e = Config::parse("[strip1]\nconnect = @defualt\n").unwrap_err();
        assert!(e.line == 2 && e.msg.contains("@defualt"), "{e}");
        assert!(Config::parse("[bus.A2]\nconnect = @mic\n").is_err());
    }

    #[test]
    fn connect_keywords() {
        let c = Config::parse("[strip1]\nconnect = @physical\nconnect = @default\n[bus.A1]\nconnect = @physical\n").unwrap();
        assert_eq!(c.strips[0].connect, [PHYSICAL, DEFAULT_DEVICE]);
        assert_eq!(c.buses[0].connect, [PHYSICAL]);
        // the default config picks the desktop's default devices
        let d = Config::default();
        assert_eq!(d.strips[0].connect, [DEFAULT_DEVICE]);
        assert_eq!(d.buses[0].connect, [DEFAULT_DEVICE]);
    }

    #[test]
    fn load_or_default_never_writes() {
        let path = std::env::temp_dir().join(format!("bananasplit-test-nowrite-{}", std::process::id())).join("bananasplit.ini");
        assert_eq!(Config::load_or_default(&path).unwrap(), Config::default());
        assert!(!path.exists() && !path.parent().unwrap().exists());
    }

    #[test]
    fn gains_are_clamped_and_routes_parse() {
        let c = Config::parse("[strip2]\ngain_db = 99\nroutes = b2, a1 ,none\n").unwrap();
        assert_eq!(c.strips[1].gain_db, crate::engine::MAX_GAIN_DB);
        assert_eq!(c.strips[1].routes, 0b10001);
        assert_eq!(parse_routes("").unwrap(), 0);
        assert_eq!(format_routes(0), "none");
    }

    #[test]
    #[allow(clippy::field_reassign_with_default)]
    fn apply_and_capture() {
        let sh = Shared::new();
        let mut c = Config::default();
        c.strips[3].gain_db = -3.0;
        c.strips[3].solo = true;
        c.buses[4].mute = true;
        c.recorder.links = 0b100_0000_1000;
        c.strips[1].eq.on = true;
        c.strips[1].eq.bands[3].gain_db = -6.0;
        c.buses[2].eq.bands[0].kind = crate::eq::Kind::LowCut;
        c.apply(&sh);
        assert_eq!(sh.rec_links.load(Relaxed), 0b100_0000_1000);
        let mut d = Config::default();
        d.capture(&sh);
        assert_eq!(c, d);
    }

    #[test]
    fn save_and_load() {
        let dir = std::env::temp_dir().join(format!("bananasplit-test-{}", std::process::id()));
        let path = dir.join("sub").join("bananasplit.ini");
        let c = Config::load_or_create(&path).unwrap();
        assert_eq!(c, Config::default());
        let mut c2 = c.clone();
        c2.strips[0].name = "Voice".into();
        c2.save(&path).unwrap();
        assert_eq!(Config::load_or_create(&path).unwrap(), c2);
        std::fs::remove_dir_all(&dir).unwrap();
    }

    #[test]
    fn migrates_the_vmix_config_once() {
        let dir = std::env::temp_dir().join(format!("bananasplit-test-migrate-{}", std::process::id()));
        let _ = std::fs::remove_dir_all(&dir);
        let legacy = dir.join("vmix").join("vmix.ini");
        let path = dir.join("bananasplit").join("bananasplit.ini");
        // nothing to copy
        assert_eq!(Config::migrate_legacy(&path, &legacy).unwrap(), None);
        assert!(!path.exists());
        // the old default name is replaced, everything else is kept
        let mut old = Config { client_name: "vmix".into(), ..Config::default() };
        old.strips[0].name = "Yeti".into();
        old.recorder.folder = "~/Music/vmix".into();
        old.save(&legacy).unwrap();
        let note = Config::migrate_legacy(&path, &legacy).unwrap().unwrap();
        assert!(note.contains("BananaSplit-In1"), "{note}");
        let new = Config::load_or_default(&path).unwrap();
        assert_eq!(new.client_name, "BananaSplit");
        assert_eq!(new.strips[0].name, "Yeti");
        assert_eq!(new.recorder.folder, "~/Music/vmix");
        assert!(legacy.exists(), "the old file must stay for vmix 2.4");
        // never twice: the new file wins from now on
        assert_eq!(Config::migrate_legacy(&path, &legacy).unwrap(), None);
        // a name the user chose is kept
        std::fs::remove_file(&path).unwrap();
        old.client_name = "studio".into();
        old.save(&legacy).unwrap();
        let note = Config::migrate_legacy(&path, &legacy).unwrap().unwrap();
        assert!(!note.contains("pick them again"), "{note}");
        assert_eq!(Config::load_or_default(&path).unwrap().client_name, "studio");
        let _ = std::fs::remove_dir_all(&dir);
    }
}




