#[path = "gui.rs"]
mod gui;
#[path = "tui.rs"]
mod tui;
#[path = "win/mod.rs"]
mod win;

use bananasplit::config::Config;
use bananasplit::engine::{NUM_STRIPS, Shared};
use bananasplit::recorder::{self, RecTap, Recorder};
use bananasplit::vban::{InState, OutState, Vban, VbanTap};
use std::path::{Path, PathBuf};
use std::process::ExitCode;
use std::sync::Arc;
use std::sync::atomic::Ordering::{Relaxed, SeqCst};
use std::time::{Duration, Instant};

const HELP: &str = "BananaSplit 2.5 — Windows WASAPI mixer\n\nUSAGE:\n    bananasplit [--config FILE] [--gui] [--headless] [--no-open]\n    bananasplit --list-devices\n    bananasplit --print-default-config\n\nOptions:\n    --gui                Run the dark-mode browser GUI (default)\n    --gui-port PORT      GUI port (default 8790)\n    --no-open             Do not open the GUI in a browser\n    --headless            Run the audio engine without a UI\n    --list-devices        List Windows audio endpoints\n";

struct Args { path: PathBuf, headless: bool, no_open: bool, port: u16, explicit: bool, list: bool }

fn main() -> ExitCode {
    match run() {
        Ok(()) => ExitCode::SUCCESS,
        Err(e) => { eprintln!("bananasplit: {e}"); win::pause_on_error(); ExitCode::FAILURE }
    }
}

fn run() -> Result<(), String> {
    let mut a = Args { path: Config::default_path(), headless: false, no_open: false, port: 8790, explicit: false, list: false };
    let mut args = std::env::args().skip(1);
    while let Some(arg) = args.next() {
        match arg.as_str() {
            "-h" | "--help" => { print!("{HELP}"); return Ok(()); }
            "-V" | "--version" => { println!("BananaSplit {} (Windows)", env!("CARGO_PKG_VERSION")); return Ok(()); }
            "-c" | "--config" => a.path = args.next().ok_or("--config needs a path")?.into(),
            "--headless" => a.headless = true,
            "--gui" => a.headless = false,
            "--no-open" => a.no_open = true,
            "--gui-port" => { a.port = args.next().ok_or("--gui-port needs a port")?.parse().map_err(|_| "invalid GUI port")?; a.explicit = true; }
            "--list-devices" => a.list = true,
            "--print-default-config" => { print!("{}", Config::default().to_ini()); return Ok(()); }
            other => return Err(format!("unknown argument {other:?} (see --help)")),
        }
    }
    if a.list { print!("{}", win::list_devices()?); return Ok(()); }
    let mut cfg = Config::load_or_create(&a.path)?;
    let mut notes = Vec::new();
    win::first_run(&mut cfg, &a.path, a.headless, &mut notes);
    win::install_signal_handlers();

    let shared = Shared::new();
    cfg.apply(&shared);
    let rec_tap = RecTap::new();
    let vban_tap = VbanTap::new();
    let mut session = win::Session::open(&cfg, shared.clone(), rec_tap.clone(), vban_tap.clone(), &mut notes)?;
    let recorder = Arc::new(Recorder::new(rec_tap, 48_000, cfg.recorder.settings()));
    let vban = Arc::new(Vban::start(vban_tap, 48_000, cfg.vban.clone()));
    let result = if a.headless {
        run_headless(&mut session, &cfg, notes)
    } else {
        run_gui(&mut session, &mut cfg, &a.path, &shared, &recorder, &vban, notes, a.port, a.explicit, !a.no_open)
    };
    vban.shutdown();
    recorder.shutdown();
    drop(session);
    result
}

fn names(cfg: &Config) -> Vec<String> {
    cfg.strips.iter().map(|s| s.name.clone()).chain(cfg.buses.iter().map(|b| b.name.clone())).collect()
}
fn capture(cfg: &mut Config, shared: &Shared, rec: &Recorder, vban: &Vban) {
    cfg.capture(shared);
    cfg.recorder.set_settings(&rec.settings());
    cfg.vban = vban.config();
}
fn stamp() -> String {
    win::local_timestamp()
}
fn toggle_record(rec: &Recorder, shared: &Shared, cfg: &Config) -> Result<String, String> {
    if rec.is_recording() { rec.stop(); return Ok("recording stopped".into()); }
    let files = rec.start(shared.rec_links.load(Relaxed), &names(cfg), &stamp())?;
    Ok(format!("recording {} file(s)", files.len()))
}
fn run_headless(session: &mut win::Session, cfg: &Config, notes: Vec<String>) -> Result<(), String> {
    for n in notes { eprintln!("bananasplit: warning: {n}"); }
    let st = session.status();
    eprintln!("BananaSplit running through WASAPI at {} Hz; Ctrl-C to stop.", st.sample_rate);
    let mut changed = Some(Instant::now());
    while !win::QUIT.load(SeqCst) {
        if session.take_changed() { changed = Some(Instant::now()); }
        if changed.is_some_and(|t| t.elapsed() > Duration::from_millis(250)) {
            let (_, errs) = session.connect(cfg, false);
            for e in errs { eprintln!("bananasplit: {e}"); }
            changed = None;
        }
        std::thread::sleep(Duration::from_millis(50));
    }
    Ok(())
}
fn run_gui(session: &mut win::Session, cfg: &mut Config, path: &Path, shared: &Arc<Shared>, rec: &Arc<Recorder>, vban: &Arc<Vban>, notes: Vec<String>, requested_port: u16, explicit: bool, open: bool) -> Result<(), String> {
    let hub = gui::Hub::new(shared.clone(), rec.clone(), vban.clone());
    hub.set_names(names(cfg));
    let port = gui::start(hub.clone(), requested_port, explicit)?;
    let url = gui::url(port);
    if port != requested_port { eprintln!("bananasplit: GUI port {requested_port} busy; using {port}"); }
    for n in &notes { eprintln!("bananasplit: warning: {n}"); }
    eprintln!("bananasplit: WASAPI audio active; GUI at {url}");
    if open && !gui::open_window(&url) { eprintln!("bananasplit: open {url} in a browser"); }

    let mut status = notes.join(" | ");
    let mut view = tui::View::default();
    let mut conn = Vec::new();
    let mut changed = Some(Instant::now());
    let mut force = false;
    let frame = Duration::from_millis(33);
    let result: Result<(), String> = loop {
        let t0 = Instant::now();
        if win::QUIT.load(SeqCst) { break Ok(()); }
        let mut quit = false;
        for request in hub.take_requests() {
            match request {
                gui::Request::Quit => quit = true,
                gui::Request::Reconnect => force = true,
                gui::Request::Save => {
                    capture(cfg, shared, rec, vban);
                    status = match cfg.save(path) { Ok(()) => format!("saved {}", path.display()), Err(e) => format!("save failed: {e}") };
                }
                gui::Request::Rename(ch, name) => {
                    if ch < cfg.strips.len() { cfg.strips[ch].name = name; }
                    else if ch < cfg.strips.len() + cfg.buses.len() { cfg.buses[ch - cfg.strips.len()].name = name; }
                    hub.set_names(names(cfg));
                }
            }
        }
        if quit { break Ok(()); }
        if session.take_changed() { changed = Some(Instant::now()); }
        if force || changed.is_some_and(|t| t.elapsed() > Duration::from_millis(250)) {
            let (d, errs) = session.connect(cfg, force);
            conn = d;
            if force || !errs.is_empty() { status = if errs.is_empty() { "audio devices connected".into() } else { errs.join(" | ") }; }
            force = false;
            changed = None;
        }
        view.update_meters(shared);
        let st = session.status();
        let (lat_in, lat_out) = session.io_latency();
        let info = tui::Info { client: "WASAPI shared mode", sample_rate: st.sample_rate, buffer_size: st.buffer_size, cpu: st.cpu, xruns: shared.xruns.load(Relaxed), oversize: shared.oversize_cycles.load(Relaxed), lat_in, lat_out, cables: session.cable_count(), vban: "" };
        let rec_status = rec.status();
        let rec_settings = rec.settings();
        let (vst, vcfg) = (vban.status(), vban.config());
        hub.publish(gui::state_json(shared, &gui::Frame { info: &info, cfg, meters: view.meters(), conn: &conn, status: &status, rec: &rec_status, rec_settings: &rec_settings, vban: &vst, vban_cfg: &vcfg }));
        if let Some(rest) = frame.checked_sub(t0.elapsed()) { std::thread::sleep(rest); }
    };
    hub.close();
    result?;
    capture(cfg, shared, rec, vban);
    cfg.save(path)
}






